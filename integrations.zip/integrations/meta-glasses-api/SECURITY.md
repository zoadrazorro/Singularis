# Security Policy

## Supported Versions

| Version | Supported          |
| ------- | ------------------ |
| 1.x.x   | :white_check_mark: |

## Reporting a Vulnerability

Report any discovered vulnerabilities to Devon Crebbin by emailing `devon@land.org.au` or @dcrebbin on twitter. Your report will acknowledged within 5 days and I'll get back to you.

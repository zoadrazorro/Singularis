"""
Skyrim AGI - Complete Integration with Consciousness

Brings together all components for autonomous Skyrim gameplay:
1. Perception (screen capture + CLIP)
2. World model (causal learning, NPC relationships)
3. Consciousness measurement (Singularis coherence C)
4. Motivation (intrinsic drives + game-specific goals)
5. Goal formation (autonomous objectives)
6. Planning & execution (hierarchical actions)
7. Learning (continual, consciousness-guided)
8. Evaluation (consciousness quality assessment)

This is the complete AGI system playing Skyrim WITH FULL CONSCIOUSNESS.

Key innovation: Learning is guided by consciousness coherence (ΔC),
making consciousness the primary judge of action quality.

Design principles:
- Consciousness is PRIMARY evaluator (not backup)
- RL learns tactics guided by consciousness strategy
- Bidirectional feedback: experiences → consciousness → learning
- Unified coherence concept (game + philosophical)
"""

import asyncio
import time
import random
import numpy as np
from typing import Dict, List, Optional, Any, Tuple
from dataclasses import dataclass
import numpy as np
from loguru import logger

# Skyrim-specific modules
from .perception import SkyrimPerception, SceneType, GameState
from .actions import SkyrimActions, Action, ActionType
from .controller import VirtualXboxController
from .controller_bindings import SkyrimControllerBindings
from .skyrim_world_model import SkyrimWorldModel
from .skyrim_cognition import SkyrimCognitiveState, SkyrimMotivation, SkyrimActionEvaluator
from .strategic_planner import StrategicPlannerNeuron
from .menu_learner import MenuLearner
from .action_affordances import ActionAffordanceSystem
from .memory_rag import MemoryRAG
from .curriculum_rag import CurriculumRAG, CATEGORY_MAPPINGS
from .smart_context import SmartContextManager
from .reinforcement_learner import ReinforcementLearner
from .rl_reasoning_neuron import RLReasoningNeuron
from .meta_strategist import MetaStrategist
from .cloud_rl_system import CloudRLMemory, CloudRLAgent, RLMemoryConfig, Experience
from .consciousness_bridge import ConsciousnessBridge, ConsciousnessState
from .system_consciousness_monitor import SystemConsciousnessMonitor, NodeCoherence, SystemConsciousnessState
from .combat_tactics import SkyrimCombatTactics
from .quest_tracker import QuestTracker
from .smart_navigation import SmartNavigator
from .inventory_manager import InventoryManager
from .dialogue_intelligence import DialogueIntelligence
from .character_progression import CharacterProgression
from .enhanced_vision import EnhancedVision
from .crafting_system import CraftingSystem
from .hierarchical_goal_planner import HierarchicalGoalPlanner
from .adaptive_loop_manager import AdaptiveLoopManager, LoopSettings
from .gameplay_analytics import GameplayAnalytics
from .meta_learning import MetaLearner

from .philosophyagent import get_random_philosophical_context
from .research_advisor import ResearchAdvisor
from .metacognition_advisor import MetaCognitionAdvisor

# Base AGI components
from ..agi_orchestrator import AGIOrchestrator, AGIConfig
from ..agency import MotivationType
from ..llm import (
    LMStudioClient,
    LMStudioConfig,
    ExpertLLMInterface,
    ClaudeClient,
    GeminiClient,
    HybridLLMClient,
    HybridConfig,
    TaskType,
    MoEOrchestrator,
    ExpertRole,
    HyperbolicClient,
)
from ..llm.openrouter_client import OpenRouterClient
from ..llm.perplexity_client import PerplexityClient
from ..bdh import BDHPolicyHead, BDHMetaCortex


@dataclass
class SkyrimConfig:
    """Configuration settings for the Skyrim AGI.

    This dataclass holds all the tunable parameters and feature flags that
    control the behavior of the AGI, from its core LLM architecture to
    gameplay settings and advanced consciousness features.
    """
    # Base AGI config
    base_config: Optional[AGIConfig] = None

    # Perception
    screen_region: Optional[Dict[str, int]] = None
    use_game_api: bool = False

    # Actions
    dry_run: bool = False  # Don't actually control game (testing)
    custom_keys: Optional[Dict[ActionType, str]] = None
    
    # Controller
    controller_deadzone_stick: float = 0.15
    controller_deadzone_trigger: float = 0.05
    controller_sensitivity: float = 1.0

    # Gameplay
    autonomous_duration: int = 3600  # 1 hour default
    cycle_interval: float = 2.0  # Perception-action cycle time
    save_interval: int = 300  # Auto-save every 5 minutes
    
    # Async execution
    enable_async_reasoning: bool = True  # Run reasoning in parallel with actions
    action_queue_size: int = 3  # Max queued actions
    perception_interval: float = 0.35  # Slightly slower perception to reduce queue pressure
    max_concurrent_llm_calls: int = 4  # Reduce concurrent LLM calls for stability
    reasoning_throttle: float = 0.1  # Min seconds between reasoning cycles - minimal throttle
    
    # Fast reactive loop
    enable_fast_loop: bool = True  # Enable fast reactive loop for immediate responses
    fast_loop_interval: float = 2.0  # Fast loop runs every 2 seconds (reduced from 0.5s)
    fast_loop_planning_timeout: float = 20.0  # Only trigger fast actions if LLM planning takes >20s
    fast_health_threshold: float = 30.0  # Health % to trigger emergency healing
    fast_danger_threshold: int = 3  # Number of enemies to trigger defensive actions

    # Core models
    phi4_action_model: str = "microsoft/phi-4-mini-reasoning"  # Action planning (fast, reliable)
    huihui_cognition_model: str = "microsoft/phi-4-mini-reasoning:2"  # Main cognition, reasoning, strategy (fast, reliable)
    qwen3_vl_perception_model: str = "qwen/qwen3-vl-30b"  # Perception and spatial awareness

    # Learning
    surprise_threshold: float = 0.3  # Threshold for learning from surprise
    exploration_weight: float = 0.5  # How much to favor exploration

    # Reinforcement Learning
    use_rl: bool = True  # Enable RL-based learning
    rl_learning_rate: float = 0.01  # Q-network learning rate
    rl_epsilon_start: float = 0.3  # Initial exploration rate
    rl_train_freq: int = 5  # Train every N cycles
    
    # Cloud-Enhanced RL
    use_cloud_rl: bool = True  # Enable cloud LLM-enhanced RL
    rl_memory_dir: str = "skyrim_rl_memory"
    rl_use_rag: bool = True  # Enable RAG context fetching
    use_curriculum_rag: bool = True  # Enable university curriculum knowledge augmentation
    rl_cloud_reward_shaping: bool = True  # Use cloud LLM for reward shaping
    rl_moe_evaluation: bool = True  # Use MoE for action evaluation
    rl_save_frequency: int = 100  # Save RL memory every N experiences

    # Hybrid LLM Architecture (Primary: Gemini + Claude, Optional Fallback: Local)
    use_hybrid_llm: bool = True
    use_gemini_vision: bool = True
    gemini_model: str = "gemini-2.5-flash"
    use_claude_reasoning: bool = True
    claude_model: str = "claude-3-5-haiku-20241022"  # Fast Haiku for background reasoning
    claude_sensorimotor_model: str = "claude-3-5-haiku-20241022"  # Fast Haiku for sensorimotor
    use_local_fallback: bool = False  # Optional local LLMs as fallback
    
    # Mixture of Experts (MoE) Architecture
    use_moe: bool = False  # Enable MoE with multiple expert instances
    num_gemini_experts: int = 2  # Number of Gemini experts (optimal for rate limits)
    num_claude_experts: int = 1  # Number of Claude experts (optimal for rate limits)
    gemini_rpm_limit: int = 30  # Gemini requests per minute limit (increased from 10)
    claude_rpm_limit: int = 100  # Claude requests per minute limit (increased from 50)
    
    # Parallel Mode (MoE + Hybrid simultaneously)
    use_parallel_mode: bool = False  # Run both MoE and Hybrid in parallel
    parallel_consensus_weight_moe: float = 0.6  # Weight for MoE consensus
    parallel_consensus_weight_hybrid: float = 0.4  # Weight for Hybrid output
    
    # Realtime Decision Coordination (GPT-4 Realtime API)
    use_realtime_coordinator: bool = False  # Enable GPT-4 Realtime API for streaming decisions
    realtime_decision_frequency: int = 10  # Use realtime coordinator every N cycles
    
    # Self-Reflection System (GPT-4 Realtime)
    use_self_reflection: bool = False  # Enable iterative evolving self-reflection
    self_reflection_frequency: int = 50  # Reflect every N cycles
    self_reflection_chain_length: int = 3  # Iterations per reflection chain
    
    # Reward-Guided Heuristic Tuning (Claude Sonnet 4.5)
    use_reward_tuning: bool = False  # Enable reward-guided heuristic fine-tuning
    reward_tuning_frequency: int = 10  # Tune heuristics every N outcomes
    
    # GPT-5 Central Orchestrator (NEW)
    use_gpt5_orchestrator: bool = True  # Enable GPT-5 meta-cognitive coordination
    gpt5_verbose: bool = True  # Verbose console logging of all system messages
    
    # Voice System (NEW - Gemini 2.5 Pro TTS)
    enable_voice: bool = True  # Enable voice system for thought vocalization
    voice_type: str = "NOVA"  # Voice type (NOVA, ALLOY, ECHO, FABLE, ONYX, SHIMMER)
    voice_min_priority: str = "HIGH"  # Minimum priority to vocalize (LOW, MEDIUM, HIGH, CRITICAL)
    
    # Streaming Video Interpreter (NEW - Gemini 2.5 Flash Native Audio)
    enable_video_interpreter: bool = True  # Enable real-time video analysis with spoken commentary
    video_interpretation_mode: str = "COMPREHENSIVE"  # Mode (TACTICAL, SPATIAL, NARRATIVE, STRATEGIC, COMPREHENSIVE)
    video_frame_rate: float = 0.5  # Frames per second to analyze (0.5 = 1 frame every 2 seconds)
    
    # Double Helix Architecture (NEW - 15-System Integration)
    use_double_helix: bool = True  # Enable double helix integration
    self_improvement_gating: bool = True  # Enable self-improvement gating based on integration scores
    
    # Beta 1.0 Features - Temporal Binding
    enable_temporal_binding: bool = True  # Enable temporal coherence tracking
    temporal_window_size: int = 20  # Number of recent bindings to track
    temporal_timeout: float = 30.0  # Seconds before auto-closing stale bindings
    
    # Beta 1.0 Features - Adaptive Memory
    enable_adaptive_memory: bool = True  # Enable adaptive forgetting
    memory_decay_rate: float = 0.95  # Confidence decay rate per consolidation
    memory_forget_threshold: float = 0.1  # Confidence below which patterns are forgotten
    
    # Beta 1.0 Features - Enhanced Coherence
    enable_enhanced_coherence: bool = True  # Enable 4D coherence measurement
    
    # Beta 1.0 Features - Lumen Balance
    enable_lumen_balance: bool = True  # Enable Lumen balance tracking and rebalancing
    lumen_severe_threshold: float = 0.5  # Balance score for emergency rebalancing
    lumen_moderate_threshold: float = 0.7  # Balance score for gradual rebalancing
    
    # Beta 1.0 Features - Unified Perception
    enable_unified_perception: bool = True  # Enable cross-modal perception fusion
    
    # Beta 1.0 Features - Goal Generation
    enable_goal_generation: bool = True  # Enable novel goal generation
    max_active_goals: int = 3  # Maximum concurrent active goals
    goal_novelty_threshold: float = 0.7  # Minimum novelty for new goals (0-1)
    
    # Beta 1.0 Features - Live Audio Stream
    enable_live_audio: bool = True  # Enable real-time audio commentary
    live_audio_frequency: float = 5.0  # Seconds between audio updates
    live_audio_style: str = "analytical"  # Narration style (analytical, dramatic, technical, casual)
    
    # HaackLang + SCCE Integration (NEW - Cognitive Calculus)
    use_haacklang: bool = True  # Enable HaackLang cognitive modules
    haack_beat_interval: float = 0.1  # Beat interval in seconds (10 Hz default)
    haack_verbose: bool = False  # Verbose HaackLang logging
    scce_profile: str = "balanced"  # SCCE personality (balanced, anxious, stoic, curious, aggressive, cautious)
    scce_frequency: int = 1  # Run SCCE cognition_step every N cycles (1 = every cycle)
    
    # Infinity Engine Phase 2 (NEW - Adaptive Rhythmic Cognition)
    use_infinity_engine: bool = True  # Enable Infinity Engine Phase 2A/2B
    infinity_verbose: bool = False  # Verbose Infinity Engine logging
    # Phase 2A settings
    coherence_v2_threshold: float = 0.4  # Minimum coherence before intervention
    meta_context_enabled: bool = True  # Enable hierarchical temporal contexts
    # Phase 2B settings
    polyrhythmic_learning_enabled: bool = True  # Enable adaptive track periods
    rhythm_learning_rate: float = 0.01  # How fast rhythms adapt
    harmonic_attraction: float = 0.1  # Strength of harmonic synchronization
    memory_v2_enabled: bool = True  # Enable temporal-rhythmic memory
    memory_v2_capacity: int = 1000  # Episodic memory capacity
    memory_consolidation_threshold: int = 3  # Reinforcements before consolidation
    memory_decay_rate: float = 0.001  # Forgetting rate per cycle
    
    # Legacy external augmentation (deprecated in favor of hybrid)
    enable_claude_meta: bool = False
    enable_gemini_vision: bool = False
    gemini_max_output_tokens: int = 768

    def __post_init__(self):
        """Initializes the base AGIConfig if it's not provided."""
        if self.base_config is None:
            self.base_config = AGIConfig(
                use_vision=True,
                use_physics=False,  # Don't need physics sim for Skyrim
                curiosity_weight=0.35,  # Higher curiosity for exploration
                competence_weight=0.15,
                coherence_weight=0.40,  # Note: This is still used by base AGI
                autonomy_weight=0.10,
            )


class SkyrimAGI:
    """The main class that integrates all AGI components for autonomous Skyrim gameplay.

    This class orchestrates the entire perception-action-learning loop. It
    initializes and connects dozens of specialized subsystems, including perception,
    action execution, world modeling, various LLM architectures (Hybrid, MoE),
    reinforcement learning, and multiple layers of consciousness and strategic
    reasoning. Its core innovation is the use of consciousness coherence (ΔC)
    as the primary reward signal to guide learning.
    """

    def __init__(self, config: Optional[SkyrimConfig] = None):
        """Initializes the complete Skyrim AGI system.

        This method sets up all the necessary components based on the provided
        configuration, including perception, action controllers, world models,
        LLM clients, and various learning and reasoning systems.

        Args:
            config: A `SkyrimConfig` object containing the desired settings.
        """
        self.config = config or SkyrimConfig()

        print("=" * 60)
        print("SINGULARIS AGI - SKYRIM INTEGRATION")
        print("=" * 60)

        # Components
        print("\nInitializing components...")

        # 1. Base AGI orchestrator
        print("  [1/4] Base AGI system...")
        self.agi = AGIOrchestrator(self.config.base_config)

        # 2. Skyrim perception
        print("  [2/4] Skyrim perception...")
        self.perception = SkyrimPerception(
            vision_module=self.agi.world_model.vision if self.config.base_config.use_vision else None,
            screen_region=self.config.screen_region,
            use_game_api=self.config.use_game_api
        )

        # 3. Skyrim actions
        print("  [3/4] Skyrim actions...")
        # Controller and bindings
        self.controller = VirtualXboxController(
            deadzone_stick=self.config.controller_deadzone_stick,
            deadzone_trigger=self.config.controller_deadzone_trigger,
            sensitivity=self.config.controller_sensitivity,
            dry_run=self.config.dry_run
        )
        self.bindings = SkyrimControllerBindings(self.controller)
        self.bindings.switch_to_exploration()
        self.actions = SkyrimActions(
            use_game_api=self.config.use_game_api,
            custom_keys=self.config.custom_keys,
            dry_run=self.config.dry_run,
            controller=self.controller
        )

        # 4. THE ONE THING - BeingState + CoherenceEngine
        print("  [4/20] THE UNIFIED BEING - BeingState + CoherenceEngine...")
        from singularis.core.being_state import BeingState
        from singularis.core.coherence_engine import CoherenceEngine
        
        self.being_state = BeingState()
        self.coherence_engine = CoherenceEngine(verbose=True)
        
        print("[BEING] Unified BeingState initialized")
        print("[BEING] CoherenceEngine ready - optimizing C_global")
        print("[BEING] This is the metaphysical center: one being, one coherence")
        
        # 5. Skyrim world model
        print("  [5/20] Skyrim world model...")
        self.skyrim_world = SkyrimWorldModel(
            base_world_model=self.agi.world_model
        )
        
        # 5. Consciousness Bridge (NEW - connects game to consciousness)
        print("  [5/11] Consciousness bridge...")
        self.consciousness_bridge = ConsciousnessBridge(
            consciousness_llm=None  # Will be set after LLM initialization
        )
        
        # 5b. Expert Rule System (NEW - fast rule-based reasoning)
        print("  [5b/11] Expert rule system...")
        from .expert_rules import RuleEngine
        self.rule_engine = RuleEngine()
        
        # 5c. Emergency Rules System (NEW - critical situation handler)
        print("  [5c/11] Emergency response rules...")
        from .emergency_rules import EmergencyRules
        self.emergency_rules = EmergencyRules()
        print("[BRIDGE] Consciousness bridge initialized")
        print("[BRIDGE] This unifies game quality and philosophical coherence C")
        
        # 6. Quantum Superposition Explorer (4D Fractal RNG)
        print("  [6/11] Quantum superposition (4D fractal RNG)...")
        from ..core.fractal_rng import QuantumSuperpositionExplorer
        self.quantum_explorer = QuantumSuperpositionExplorer(
            seed=int(time.time() * 1000) % 2**32
        )
        print("[QUANTUM] 4D Fractal RNG initialized")
        print("[QUANTUM] Variance: 0.01-0.09% | Fibonacci phi ~= 1.618")
        
        # 6. Reinforcement Learning System (with consciousness)
        if self.config.use_rl:
            print("  [6/11] Reinforcement learning system (consciousness-guided)...")
            self.rl_learner = ReinforcementLearner(
                state_dim=64,
                learning_rate=self.config.rl_learning_rate,
                epsilon_start=self.config.rl_epsilon_start,
                consciousness_bridge=self.consciousness_bridge  # KEY: Connect to consciousness
            )
            # Try to load saved model
            self.rl_learner.load('skyrim_rl_model.pkl')
        else:
            self.rl_learner = None
            print("  [6/11] Reinforcement learning DISABLED")
        
        # 6b. Cloud-Enhanced RL System (will be initialized after LLM setup)
        self.cloud_rl_memory: Optional[CloudRLMemory] = None
        self.cloud_rl_agent: Optional[CloudRLAgent] = None
        if self.config.use_cloud_rl:
            print("  [6b/11] Cloud-enhanced RL system (will initialize after LLM)...")
            print("  [6b/11] Features: RAG context, cloud reward shaping, MoE evaluation")
        
        # 7. Strategic Planner Neuron
        print("  [7/11] Strategic planner neuron...")
        self.strategic_planner = StrategicPlannerNeuron(memory_capacity=100)
        
        # Connect RL learner to strategic planner if RL enabled
        if self.rl_learner:
            self.strategic_planner.set_rl_learner(self.rl_learner)

        # 8. Menu Learner
        print("  [8/11] Menu interaction learner...")
        self.menu_learner = MenuLearner()
        
        # 8b. Action Affordances System
        print("  [8b/11] Action affordances system...")
        self.action_affordances = ActionAffordanceSystem()

        # 9. Memory RAG System
        print("  [9/11] Memory RAG system...")
        self.memory_rag = MemoryRAG(
            perceptual_capacity=1000,
            cognitive_capacity=500
        )
        
        # 9b. University Curriculum RAG System
        if self.config.use_curriculum_rag:
            print("  [9b/11] University Curriculum RAG (academic knowledge)...")
            self.curriculum_rag = CurriculumRAG(
                curriculum_path="university_curriculum",
                max_documents=150,
                chunk_size=2000
            )
            try:
                self.curriculum_rag.initialize()
                stats = self.curriculum_rag.get_stats()
                print(f"    [OK] Indexed {stats['documents_indexed']} texts across {len(stats['categories'])} categories")
            except Exception as e:
                print(f"    ⚠️ Curriculum RAG initialization failed: {e}")
                self.curriculum_rag = None
        else:
            self.curriculum_rag = None
        
        # 9c. Smart Context Manager
        print("  [9c/11] Smart context management...")
        self.smart_context = SmartContextManager(
            max_tokens_per_call=2000,
            cache_size=100,
            enable_compression=True
        )
        print("    [OK] Context optimization enabled")
        
        # 10. RL Reasoning Neuron (LLM thinks about RL)
        print("  [10/11] RL reasoning neuron (LLM-enhanced RL)...")
        self.rl_reasoning_neuron = RLReasoningNeuron()
        # Will connect LLM interface when initialized
        
        # Hybrid LLM system (Gemini + Claude + optional local fallback)
        self.hybrid_llm: Optional[HybridLLMClient] = None
        
        # MoE system (2 Gemini + 1 Claude + 1 GPT-4o + Hyperbolic experts)
        self.moe: Optional[MoEOrchestrator] = None
        
        # Legacy LLM references (for backward compatibility)
        self.huihui_llm = None  # Main cognition
        self.perception_llm = None  # Visual perception
        self.action_planning_llm = None  # Action planning
        
        # 11. Meta-Strategist (coordinates tactical & strategic thinking)
        print("  [11/12] Meta-strategist coordinator...")
        # Lower instruction frequency for faster API testing (default: 10)
        self.meta_strategist = MetaStrategist(instruction_frequency=3)
        # Will connect LLM interface when initialized
        
        # 12. Emotion System (HuiHui)
        print("  [12/14] Emotion system (HuiHui)...")
        from .emotion_integration import SkyrimEmotionIntegration
        from ..emotion import EmotionConfig
        
        self.emotion_integration = SkyrimEmotionIntegration(
            emotion_config=EmotionConfig(
                lm_studio_url=self.config.lm_studio_url if hasattr(self.config, 'lm_studio_url') else "http://localhost:1234/v1",
                model_name="huihui-moe-60b-a38",
                temperature=0.8,
                decay_rate=0.1
            )
        )
        print("    [OK] HuiHui emotion system initialized")
        
        # 13. Spiritual Awareness System
        print("  [13/14] Spiritual awareness system...")
        from ..consciousness import SpiritualAwarenessSystem
        
        self.spiritual = SpiritualAwarenessSystem()
        print("    [OK] Contemplative wisdom integrated")
        print("    [OK] Traditions: Spinoza, Buddhism, Vedanta, Taoism, Stoicism")
        
        # 14. Realtime Decision Coordinator (GPT-4 Realtime API)
        print("  [14/15] Realtime decision coordinator (GPT-4 Realtime)...")
        from .realtime_coordinator import RealtimeCoordinator
        
        self.realtime_coordinator = None  # Will be initialized if enabled
        if self.config.use_realtime_coordinator:
            try:
                self.realtime_coordinator = RealtimeCoordinator(self)
                print("    [OK] GPT-4 Realtime API coordinator initialized")
                print("    [OK] Streaming decision-making enabled")
                print("    [OK] Subsystem delegation configured")
            except Exception as e:
                print(f"    ⚠️ Realtime coordinator initialization failed: {e}")
                print("    ⚠️ Continuing without realtime coordination")
                self.realtime_coordinator = None
        else:
            print("    ⚠️ Realtime coordinator disabled (set use_realtime_coordinator=True to enable)")
        
        # 15. Self-Reflection System (GPT-4 Realtime)
        print("  [15/17] Self-reflection system (GPT-4 Realtime)...")
        from ..consciousness import SelfReflectionSystem
        
        self.self_reflection = None
        if self.config.use_self_reflection:
            try:
                self.self_reflection = SelfReflectionSystem()
                print("    [OK] Iterative evolving self-reflection initialized")
                print("    [OK] GPT-4 Realtime for continuous self-understanding")
            except Exception as e:
                print(f"    ⚠️ Self-reflection initialization failed: {e}")
                self.self_reflection = None
        else:
            print("    ⚠️ Self-reflection disabled")
        
        # 16. Reward-Guided Heuristic Fine-Tuning (Claude Sonnet 4.5)
        print("  [16/17] Reward-guided heuristic tuning (Claude Sonnet 4.5)...")
        from ..learning.reward_guided_tuning import RewardGuidedTuning
        
        self.reward_tuning = None
        if self.config.use_reward_tuning:
            # Will be initialized after Claude client is ready
            print("    [OK] Reward-guided tuning configured (will initialize with Claude)")
        else:
            print("    ⚠️ Reward-guided tuning disabled")
        
        # 17. GPT-5 Central Orchestrator (NEW - Meta-Cognitive Coordination)
        print("  [17/22] GPT-5 central orchestrator...")
        from ..llm import GPT5Orchestrator, SystemType
        
        self.gpt5_orchestrator = None
        if self.config.use_gpt5_orchestrator:
            try:
                self.gpt5_orchestrator = GPT5Orchestrator(
                    model="gpt-5",
                    verbose=self.config.gpt5_verbose
                )
                print("    [OK] GPT-5 meta-cognitive coordinator initialized")
                print("    [OK] All subsystems will communicate through GPT-5")
            except Exception as e:
                print(f"    ⚠️ GPT-5 orchestrator initialization failed: {e}")
                self.gpt5_orchestrator = None
        else:
            print("    ⚠️ GPT-5 orchestrator disabled")
        
        # 18. Voice System (NEW - Gemini 2.5 Pro TTS)
        print("  [18/22] Voice system (Gemini 2.5 Pro TTS)...")
        from ..consciousness import VoiceSystem, VoiceType, ThoughtPriority
        
        self.voice_system = None
        if self.config.enable_voice:
            try:
                # Get voice type from config (default to CHARON)
                voice_name = self.config.voice_type if hasattr(self.config, 'voice_type') else "CHARON"
                voice_type = getattr(VoiceType, voice_name.upper(), VoiceType.CHARON)
                
                # Get min priority from config (default to MEDIUM)
                priority_name = self.config.voice_min_priority if hasattr(self.config, 'voice_min_priority') else "MEDIUM"
                min_priority = getattr(ThoughtPriority, priority_name.upper(), ThoughtPriority.MEDIUM)
                
                self.voice_system = VoiceSystem(
                    voice=voice_type,
                    enabled=True,
                    min_priority=min_priority
                )
                print(f"    [OK] Voice system initialized with {voice_name} voice")
                print(f"    [OK] Min priority: {priority_name}")
                print("    [OK] AGI can now speak its thoughts aloud")
            except Exception as e:
                print(f"    ⚠️ Voice system initialization failed: {e}")
                self.voice_system = None
        else:
            print("    ⚠️ Voice system disabled")
        
        # 19. Streaming Video Interpreter (NEW - Gemini 2.5 Flash Native Audio)
        print("  [19/22] Streaming video interpreter (Gemini 2.5 Flash)...")
        from ..perception import StreamingVideoInterpreter, InterpretationMode
        
        self.video_interpreter = None
        if self.config.enable_video_interpreter:
            try:
                self.video_interpreter = StreamingVideoInterpreter(
                    mode=InterpretationMode.COMPREHENSIVE,
                    frame_rate=self.config.video_frame_rate,
                    audio_enabled=True
                )
                print("    [OK] Video interpreter initialized in COMPREHENSIVE mode")
                print("    [OK] Real-time video analysis with spoken commentary")
            except Exception as e:
                print(f"    ⚠️ Video interpreter initialization failed: {e}")
                self.video_interpreter = None
        else:
            print("    ⚠️ Video interpreter disabled")
        
        # 20. Double Helix Architecture (NEW - 17-System Integration)
        print("  [20/22] Double helix architecture...")
        from ..evolution import DoubleHelixArchitecture
        
        self.double_helix = None
        if self.config.use_double_helix:
            try:
                self.double_helix = DoubleHelixArchitecture()
                self.double_helix.initialize_systems()
                stats = self.double_helix.get_stats()
                print(f"    [OK] Double helix initialized: {stats['total_nodes']} systems")
                print(f"    [OK] Analytical strand: {stats['analytical_nodes']} nodes")
                print(f"    [OK] Intuitive strand: {stats['intuitive_nodes']} nodes")
                print(f"    [OK] Integration score: {stats['average_integration']:.3f}")
            except Exception as e:
                print(f"    ⚠️ Double helix initialization failed: {e}")
                self.double_helix = None
        else:
            print("    ⚠️ Double helix disabled")
        
        # 20.5 Hyperbolic API Integration (NEW - Parallel Reasoning & Vision)
        print("  [20.5/22] Hyperbolic API (Qwen3-235B + NVIDIA Nemotron)...")
        self.hyperbolic_reasoning = None
        self.hyperbolic_vision = None
        try:
            # Reasoning model (Qwen3-235B - 235 billion parameters)
            self.hyperbolic_reasoning = HyperbolicClient(
                model="Qwen/Qwen3-235B-A22B-Instruct-2507",
                timeout=300  # 5 minutes for 235B model
            )
            if self.hyperbolic_reasoning.is_available():
                print("    [OK] Hyperbolic Reasoning (Qwen3-235B) initialized")
                print("    [OK] Meta-cognitive reasoning enabled")
                
                # Record in double helix
                if self.double_helix:
                    self.double_helix.record_activation("hyperbolic_reasoning", True, 1.0)
            else:
                print("    ⚠️ Hyperbolic API key not found (HYPERBOLIC_API_KEY)")
                self.hyperbolic_reasoning = None
            
            # Vision model (NVIDIA Nemotron)
            self.hyperbolic_vision = HyperbolicClient(
                vlm_model="nvidia/NVIDIA-Nemotron-Nano-12B-v2-VL-BF16",
                timeout=120
            )
            if self.hyperbolic_vision.is_available():
                print("    [OK] Hyperbolic Vision (NVIDIA Nemotron) initialized")
                print("    [OK] Visual awareness enabled")
                
                # Record in double helix
                if self.double_helix:
                    self.double_helix.record_activation("hyperbolic_vision", True, 1.0)
            else:
                self.hyperbolic_vision = None
        except Exception as e:
            print(f"    ⚠️ Hyperbolic initialization failed: {e}")
            self.hyperbolic_reasoning = None
            self.hyperbolic_vision = None

        # OMEGA DNA Hyperhelix (second helix mapping to Double Helix)
        try:
            from ..evolution import OmegaHyperhelix
            self.omega = OmegaHyperhelix(
                self.double_helix,
                symbolic_bridge=getattr(self, 'symbolic_neural_bridge', None),
                curriculum=getattr(self, 'curriculum', None),
                task_sampler=getattr(self, 'task_sampler', None),
                memory=getattr(self, 'hierarchical_memory', None),
                world_model=getattr(self, 'skyrim_world', None),
                perception=getattr(self, 'perception', None),
                video_interpreter=getattr(self, 'video_interpreter', None),
                voice_system=getattr(self, 'voice_system', None),
                moe=getattr(self, 'moe', None),
                hybrid_llm=getattr(self, 'hybrid_llm', None),
            )
            print("  [OMEGA] Hyperhelix initialized and mapped to Double Helix")
        except Exception as e:
            print(f"  [OMEGA] Initialization failed: {e}")
            self.omega = None
        
        # Research Advisor (Perplexity)
        print("  [RESEARCH] Perplexity research advisor...")
        self.research_advisor = ResearchAdvisor()
        if self.research_advisor.client.is_available():
            print("    [OK] Perplexity API connected (sonar-medium-online)")
        else:
            print("    ⚠️ Perplexity API key not found (PERPLEXITY_API_KEY)")
        
        # MetaCognition Advisor (OpenRouter)
        print("  [METACOG] OpenRouter metacognition advisor...")
        self.metacog_advisor = MetaCognitionAdvisor()
        if self.metacog_advisor.client.is_available():
            print("    [OK] OpenRouter API connected (gpt-4o + deepseek)")
        else:
            print("    ⚠️ OpenRouter API key not found (OPENROUTER_API_KEY)")
        
        # 21. Temporal Binding System (NEW - Critical)
        print("  [21/27] Temporal binding system...")
        from ..core.temporal_binding import TemporalCoherenceTracker
        
        self.temporal_tracker = TemporalCoherenceTracker(window_size=20)
        print("    [OK] Temporal coherence tracking initialized")
        print("    [OK] Perception→action→outcome loops will be tracked")
        
        # 22. CONTINUUM PHASE 1 INTEGRATION (NEW - Next-Gen Architecture)
        print("  [22/27] Continuum Phase 1 (Observable mode)...")
        from ..continuum import ContinuumIntegration
        
        self.continuum = ContinuumIntegration(
            phase=1,  # Observable only - no control changes
            subsystems=[
                'perception', 'consciousness', 'emotion', 'motivation',
                'learning', 'action', 'temporal', 'lumina_ontic',
                'lumina_structural', 'lumina_participatory', 'gpt5',
                'double_helix', 'voice', 'video', 'research', 'philosophy',
                'metacognition', 'main_brain', 'wolfram', 'hybrid_llm'
            ],
            config={
                'manifold_dimensions': 20,  # Start with 20D manifold
            }
        )
        print("    [OK] Continuum Phase 1 initialized")
        print("    [OK] CoherenceManifold (20D consciousness space)")
        print("    [OK] GraphConsciousnessField (subsystem graph)")
        print("    [OK] TemporalSuperpositionEngine (future simulation)")
        print("    ⚠️ OBSERVATION MODE - No control changes")
        
        # 23. HaackLang Bridge + SCCE (NEW - Cognitive Calculus Engine)
        print("  [23/28] HaackLang + SCCE integration...")
        from ..haacklang_bridge import SingularisHaackBridge
        from ..skyrim.Haacklang.src.haackc.scc_calculus import (
            cognition_step,
            BALANCED_PROFILE,
            ANXIOUS_PROFILE,
            STOIC_PROFILE,
        )
        
        self.haack_bridge = None
        self.scce_profile = BALANCED_PROFILE  # Default profile
        
        if self.config.use_haacklang:
            try:
                # Initialize HaackLang bridge
                modules_dir = Path(__file__).parent / "Haacklang" / "cognitive_modules"
                self.haack_bridge = SingularisHaackBridge(
                    modules_dir=modules_dir,
                    beat_interval=self.config.haack_beat_interval,
                    verbose=self.config.haack_verbose
                )
                
                # Load cognitive modules
                loaded = self.haack_bridge.load_all_modules()
                print(f"    [OK] HaackLang runtime initialized")
                print(f"    [OK] Loaded {len(loaded)} cognitive modules:")
                for module_name in loaded:
                    print(f"        - {module_name}.haack")
                
                # Register Python callbacks for subsystems
                self._register_haack_callbacks()
                
                # Set SCCE profile based on config
                profile_name = self.config.scce_profile if hasattr(self.config, 'scce_profile') else 'balanced'
                if profile_name.lower() == 'anxious':
                    self.scce_profile = ANXIOUS_PROFILE
                elif profile_name.lower() == 'stoic':
                    self.scce_profile = STOIC_PROFILE
                else:
                    self.scce_profile = BALANCED_PROFILE
                
                print(f"    [OK] SCCE profile: {self.scce_profile.name}")
                print("    [OK] Temporal cognitive dynamics enabled")
                print("    [OK] Fear/trust/stress/curiosity evolution active")
                
                # Record in double helix
                if self.double_helix:
                    self.double_helix.record_activation("haacklang_runtime", True, 1.0)
                    self.double_helix.record_activation("scce_cognition", True, 1.0)
                
            except Exception as e:
                print(f"    ⚠️ HaackLang/SCCE initialization failed: {e}")
                print(f"    ⚠️ Continuing without cognitive calculus")
                self.haack_bridge = None
        else:
            print("    ⚠️ HaackLang/SCCE disabled (set use_haacklang=True to enable)")
        
        # 24. Infinity Engine Phase 2 (NEW - Adaptive Rhythmic Cognition)
        print("  [24/28] Infinity Engine Phase 2A/2B...")
        from ..infinity import (
            CoherenceEngineV2,
            MetaContextSystem,
            Context,
            ContextLevel,
            PolyrhythmicLearner,
            AdaptationStrategy,
            MemoryEngineV2,
            create_exploration_profile,
            create_survival_profile,
            create_learning_profile,
        )
        
        self.coherence_v2 = None
        self.meta_context = None
        self.rhythm_learner = None
        self.memory_v2 = None
        
        if self.config.use_infinity_engine:
            try:
                # Phase 2A: Coherence Engine V2
                self.coherence_v2 = CoherenceEngineV2(
                    contradiction_threshold=0.7,
                    tension_threshold=0.6,
                    coherence_minimum=self.config.coherence_v2_threshold,
                    verbose=self.config.infinity_verbose
                )
                print("    [OK] Coherence Engine V2 initialized (Meta-Logic)")
                
                # Phase 2A: Meta-Context System
                if self.config.meta_context_enabled:
                    self.meta_context = MetaContextSystem(
                        verbose=self.config.infinity_verbose
                    )
                    
                    # Add predefined context profiles
                    exploration_profile = create_exploration_profile()
                    survival_profile = create_survival_profile()
                    learning_profile = create_learning_profile()
                    
                    # Create contexts from profiles
                    exploration_ctx = Context(
                        name='exploration',
                        level=ContextLevel.MACRO,
                        track_amplifications=exploration_profile.track_periods,
                        coherence_threshold=0.5
                    )
                    survival_ctx = Context(
                        name='survival',
                        level=ContextLevel.MACRO,
                        track_amplifications={'perception': 1.5, 'fast_response': 1.8},
                        track_suppressions={'reflection': 0.3, 'creativity': 0.2},
                        coherence_threshold=0.5
                    )
                    learning_ctx = Context(
                        name='learning',
                        level=ContextLevel.MACRO,
                        track_amplifications={'reflection': 1.5, 'memory_consolidation': 1.4},
                        plasticity_factor=1.5
                    )
                    
                    # Start in exploration context
                    self.meta_context.push_context(exploration_ctx)
                    
                    print("    [OK] Meta-Context System initialized")
                    print("    [OK] Contexts: exploration, survival, learning")
                else:
                    print("    ⚠️ Meta-Context disabled")
                
                # Phase 2B: Polyrhythmic Learning
                if self.config.polyrhythmic_learning_enabled:
                    self.rhythm_learner = PolyrhythmicLearner(
                        strategy=AdaptationStrategy.REWARD_BASED,
                        global_learning_rate=self.config.rhythm_learning_rate,
                        harmonic_attraction=self.config.harmonic_attraction,
                        verbose=self.config.infinity_verbose
                    )
                    
                    # Register cognitive tracks
                    self.rhythm_learner.register_track('perception', initial_period=100, min_period=20, max_period=500)
                    self.rhythm_learner.register_track('reflection', initial_period=200, min_period=50, max_period=1000)
                    self.rhythm_learner.register_track('strategic', initial_period=500, min_period=100, max_period=2000)
                    self.rhythm_learner.register_track('fast_response', initial_period=50, min_period=10, max_period=200)
                    
                    # Add harmonic constraints
                    self.rhythm_learner.add_harmonic_constraint('perception', 'reflection', 0.5)
                    self.rhythm_learner.add_harmonic_constraint('fast_response', 'perception', 0.5)
                    
                    # Add rhythm profiles
                    self.rhythm_learner.add_rhythm_profile(exploration_profile)
                    self.rhythm_learner.add_rhythm_profile(survival_profile)
                    self.rhythm_learner.add_rhythm_profile(learning_profile)
                    
                    print("    [OK] Polyrhythmic Learning initialized")
                    print("    [OK] 4 adaptive tracks with harmonic constraints")
                else:
                    print("    ⚠️ Polyrhythmic Learning disabled")
                
                # Phase 2B: Memory Engine V2
                if self.config.memory_v2_enabled:
                    self.memory_v2 = MemoryEngineV2(
                        episodic_capacity=self.config.memory_v2_capacity,
                        semantic_capacity=500,
                        decay_rate=self.config.memory_decay_rate,
                        consolidation_threshold=self.config.memory_consolidation_threshold,
                        verbose=self.config.infinity_verbose
                    )
                    print("    [OK] Memory Engine V2 initialized (Temporal-Rhythmic)")
                    print(f"    [OK] Capacity: {self.config.memory_v2_capacity} episodic, 500 semantic")
                else:
                    print("    ⚠️ Memory Engine V2 disabled")
                
                print("    [OK] Infinity Engine Phase 2A/2B ready")
                print("    [OK] Adaptive rhythmic cognition enabled")
                
                # Record in double helix if available
                if self.double_helix:
                    self.double_helix.record_activation("infinity_engine", True, 1.0)
                
            except Exception as e:
                print(f"    ⚠️ Infinity Engine initialization failed: {e}")
                print(f"    ⚠️ Continuing without adaptive rhythmic cognition")
                self.coherence_v2 = None
                self.meta_context = None
                self.rhythm_learner = None
                self.memory_v2 = None
        else:
            print("    ⚠️ Infinity Engine disabled (set use_infinity_engine=True to enable)")

        # MATRIX NETWORK OF IMPROVEMENT + PTPL (scaffolding)
        try:
            from ..evolution.matrix_network import MatrixManager
            from ..reasoning.ptpl import PTPL
            self.matrix_manager = MatrixManager(omega=self.omega)
            self.matrix_manager.map_to_omega()
            print(f"  [MATRIX] Manager initialized: modules = {len(self.matrix_manager.modules)}")
            self.ptpl = PTPL(omega=self.omega)
            print("  [PTPL] Phase-Temporal Participatory Logic ready")

            # Register S/H/E executors to real subsystems
            try:
                # S: Rule engine + affordances (symbolic)
                self.matrix_manager.register_executor(
                    "S-Sensorimotor",
                    lambda ctx: (
                        (
                            lambda rec: {'action': rec.action, 'confidence': 0.8} if rec else None
                        )(
                            self.rule_engine.get_top_recommendation(exclude_blocked=True)
                            if hasattr(self, 'rule_engine') and self.rule_engine else None
                        )
                    )
                )
                # H: Reflex & heuristic templates (motor/combat/navigator)
                self.matrix_manager.register_executor(
                    "H-Sensorimotor",
                    lambda ctx: (
                        (lambda a: {'action': a, 'confidence': 0.7} if a else None)(
                            (self.reflex_controller.get_reflex_action(self.current_perception.get('game_state').to_dict()).name.lower().replace('_',' ') if self.current_perception and self.reflex_controller and self.current_perception.get('game_state') and self.reflex_controller.get_reflex_action(self.current_perception.get('game_state').to_dict()) else None)
                            or
                            (self.navigator.suggest_exploration_action(self.current_perception.get('game_state').to_dict(), self.current_perception).name.lower().replace('_',' ') if self.current_perception and self.navigator and self.current_perception.get('game_state') else None)
                        )
                    )
                )
                # S: Planning (symbolic strategic suggestions)
                self.matrix_manager.register_executor(
                    "S-Planning",
                    lambda ctx: (
                        {'action': getattr(self, '_motor_suggestion', None).name.lower().replace('_',' ') if getattr(self, '_motor_suggestion', None) else 'look_around', 'confidence': 0.6}
                    )
                )
                # E: Planning (emergent RL/Policy)
                self.matrix_manager.register_executor(
                    "E-Planning",
                    lambda ctx: (
                        (lambda top: {'action': top[0], 'confidence': 0.65} if top else None)(
                            (lambda qv, acts: sorted([(a, qv.get(a, 0.0)) for a in acts], key=lambda x: x[1], reverse=True)[:1])(
                                (self.rl_learner.get_q_values(self.current_perception.get('game_state').to_dict()) if (self.rl_learner and self.current_perception and self.current_perception.get('game_state')) else {}),
                                (self.current_perception.get('game_state').available_actions if (self.current_perception and self.current_perception.get('game_state')) else [])
                            )
                        )
                    )
                )
            except Exception as e:
                print(f"  [MATRIX] Executor registration failed: {e}")
        except Exception as e:
            print(f"  [MATRIX/PTPL] Initialization failed: {e}")
            self.matrix_manager = None
            self.ptpl = None
        
        # 22. Enhanced Coherence Metrics (NEW - Critical)
        print("  [22/27] Enhanced coherence metrics...")
        from ..consciousness.enhanced_coherence import EnhancedCoherenceMetrics
        
        self.enhanced_coherence = EnhancedCoherenceMetrics(
            temporal_tracker=self.temporal_tracker
        )
        print("    [OK] 4D coherence measurement enabled")
        print("    [OK] Integration + Temporal + Causal + Predictive")
        
        # 23. Hierarchical Memory System (NEW - Critical)
        print("  [23/27] Hierarchical memory system...")
        from ..learning.hierarchical_memory import HierarchicalMemory
        
        self.hierarchical_memory = HierarchicalMemory(
            episodic_capacity=1000,
            consolidation_threshold=10,
            min_pattern_samples=3,
            consolidation_interval=60.0
        )
        print("    [OK] Episodic→semantic consolidation enabled")
        print("    [OK] Genuine learning from experience")
        
        # 24. Lumen Integration System (NEW)
        print("  [24/27] Lumen integration system...")
        from ..consciousness.lumen_integration import LumenIntegratedSystem
        
        self.lumen_integration = LumenIntegratedSystem()
        print("    [OK] Metaluminosity framework integrated")
        print("    [OK] Onticum + Structurale + Participatum balance tracking")
        
        # 25. Async Expert Pools (NEW - Critical)
        print("  [25/27] Async expert pools...")
        from ..llm.async_expert_pool import AsyncExpertPool, PooledExpertCaller
        
        # Will be initialized after LLM setup
        self.gemini_pool = None
        self.claude_pool = None
        self.gemini_caller = None
        self.claude_caller = None
        print("    [OK] Async expert pools configured (will initialize with LLMs)")
        
        # 26. Live Audio Stream (NEW - Real-time Commentary)
        print("  [26/28] Live audio stream...")
        from ..consciousness.live_audio_stream import LiveAudioStream, AudioStreamConfig, StreamPriority
        
        self.live_audio = None
        if self.config.enable_live_audio:
            try:
                audio_config = AudioStreamConfig(
                    enable_gemini_live=True,
                    enable_openai_realtime=True,
                    stream_frequency=5.0,
                    min_priority=StreamPriority.MEDIUM,
                    narration_style="analytical",
                    max_streams_per_minute=12,
                )
                self.live_audio = LiveAudioStream(audio_config)
                print("    [OK] Live audio stream initialized")
                print("    [OK] Gemini 2.5 Flash Live + OpenAI Realtime")
                print("    [OK] Real-time thought vocalization enabled")
            except Exception as e:
                print(f"    ⚠️ Live audio stream initialization failed: {e}")
                self.live_audio = None
        else:
            print("    ⚠️ Live audio stream disabled")
        
        # 27. Unified Metrics Aggregator
        print("  [27/28] Unified metrics aggregator...")
        self.unified_metrics = {
            'consciousness': {},
            'double_helix': {},
            'gpt5': {},
            'voice': {},
            'video': {},
            'live_audio': {},
            'performance': {},
            'temporal': {},
            'coherence': {},
            'memory': {},
            'lumen': {}
        }
        print("    [OK] Unified metrics tracking enabled")
        
        # 28. Skyrim-specific Motivation System
        print("  [28/28] Skyrim-specific motivation system...")
        self.skyrim_motivation = SkyrimMotivation(
            survival_weight=0.35,  # Prioritize staying alive
            progression_weight=0.25,  # Character growth important
            exploration_weight=0.20,  # Discover new areas
            wealth_weight=0.10,  # Gather resources
            mastery_weight=0.10  # Improve combat/stealth skills
        )

        # Skyrim-specific enhancement modules
        self.combat_tactics = SkyrimCombatTactics()
        self.quest_tracker = QuestTracker()
        self.smart_navigator = SmartNavigator()
        self.inventory_manager = InventoryManager()
        self.dialogue_intelligence = DialogueIntelligence()
        self.character_progression = CharacterProgression()
        self.crafting_system = CraftingSystem()
        self.goal_planner = HierarchicalGoalPlanner()
        self.analytics = GameplayAnalytics()
        self.meta_learner = MetaLearner()

        # 29. Motor Control Layer (Arms and Legs!)
        print("  [29/30] Motor control layer (hands and feet)...")
        from singularis.controls import (
            AffordanceExtractor,
            MotorController,
            ReflexController,
            Navigator,
            CombatController,
            MenuHandler,
        )
        
        self.affordance_extractor = AffordanceExtractor()
        self.motor_controller = MotorController(self.actions, verbose=True)
        self.reflex_controller = ReflexController(
            critical_health_threshold=15.0,
            low_health_threshold=30.0,
            danger_enemy_count=4
        )
        self.navigator = Navigator(stuck_threshold=6)
        self.combat_controller = CombatController(
            low_health_threshold=40.0,
            critical_health_threshold=25.0
        )
        self.menu_handler = MenuHandler(max_menu_time=3.0)
        print("    [OK] Motor control layer initialized")
        print("    [OK] Reflexes, navigation, combat, menu handling ready")
        
        # 30. Curriculum RL System (Progressive Learning)
        print("  [30/30] Curriculum RL system (progressive learning)...")
        from singularis.learning.curriculum_integration import CurriculumIntegration
        
        self.curriculum = CurriculumIntegration(
            coherence_weight=0.6,  # 60% coherence, 40% progress
            progress_weight=0.4,
            enable_symbolic_rules=True
        )
        print("    [OK] Curriculum RL initialized")
        print("    [OK] Progressive stages: Locomotion → Navigation → Combat")
        print("    [OK] Blends ΔC (coherence) + game progress")

        # External augmentation clients (initialized later)
        self.claude_meta_client = None
        self.gemini_vision_client = None

        # Enhanced perception utilities
        self.enhanced_vision = EnhancedVision()
        self.perception.set_enhanced_vision(self.enhanced_vision)

        # Adaptive loop scheduling
        self.loop_manager = AdaptiveLoopManager(
            LoopSettings(
                perception_interval=self.config.perception_interval,
                reasoning_throttle=self.config.reasoning_throttle,
                fast_loop_interval=self.config.fast_loop_interval
            )
        )

        # State
        self.running = False
        self.cycle_count = 0  # Track cycles for rate limiting
        self.current_perception: Optional[Dict[str, Any]] = None
        self.current_goal: Optional[str] = None
        self.last_save_time = time.time()
        self.last_state: Optional[Dict[str, Any]] = None  # For RL experience tracking
        self.last_action: Optional[str] = None
        
        # Async queues for parallel execution
        self.perception_queue: asyncio.Queue = asyncio.Queue(maxsize=5)
        self.action_queue: asyncio.Queue = asyncio.Queue(maxsize=self.config.action_queue_size)
        self.learning_queue: asyncio.Queue = asyncio.Queue(maxsize=10)
        self.fast_action_queue: asyncio.Queue = asyncio.Queue(maxsize=5)  # Fast reactive actions
        
        # Resource management for async execution
        self.llm_semaphore: Optional[asyncio.Semaphore] = None  # Limit concurrent LLM calls
        self.last_reasoning_time: float = 0.0  # Track last reasoning to throttle
        
        # Multi-LLM architecture (initialized in initialize_llm)
        # Mistral Nemo for fast consciousness/tactical reasoning
        self.action_planning_llm: Optional[Any] = None  # mistral-nemo: Fast action planning
        # 2x big models for high-level strategic planning
        self.strategic_planning_llm: Optional[Any] = None  # Big model: Long-term strategy
        self.world_understanding_llm: Optional[Any] = None  # Big model: Deep world understanding
        self.state_printer_llm: Optional[Any] = None  # Phi-4: Internal state printing and analysis

        # Statistics
        self.stats = {
            'cycles_completed': 0,
            'actions_taken': 0,
            'locations_discovered': 0,
            'npcs_met': 0,
            'quests_completed': 0,
            'total_playtime': 0.0,
            'game_state_quality_history': [],  # Replaces coherence_history
            # Performance metrics
            'action_success_count': 0,
            'action_failure_count': 0,
            'llm_action_count': 0,
            'heuristic_action_count': 0,
            'rl_action_count': 0,
            'fast_action_count': 0,  # Fast reactive actions
            'planning_times': [],  # Track planning duration
            'execution_times': [],  # Track execution duration
            'fast_action_times': [],  # Track fast action execution
            # Action source tracking (which system provided the action)
            'action_source_moe': 0,  # MoE consensus
            'action_source_hybrid': 0,  # Hybrid LLM
            'action_source_phi4': 0,  # Phi-4 planner
            'action_source_local_moe': 0,  # Local MoE
            'action_source_heuristic': 0,  # Heuristic fallback
            'action_source_timeout': 0,  # Timeout fallback
            'random_academic_thoughts': 0,  # Brownian motion memory retrievals
            'bdh_policy_adjustments': 0,
            # Phase 1.2: Action validation stats
            'action_rejected_count': 0,  # Total rejected actions
            'action_rejected_stale': 0,  # Rejected due to stale perception
            'action_rejected_context': 0,  # Rejected due to context mismatch
        }
        
        # Last successful action source (for caching fast path)
        self.last_action_source: Optional[str] = None
        
        # Phase 2.3: Action Arbiter - Single point of action execution
        print("  [PHASE 2] Initializing Action Arbiter...")
        from .action_arbiter import ActionArbiter, ActionPriority
        self.bdh_policy_head = BDHPolicyHead()
        self.bdh_meta_cortex = BDHMetaCortex()
        self.action_arbiter = ActionArbiter(self, meta_cortex=self.bdh_meta_cortex)
        self.ActionPriority = ActionPriority  # Make enum accessible
        print("    [OK] Action Arbiter initialized with priority system")

        # Set up controller reference in perception for layer awareness
        self.perception.set_controller(self.controller)
        
        # State tracking for consciousness
        self.current_consciousness: Optional[ConsciousnessState] = None
        self.last_consciousness: Optional[ConsciousnessState] = None
        
        # System-wide consciousness monitor
        print("  [12/12] System consciousness monitor...")
        self.consciousness_monitor = SystemConsciousnessMonitor(history_size=1000)
        self._register_consciousness_nodes()
        
        # State coordinator (resolves subsystem conflicts)
        print("  [13/13] State coordination system...")
        from .state_coordinator import StateCoordinator
        self.state_coordinator = StateCoordinator(
            staleness_threshold=2.0,
            conflict_history_size=100
        )
        print("[STATE-COORD] Epistemic coherence tracking enabled")
        print("[STATE-COORD] Subsystem state mismatches will be detected and resolved")
        
        # Stuck detection and recovery (multi-tier failsafe)
        self.stuck_detection_window = 5  # Check last N actions
        self.action_history = []  # Track recent actions
        self.coherence_history = []  # Track recent coherence values
        self.stuck_threshold = 0.02  # Coherence change threshold
        self.consecutive_same_action = 0  # Count same action repeats
        self.last_executed_action = None
        
        # STUCK Recovery Tracker (monitors if unstick actions work)
        from .stuck_recovery_tracker import StuckRecoveryTracker
        self.stuck_tracker = StuckRecoveryTracker(
            verification_cycles=3,
            max_history=100
        )
        print("[STUCK-TRACKER] Recovery monitoring enabled")
        print("[STUCK-TRACKER] Will verify if unstick actions change visual state")
        
        # Action diversity tracking (GPT-4o recommendation)
        self.action_type_counts = {}  # Track frequency of each action type
        self.reward_by_action_type = {}  # Track avg reward per action type
        self.recent_action_types = []  # Track action types for pattern analysis
        
        # GPT-5-thinking world model tracking
        self.last_world_model_narrative = None  # Track for consciousness measurement
        
        # Advanced stuck detection
        self.position_history = []  # Track player positions (if available)
        self.visual_embedding_history = []  # Track visual embeddings
        self.stuck_recovery_attempts = 0  # Count recovery attempts
        self.last_stuck_detection_time = 0  # Prevent spam
        self.stuck_detection_cooldown = 10.0  # Seconds between detections

        # Sensorimotor feedback tracking
        self.sensorimotor_state: Optional[Dict[str, Any]] = None
        
        # Performance dashboard (Fix 20)
        self.dashboard_update_interval = 5
        self.dashboard_last_update = 0
        
        # Dashboard streamer for real-time webapp monitoring
        print("  [13/13] Dashboard streamer for real-time webapp...")
        from singularis.skyrim.dashboard_streamer import DashboardStreamer
        self.dashboard_streamer = DashboardStreamer(
            output_path="skyrim_agi_state.json",
            max_history=100
        )
        
        # LLM decision tracking (Fix 11&12)
        self.stats['llm_queued_requests'] = 0
        self.stats['llm_skipped_rate_limit'] = 0
        self.stats['llm_decision_rejections'] = 0
        self.sensorimotor_similarity_streak: int = 0
        self.sensorimotor_last_cycle: int = -1
        self.sensorimotor_high_similarity_threshold: float = 0.90
        self.sensorimotor_required_streak: int = 3
        
        print("Skyrim AGI initialization complete.")
        print("[OK] Skyrim AGI initialized with CONSCIOUSNESS INTEGRATION\n")


    def _register_consciousness_nodes(self) -> None:
        """Registers all major subsystems with the SystemConsciousnessMonitor.

        This allows the monitor to track the coherence and contribution of each
        component to the overall consciousness of the AGI.
        """
        # Perception nodes
        self.consciousness_monitor.register_node(
            "perception_vision", "perception", weight=1.5,
            metadata={'description': 'Visual perception and scene understanding'}
        )
        self.consciousness_monitor.register_node(
            "perception_gamestate", "perception", weight=1.0,
            metadata={'description': 'Game state extraction'}
        )
        
        # Action nodes
        self.consciousness_monitor.register_node(
            "action_planning", "action", weight=1.5,
            metadata={'description': 'Action planning and selection'}
        )
        self.consciousness_monitor.register_node(
            "action_execution", "action", weight=1.0,
            metadata={'description': 'Action execution'}
        )
        
        # Learning nodes
        self.consciousness_monitor.register_node(
            "world_model", "learning", weight=1.5,
            metadata={'description': 'World model and causal learning'}
        )
        self.consciousness_monitor.register_node(
            "rl_system", "learning", weight=1.3,
            metadata={'description': 'Reinforcement learning'}
        )
        self.consciousness_monitor.register_node(
            "cloud_rl", "learning", weight=1.2,
            metadata={'description': 'Cloud-enhanced RL with RAG'}
        )
        
        # Strategic nodes
        self.consciousness_monitor.register_node(
            "strategic_planner", "strategy", weight=1.4,
            metadata={'description': 'Strategic planning neuron'}
        )
        self.consciousness_monitor.register_node(
            "meta_strategist", "strategy", weight=1.3,
            metadata={'description': 'Meta-strategic coordination'}
        )
        
        # LLM nodes (will be registered after initialization)
        # These will be added dynamically based on configuration
        
        # Consciousness bridge
        self.consciousness_monitor.register_node(
            "consciousness_bridge", "consciousness", weight=2.0,
            metadata={'description': 'Consciousness integration bridge'}
        )
        
        # Memory systems
        self.consciousness_monitor.register_node(
            "memory_rag", "memory", weight=1.0,
            metadata={'description': 'Memory RAG system'}
        )
        
        if self.curriculum_rag:
            self.consciousness_monitor.register_node(
                "curriculum_rag", "knowledge", weight=1.2,
                metadata={'description': 'Academic knowledge from university curriculum'}
            )
        
        # Game-specific systems
        self.consciousness_monitor.register_node(
            "combat_tactics", "game", weight=0.8,
            metadata={'description': 'Combat tactics system'}
        )
        self.consciousness_monitor.register_node(
            "quest_tracker", "game", weight=0.7,
            metadata={'description': 'Quest tracking'}
        )
        self.consciousness_monitor.register_node(
            "navigation", "game", weight=0.6,
            metadata={'description': 'Smart navigation'}
        )
        
        logger.info(f"Registered {len(self.consciousness_monitor.registered_nodes)} consciousness nodes")
    
    def _register_llm_nodes(self) -> None:
        """Dynamically registers the configured LLM experts with the consciousness monitor."""
        if self.moe:
            # Register MoE experts
            for i in range(self.config.num_gemini_experts):
                self.consciousness_monitor.register_node(
                    f"moe_gemini_{i+1}", "llm_vision", weight=0.5,
                    metadata={'description': f'Gemini expert {i+1}', 'model': 'gemini'}
                )
            
            for i in range(self.config.num_claude_experts):
                self.consciousness_monitor.register_node(
                    f"moe_claude_{i+1}", "llm_reasoning", weight=0.7,
                    metadata={'description': f'Claude expert {i+1}', 'model': 'claude'}
                )
            
            self.consciousness_monitor.register_node(
                "moe_consensus", "llm_meta", weight=1.5,
                metadata={'description': 'MoE consensus mechanism'}
            )
        
        if self.hybrid_llm:
            self.consciousness_monitor.register_node(
                "hybrid_vision", "llm_vision", weight=1.0,
                metadata={'description': 'Hybrid Gemini vision'}
            )
            self.consciousness_monitor.register_node(
                "hybrid_reasoning", "llm_reasoning", weight=1.2,
                metadata={'description': 'Hybrid Claude reasoning'}
            )
            
            # Register GPT-5-thinking world model synthesis node
            if hasattr(self.hybrid_llm, 'openai') and self.hybrid_llm.openai:
                self.consciousness_monitor.register_node(
                    "gpt5_world_model_synthesis", "llm_meta", weight=2.0,
                    metadata={
                        'description': 'GPT-5-thinking unified consciousness synthesis',
                        'model': 'gpt-5-thinking',
                        'role': 'Integrates ALL perspectives into unified self-referential narrative'
                    }
                )
        
        logger.info(f"Registered LLM nodes, total: {len(self.consciousness_monitor.registered_nodes)}")
    
    async def measure_system_consciousness(self) -> SystemConsciousnessState:
        """Measures and aggregates the consciousness state across the entire AGI system.

        This method queries each registered subsystem to get its current coherence
        and other consciousness-related metrics. It then uses the
        `SystemConsciousnessMonitor` to compute a global consciousness state,
        including overall coherence, integration (Φ), and unity.

        Returns:
            A `SystemConsciousnessState` object representing the holistic state of the AGI.
        """
        node_measurements = {}
        
        # Measure perception coherence
        if self.current_perception:
            # Vision coherence based on confidence
            vision_coherence = self.current_perception.get('confidence', 0.5)
            node_measurements['perception_vision'] = self.consciousness_monitor.measure_node_coherence(
                'perception_vision',
                coherence=vision_coherence,
                unity=0.8,  # Aligned with perception goals
                integration=0.7,  # Integrates with action planning
                differentiation=0.9,  # Specialized for vision
                confidence=vision_coherence,
                activity_level=1.0,
            )
            
            # Game state coherence
            gamestate_coherence = 0.8 if self.current_perception.get('game_state') else 0.3
            node_measurements['perception_gamestate'] = self.consciousness_monitor.measure_node_coherence(
                'perception_gamestate',
                coherence=gamestate_coherence,
                unity=0.7,
                integration=0.8,
                differentiation=0.8,
            )
        
        # Measure action coherence
        if self.last_action:
            action_coherence = 0.7  # Default
            node_measurements['action_planning'] = self.consciousness_monitor.measure_node_coherence(
                'action_planning',
                coherence=action_coherence,
                unity=0.8,
                integration=0.9,  # Highly integrated with perception
                differentiation=0.7,
            )
            node_measurements['action_execution'] = self.consciousness_monitor.measure_node_coherence(
                'action_execution',
                coherence=0.8,
                unity=0.9,
                integration=0.6,
                differentiation=0.8,
            )
        
        # Measure learning coherence
        if self.rl_learner:
            rl_coherence = 0.6  # Based on exploration vs exploitation
            node_measurements['rl_system'] = self.consciousness_monitor.measure_node_coherence(
                'rl_system',
                coherence=rl_coherence,
                unity=0.7,
                integration=0.8,
                differentiation=0.9,
            )
        
        if self.cloud_rl_memory:
            stats = self.cloud_rl_memory.get_stats()
            cloud_rl_coherence = min(1.0, stats.get('avg_coherence_delta', 0.0) + 0.5)
            node_measurements['cloud_rl'] = self.consciousness_monitor.measure_node_coherence(
                'cloud_rl',
                coherence=cloud_rl_coherence,
                unity=0.8,
                integration=0.9,
                differentiation=0.8,
            )
        
        # Measure world model coherence
        world_coherence = 0.7  # Based on causal model quality
        node_measurements['world_model'] = self.consciousness_monitor.measure_node_coherence(
            'world_model',
            coherence=world_coherence,
            unity=0.8,
            integration=0.9,
            differentiation=0.9,
        )
        
        # Measure strategic coherence
        node_measurements['strategic_planner'] = self.consciousness_monitor.measure_node_coherence(
            'strategic_planner',
            coherence=0.75,
            unity=0.9,
            integration=0.8,
            differentiation=0.8,
        )
        
        node_measurements['meta_strategist'] = self.consciousness_monitor.measure_node_coherence(
            'meta_strategist',
            coherence=0.8,
            unity=0.9,
            integration=0.9,
            differentiation=0.7,
        )
        
        # Measure GPT-5-thinking world model synthesis consciousness
        if hasattr(self, 'last_world_model_narrative') and self.last_world_model_narrative:
            # Calculate consciousness score for the world model synthesis
            from ..consciousness.measurement import ConsciousnessMeasurement
            consciousness_measure = ConsciousnessMeasurement()
            
            # Measure consciousness of the unified narrative
            world_model_consciousness = consciousness_measure.measure(
                content=self.last_world_model_narrative,
                query="unified consciousness synthesis",
                lumen_focus="participatum"
            )
            
            # Extract overall consciousness score
            wm_consciousness_score = world_model_consciousness.overall_consciousness
            
            node_measurements['gpt5_world_model_synthesis'] = self.consciousness_monitor.measure_node_coherence(
                'gpt5_world_model_synthesis',
                coherence=wm_consciousness_score,  # Use measured consciousness as coherence
                unity=0.95,  # Very high - unifies all perspectives
                integration=1.0,  # Maximum integration - synthesizes everything
                differentiation=0.85,  # High - creates unique phenomenological narrative
                confidence=wm_consciousness_score,
                activity_level=1.0 if self.last_world_model_narrative else 0.0,
            )
        
        # Measure consciousness bridge
        if self.current_consciousness:
            bridge_coherence = getattr(self.current_consciousness, 'coherence', 0.7)
            node_measurements['consciousness_bridge'] = self.consciousness_monitor.measure_node_coherence(
                'consciousness_bridge',
                coherence=bridge_coherence,
                unity=1.0,  # Central to system unity
                integration=1.0,  # Integrates everything
                differentiation=0.6,  # Less specialized
            )
        
        # Measure MoE if active
        if self.moe:
            moe_stats = self.moe.get_stats()
            moe_coherence = moe_stats.get('avg_coherence', 0.7)
            
            # MoE consensus
            node_measurements['moe_consensus'] = self.consciousness_monitor.measure_node_coherence(
                'moe_consensus',
                coherence=moe_coherence,
                unity=0.9,
                integration=0.9,
                differentiation=0.7,
            )
            
            # Individual experts (sample a few)
            for i in range(min(3, self.config.num_gemini_experts)):
                node_measurements[f'moe_gemini_{i+1}'] = self.consciousness_monitor.measure_node_coherence(
                    f'moe_gemini_{i+1}',
                    coherence=0.7 + (i * 0.05),  # Slight variation
                    unity=0.6,
                    integration=0.5,
                    differentiation=0.9,
                )
            
            for i in range(min(2, self.config.num_claude_experts)):
                node_measurements[f'moe_claude_{i+1}'] = self.consciousness_monitor.measure_node_coherence(
                    f'moe_claude_{i+1}',
                    coherence=0.75 + (i * 0.05),
                    unity=0.7,
                    integration=0.6,
                    differentiation=0.9,
                )
        
        # Measure hybrid LLM if active
        if self.hybrid_llm:
            hybrid_stats = self.hybrid_llm.get_stats()
            hybrid_coherence = hybrid_stats.get('primary_success_rate', 0.8)
            
            node_measurements['hybrid_vision'] = self.consciousness_monitor.measure_node_coherence(
                'hybrid_vision',
                coherence=hybrid_coherence,
                unity=0.8,
                integration=0.7,
                differentiation=0.9,
            )
            
            node_measurements['hybrid_reasoning'] = self.consciousness_monitor.measure_node_coherence(
                'hybrid_reasoning',
                coherence=hybrid_coherence,
                unity=0.8,
                integration=0.8,
                differentiation=0.9,
            )
        
        # Measure game systems
        node_measurements['combat_tactics'] = self.consciousness_monitor.measure_node_coherence(
            'combat_tactics',
            coherence=0.7,
            unity=0.7,
            integration=0.6,
            differentiation=0.9,
        )
        
        node_measurements['quest_tracker'] = self.consciousness_monitor.measure_node_coherence(
            'quest_tracker',
            coherence=0.6,
            unity=0.6,
            integration=0.5,
            differentiation=0.8,
        )
        
        # Compute system state
        system_state = self.consciousness_monitor.compute_system_state(node_measurements)
        
        return system_state
    
    async def initialize_llm(self) -> None:
        """Initializes the multi-faceted LLM architecture.

        This complex method sets up the AGI's "brain," which can be configured
        to run in several modes:
        - **Hybrid Mode:** Uses a combination of cloud-based models (like Gemini for
          vision and Claude for reasoning) with an optional local fallback.
        - **Mixture of Experts (MoE) Mode:** Utilizes an orchestrator to query
          multiple specialized LLM experts in parallel and synthesize their responses.
        - **Parallel Mode:** Runs both Hybrid and MoE modes simultaneously,
          blending their outputs for maximum intelligence.

        It also handles the initialization and connection of various auxiliary LLM-based
        subsystems, such as the consciousness bridge, RL reasoning neuron, and
        meta-strategist, to the appropriate LLM interfaces.
        """
        print("=" * 70)
        print("INITIALIZING HYBRID LLM ARCHITECTURE")
        print("=" * 70)
        print("Primary: Gemini 2.0 Flash (vision) + Claude Sonnet 4 (reasoning)")
        if self.config.use_local_fallback:
            print("Fallback: Local LLMs (optional)")
        else:
            print("Fallback: Disabled")
        print("=" * 70)
        print()
        
        # ===== PARALLEL MODE: MoE + Hybrid =====
        if self.config.use_parallel_mode:
            print("\n[PARALLEL] Initializing PARALLEL mode: MoE + Hybrid simultaneously")
            print("[PARALLEL] This provides maximum intelligence by combining:")
            print("[PARALLEL]   - MoE: 6 expert consensus (2 Gemini + 1 Claude + 1 GPT-4o + 1 Nemotron + 1 Qwen3)")
            print("[PARALLEL]   - Hybrid: Single Gemini + Claude for speed")
            print()
            
            # Initialize MoE
            try:
                logger.info("Initializing MoE component...")
                self.moe = MoEOrchestrator(
                    num_gemini_experts=self.config.num_gemini_experts,
                    num_claude_experts=self.config.num_claude_experts,
                    gemini_model=self.config.gemini_model,
                    claude_model=self.config.claude_model,
                    gemini_rpm_limit=self.config.gemini_rpm_limit,
                    claude_rpm_limit=self.config.claude_rpm_limit,
                )
                await self.moe.initialize()
                print("[PARALLEL] [OK] MoE component ready")
                await self._connect_moe()
            except Exception as e:
                print(f"[PARALLEL] ⚠️ MoE initialization failed: {e}")
                self.moe = None
            
            # Initialize Hybrid
            try:
                logger.info("Initializing Hybrid component...")
                hybrid_config = HybridConfig(
                    use_gemini_vision=self.config.use_gemini_vision,
                    gemini_model=self.config.gemini_model,
                    use_claude_reasoning=self.config.use_claude_reasoning,
                    claude_model=self.config.claude_model,
                    use_local_fallback=self.config.use_local_fallback,
                    local_base_url="http://localhost:1234/v1",  # LM Studio default
                    local_vision_model=self.config.qwen3_vl_perception_model,
                    local_reasoning_model=self.config.huihui_cognition_model,
                    local_action_model=self.config.phi4_action_model,
                    timeout=30,
                    max_concurrent_requests=self.config.max_concurrent_llm_calls,
                )
                
                self.hybrid_llm = HybridLLMClient(hybrid_config)
                await self.hybrid_llm.initialize()
                print("[PARALLEL] [OK] Hybrid component ready")
                await self._connect_hybrid_llm()
                
                # Initialize Emotion System LLM
                try:
                    await self.emotion_integration.initialize_llm()
                    print("[PARALLEL] [OK] Emotion system LLM ready (HuiHui)")
                except Exception as e:
                    print(f"[PARALLEL] ⚠️ Emotion LLM initialization failed: {e}")
                    print("[PARALLEL]   Continuing with rule-based emotion system")
                
                # Initialize Realtime Coordinator
                if self.realtime_coordinator:
                    try:
                        await self.realtime_coordinator.connect()
                        print("[PARALLEL] [OK] Realtime coordinator connected (GPT-4 Realtime API)")
                    except Exception as e:
                        print(f"[PARALLEL] ⚠️ Realtime coordinator connection failed: {e}")
                        print("[PARALLEL]   Continuing without realtime coordination")
                        self.realtime_coordinator = None
                
                # Initialize Self-Reflection System
                if self.self_reflection:
                    try:
                        await self.self_reflection.connect()
                        print("[PARALLEL] [OK] Self-reflection system connected (GPT-4 Realtime)")
                    except Exception as e:
                        print(f"[PARALLEL] ⚠️ Self-reflection connection failed: {e}")
                        self.self_reflection = None
                
                # Initialize Reward-Guided Tuning with Claude Sonnet 4.5
                if self.config.use_reward_tuning and self.sensorimotor_llm:
                    try:
                        from ..learning.reward_guided_tuning import RewardGuidedTuning
                        self.reward_tuning = RewardGuidedTuning(self.sensorimotor_llm)
                        print("[PARALLEL] [OK] Reward-guided tuning initialized (Claude Sonnet 4.5)")
                    except Exception as e:
                        print(f"[PARALLEL] ⚠️ Reward tuning initialization failed: {e}")
                        self.reward_tuning = None
                
                # Also initialize local LLM references if fallback enabled
                if self.config.use_local_fallback and self.hybrid_llm.local_reasoning:
                    print("[PARALLEL] [OK] Local LLM fallback available")
                    self.huihui_llm = self.hybrid_llm.local_reasoning
                    self.perception_llm = self.hybrid_llm.local_vision
                    self.action_planning_llm = self.hybrid_llm.local_action
                    
                    # Connect local LLMs to components
                    self.rl_reasoning_neuron.llm_interface = self.huihui_llm
                    self.strategic_planner.llm_interface = self.huihui_llm
                    
                    # Initialize Meta-Strategist with Mistral-7B
                    mistral_config = LMStudioConfig(
                        base_url="http://localhost:1234/v1",
                        model_name="mistralai/mistral-7b-instruct-v0.3",
                        temperature=0.7,
                        max_tokens=1024
                    )
                    mistral_client = LMStudioClient(mistral_config)
                    mistral_interface = ExpertLLMInterface(mistral_client)
                    self.meta_strategist.llm_interface = mistral_interface
                    print("[PARALLEL] [OK] Meta-Strategist using Mistral-7B")
                    
                    # Connect Huihui to AGI orchestrator as consciousness LLM
                    # This enables full Singularis dialectical reasoning
                    self.agi.consciousness_llm = self.huihui_llm
                    self.consciousness_bridge.consciousness_llm = self.huihui_llm
                    
                    # Initialize state printer LLM (microsoft/phi-4)
                    state_printer_config = LMStudioConfig(
                        base_url="http://localhost:1234/v1",
                        model_name="microsoft/phi-4",
                        temperature=0.5,
                        max_tokens=1024
                    )
                    state_printer_client = LMStudioClient(state_printer_config)
                    self.state_printer_llm = ExpertLLMInterface(state_printer_client)
                    
                    # Run health check for local LLMs
                    print("\n[PARALLEL] Running LM Studio health check...")
                    if await state_printer_client.health_check():
                        print("[PARALLEL] [OK] LM Studio connection verified")
                    else:
                        print("[PARALLEL] ⚠️ LM Studio health check failed - local models may not work")
                        print("[PARALLEL] Please ensure:")
                        print("[PARALLEL]   1. LM Studio is running")
                        print("[PARALLEL]   2. Local server is started (Server tab)")
                        print("[PARALLEL]   3. A model is loaded")
                    
                    print("[PARALLEL] [OK] Huihui connected to AGI orchestrator (enables dialectical synthesis)")
                    print("[PARALLEL] [OK] State printer LLM connected (microsoft/phi-4)")
                    print("[PARALLEL] [OK] Local LLMs connected to components")
                    
            except Exception as e:
                print(f"[PARALLEL] ⚠️ Hybrid initialization failed: {e}")
                self.hybrid_llm = None
            
            # Initialize Local MoE as additional fallback
            try:
                from singularis.llm.local_moe import LocalMoEOrchestrator, LocalMoEConfig
                
                print("\n[PARALLEL] Initializing Local MoE fallback...")
                local_moe_config = LocalMoEConfig(
                    num_experts=4,
                    expert_model="microsoft/phi-4-mini-reasoning",  # Use phi-4-mini instances 1-4
                    synthesizer_model="microsoft/phi-4-mini-reasoning",  # Use phi-4-mini for synthesis (fast, reliable)
                    fallback_synthesizer="mistralai/mistral-nemo-instruct-2407",  # Fallback if phi-4 fails
                    base_url="http://localhost:1234/v1",
                    timeout=25,  # Increased for better reliability
                    synthesis_timeout=15,
                    max_tokens=1024
                )
                
                self.local_moe = LocalMoEOrchestrator(local_moe_config)
                await self.local_moe.initialize()
                print("[PARALLEL] [OK] Local MoE fallback ready (4x Phi-4-mini + Phi-4-mini synthesizer + Mistral fallback)")
            except Exception as e:
                print(f"[PARALLEL] ⚠️ Local MoE initialization failed: {e}")
                self.local_moe = None
            
            print(f"\n[PARALLEL] [OK] Parallel mode active")
            print(f"[PARALLEL] Consensus weights: MoE={self.config.parallel_consensus_weight_moe}, Hybrid={self.config.parallel_consensus_weight_hybrid}")
            if hasattr(self, 'local_moe') and self.local_moe:
                print(f"[PARALLEL] Local MoE fallback: ENABLED")
        
        # ===== MIXTURE OF EXPERTS (MoE) ONLY =====
        elif self.config.use_moe:
            try:
                logger.info("Initializing Mixture of Experts (MoE) system...")
                logger.info(f"  {self.config.num_gemini_experts} Gemini experts")
                logger.info(f"  {self.config.num_claude_experts} Claude experts")
                
                self.moe = MoEOrchestrator(
                    num_gemini_experts=self.config.num_gemini_experts,
                    num_claude_experts=self.config.num_claude_experts,
                    gemini_model=self.config.gemini_model,
                    claude_model=self.config.claude_model,
                    gemini_rpm_limit=self.config.gemini_rpm_limit,
                    claude_rpm_limit=self.config.claude_rpm_limit,
                )
                
                await self.moe.initialize()
                
                print("\n[MoE] [OK] Mixture of Experts system initialized successfully")
                print(f"[MoE] Total experts: {self.config.num_gemini_experts + self.config.num_claude_experts}")
                print(f"[MoE] Rate limits: Gemini {self.config.gemini_rpm_limit} RPM, Claude {self.config.claude_rpm_limit} RPM")
                
                # Connect MoE to components
                await self._connect_moe()
                
            except Exception as e:
                print(f"[MoE] ⚠️ Failed to initialize MoE system: {e}")
                import traceback
                traceback.print_exc()
                self.moe = None
        
        # ===== HYBRID LLM SYSTEM ONLY =====
        elif self.config.use_hybrid_llm:
            try:
                # Configure hybrid system
                hybrid_config = HybridConfig(
                    use_gemini_vision=self.config.use_gemini_vision,
                    gemini_model=self.config.gemini_model,
                    use_claude_reasoning=self.config.use_claude_reasoning,
                    claude_model=self.config.claude_model,
                    use_local_fallback=self.config.use_local_fallback,
                    local_base_url="http://localhost:1234/v1",  # LM Studio default
                    local_vision_model=self.config.qwen3_vl_perception_model,
                    local_reasoning_model=self.config.huihui_cognition_model,
                    local_action_model=self.config.phi4_action_model,
                    timeout=30,
                    max_concurrent_requests=self.config.max_concurrent_llm_calls,
                )
                
                # Initialize hybrid client
                self.hybrid_llm = HybridLLMClient(hybrid_config)
                await self.hybrid_llm.initialize()
                
                print("\n[HYBRID] [OK] Hybrid LLM system initialized successfully")
                
                # Connect hybrid system to all components
                await self._connect_hybrid_llm()
                
            except Exception as e:
                print(f"[HYBRID] ⚠️ Failed to initialize hybrid system: {e}")
                import traceback
                traceback.print_exc()
                self.hybrid_llm = None
        else:
            print("[HYBRID] Hybrid LLM system disabled, using legacy architecture")
            # Fall back to legacy initialization if needed
            await self._initialize_legacy_llms()
        
        print("\n" + "=" * 70)
        print("LLM ARCHITECTURE READY")
        print("=" * 70)
        if self.hybrid_llm:
            print("[OK] Hybrid system active: Gemini (vision) + Claude Sonnet 4 (reasoning)")
            if self.config.use_local_fallback:
                print("[OK] Local fallback enabled")
        if self.moe:
            print("[OK] MoE system active: 2 Gemini + 1 Claude + 1 GPT-4o + 1 Nemotron + 1 Qwen3")
        print("Async execution for parallel processing")
        print("=" * 70)
        print()
        
        # ===== CLOUD-ENHANCED RL SYSTEM =====
        if self.config.use_cloud_rl:
            await self._initialize_cloud_rl()
        
        # ===== REGISTER LLM NODES FOR CONSCIOUSNESS MONITORING =====
        self._register_llm_nodes()
        
        print("\n" + "=" * 70)
        print("FULL SYSTEM INITIALIZATION COMPLETE")
        print("=" * 70)
        print()
        
        # Visual analysis cache for temporal binding
        self._last_gemini_visual = None
        self._last_local_visual = None
        self._last_hyperbolic_visual = None
        self._last_video_interpretation = None
        
        # Start live audio stream if enabled
        if self.live_audio:
            print("\n" + "=" * 70)
            print("STARTING LIVE AUDIO STREAM")
            print("=" * 70)
            try:
                await self.live_audio.initialize()
                await self.live_audio.start()
                print("[OK] Live audio stream active")
                print()
            except Exception as e:
                print(f"⚠️ Failed to start live audio stream: {e}")
                self.live_audio = None
        
        # Measure initial consciousness state
        print("\n" + "=" * 70)
        print("INITIAL CONSCIOUSNESS MEASUREMENT")
        print("=" * 70)
        initial_state = await self.measure_system_consciousness()
        self.consciousness_monitor.print_dashboard()
        print()

    async def _connect_moe(self) -> None:
        """Connects the Mixture of Experts (MoE) system to all relevant AGI components.

        This method sets the `moe` attribute on various subsystems, allowing them
        to leverage the MoE for their LLM-based tasks.
        """
        if not self.moe:
            return
        
        print("\n[MoE] Connecting to AGI components...")
        
        # Connect to perception for vision tasks
        if hasattr(self.perception, 'set_moe'):
            self.perception.set_moe(self.moe)
            print("[MoE] [OK] Connected to perception system")
        
        # Connect to strategic planner for reasoning
        if self.strategic_planner and hasattr(self.strategic_planner, 'set_moe'):
            self.strategic_planner.set_moe(self.moe)
            self.strategic_planner.set_parallel_agi(self)
            print("[MoE] [OK] Connected to strategic planner")
        
        # Connect to meta-strategist
        if hasattr(self.meta_strategist, 'set_moe'):
            self.meta_strategist.set_moe(self.moe)
            print("[MoE] [OK] Connected to meta-strategist")
        
        # Connect to RL reasoning neuron
        if hasattr(self.rl_reasoning_neuron, 'set_moe'):
            self.rl_reasoning_neuron.set_moe(self.moe)
            print("[MoE] [OK] Connected to RL reasoning neuron")
        
        # Connect to world model
        if hasattr(self.skyrim_world, 'set_moe'):
            self.skyrim_world.set_moe(self.moe)
            print("[MoE] [OK] Connected to world model")
        
        # Connect to consciousness bridge
        if hasattr(self.consciousness_bridge, 'set_moe'):
            self.consciousness_bridge.set_moe(self.moe)
            print("[MoE] [OK] Connected to consciousness bridge")
        
        # Connect to quest tracker and dialogue
        if hasattr(self.quest_tracker, 'set_moe'):
            self.quest_tracker.set_moe(self.moe)
            print("[MoE] [OK] Connected to quest tracker")
        
        if hasattr(self.dialogue_intelligence, 'set_moe'):
            self.dialogue_intelligence.set_moe(self.moe)
            print("[MoE] [OK] Connected to dialogue intelligence")
        
        print("[MoE] Component connection complete\n")
    
    async def _connect_hybrid_llm(self) -> None:
        """Connects the Hybrid LLM system to all relevant AGI components.

        This method sets the `hybrid_llm` attribute on various subsystems,
        allowing them to use the hybrid client for their LLM tasks. It also
        handles the registration of subsystems with the GPT-5 orchestrator and
        initializes the Wolfram Alpha telemetry analyzer.
        """
        if not self.hybrid_llm:
            return
        
        print("\n[HYBRID] Connecting to AGI components...")
        
        # Connect to perception for vision tasks
        if hasattr(self.perception, 'set_hybrid_llm'):
            self.perception.set_hybrid_llm(self.hybrid_llm)
            print("[HYBRID] [OK] Connected to perception system")
        
        # Connect to strategic planner for reasoning
        if self.strategic_planner and hasattr(self.strategic_planner, 'set_hybrid_llm'):
            self.strategic_planner.set_hybrid_llm(self.hybrid_llm)
            self.strategic_planner.set_parallel_agi(self)
            print("[HYBRID] [OK] Connected to strategic planner")
        
        # Connect to meta-strategist
        if hasattr(self.meta_strategist, 'set_hybrid_llm'):
            self.meta_strategist.set_hybrid_llm(self.hybrid_llm)
            print("[HYBRID] [OK] Connected to meta-strategist")
        
        # Connect to RL reasoning neuron
        if hasattr(self.rl_reasoning_neuron, 'set_hybrid_llm'):
            self.rl_reasoning_neuron.set_hybrid_llm(self.hybrid_llm)
            print("[HYBRID] [OK] Connected to RL reasoning neuron")
        
        # Connect to world model
        if hasattr(self.skyrim_world, 'set_hybrid_llm'):
            self.skyrim_world.set_hybrid_llm(self.hybrid_llm)
            print("[HYBRID] [OK] Connected to world model")
        
        # Connect to consciousness bridge
        if hasattr(self.consciousness_bridge, 'set_hybrid_llm'):
            self.consciousness_bridge.set_hybrid_llm(self.hybrid_llm)
            print("[HYBRID] [OK] Connected to consciousness bridge")
        
        # Connect to quest tracker and dialogue
        if hasattr(self.quest_tracker, 'set_hybrid_llm'):
            self.quest_tracker.set_hybrid_llm(self.hybrid_llm)
            print("[HYBRID] [OK] Connected to quest tracker")
        
        if hasattr(self.dialogue_intelligence, 'set_hybrid_llm'):
            self.dialogue_intelligence.set_hybrid_llm(self.hybrid_llm)
            print("[HYBRID] [OK] Connected to dialogue intelligence")
        
        print("[HYBRID] Component connection complete\n")
        
        # Register all systems with GPT-5 orchestrator
        await self._register_systems_with_gpt5()
        
        # Initialize Wolfram Alpha telemetry analyzer
        await self._initialize_wolfram_telemetry()
        
        # Start video interpreter streaming
        if self.video_interpreter:
            await self.video_interpreter.start_streaming()
            print("[VIDEO] Streaming started\n")
    
    def _update_being_state_comprehensive(self, cycle_count: int, game_state: Any, perception: Dict[str, Any], current_consciousness: Any, mot_state: Any, action: Any) -> None:
        """Updates the central `BeingState` with data from all subsystems.

        This method acts as a convergence point, collecting the latest information
        from perception, consciousness, emotion, motivation, RL, and other systems
        to create a single, unified snapshot of the AGI's current state of being.

        Args:
            cycle_count: The current main loop cycle number.
            game_state: The current state of the game.
            perception: The latest perception data.
            current_consciousness: The latest consciousness measurement.
            mot_state: The current motivation state.
            action: The action that was just taken or is being planned.
        """
        if not hasattr(self, 'being_state'):
            return
        
        # Temporal
        self.being_state.cycle_number = cycle_count
        self.being_state.timestamp = time.time()
        
        # Game/World/Body
        self.being_state.game_state = game_state.to_dict() if hasattr(game_state, 'to_dict') else game_state
        self.being_state.current_perception = perception
        self.being_state.last_action = str(action) if action else None
        
        # Consciousness
        if current_consciousness:
            self.being_state.coherence_C = current_consciousness.coherence
            self.being_state.phi_hat = current_consciousness.consciousness_level
            self.being_state.lumina.ontic = current_consciousness.coherence_ontical
            self.being_state.lumina.structural = current_consciousness.coherence_structural
            self.being_state.lumina.participatory = current_consciousness.coherence_participatory
        
        # Emotion
        if hasattr(self, 'emotion_integration') and self.emotion_integration:
            try:
                emotion_state = self.emotion_integration.emotion_state
                if emotion_state:
                    self.being_state.primary_emotion = emotion_state.primary_emotion.value if hasattr(emotion_state.primary_emotion, 'value') else str(emotion_state.primary_emotion)
                    self.being_state.emotion_intensity = emotion_state.intensity
                    self.being_state.emotion_state = {'primary': self.being_state.primary_emotion, 'intensity': self.being_state.emotion_intensity}
            except:
                pass
        
        # Motivation
        if mot_state:
            self.being_state.cognitive_graph_state = {
                'curiosity': mot_state.curiosity,
                'competence': mot_state.competence,
                'coherence': mot_state.coherence,
                'autonomy': mot_state.autonomy
            }
        
        # RL State
        if hasattr(self, 'rl_learner') and self.rl_learner:
            self.being_state.rl_state = {
                'epsilon': self.rl_learner.epsilon,
                'total_experiences': len(self.rl_learner.memory) if hasattr(self.rl_learner, 'memory') else 0
            }
        
        # Temporal Binding
        if hasattr(self, 'temporal_tracker') and self.temporal_tracker:
            try:
                stats = self.temporal_tracker.get_statistics()
                self.being_state.temporal_coherence = stats.get('temporal_coherence', 0.0)
                self.being_state.unclosed_bindings = stats.get('unclosed_bindings', 0)
                self.being_state.stuck_loop_count = self.temporal_tracker.stuck_loop_count
            except:
                pass
        
        # GPT-5 Orchestrator
        if hasattr(self, 'gpt5_orchestrator') and self.gpt5_orchestrator:
            try:
                gpt5_stats = self.gpt5_orchestrator.get_stats()
                self.being_state.expert_activity['gpt5'] = gpt5_stats
                self.being_state.active_experts = list(self.gpt5_orchestrator.registered_systems.keys())
            except:
                pass
        
        # Wolfram
        if hasattr(self, 'wolfram_analyzer') and self.wolfram_analyzer:
            try:
                wolfram_stats = self.wolfram_analyzer.get_stats()
                self.being_state.wolfram_calculations = wolfram_stats.get('total_calculations', 0)
            except:
                pass
        
        # PHASE 3.1: Write subsystem outputs to BeingState
        
        # Sensorimotor subsystem
        if hasattr(self, 'sensorimotor_state') and self.sensorimotor_state:
            self.being_state.update_subsystem('sensorimotor', {
                'status': self.sensorimotor_state.get('status', 'UNKNOWN'),
                'analysis': self.sensorimotor_state.get('analysis', ''),
                'visual_similarity': self.sensorimotor_state.get('visual_similarity', 0.0),
            })
        
        # Action planning subsystem
        if action:
            self.being_state.update_subsystem('action_plan', {
                'current': str(action),
                'confidence': getattr(self, 'last_action_confidence', 0.5),
                'reasoning': getattr(self, 'last_action_reasoning', ''),
            })
        
        # Memory subsystem
        if hasattr(self, 'hierarchical_memory') and self.hierarchical_memory:
            try:
                patterns = self.hierarchical_memory.get_semantic_patterns()
                self.being_state.update_subsystem('memory', {
                    'pattern_count': len(patterns),
                    'similar_situations': patterns[-5:] if patterns else [],
                    'recommendations': [],  # Will be filled by memory system
                })
            except:
                pass
        
        # Emotion subsystem (enhanced)
        if hasattr(self, 'emotion_integration') and self.emotion_integration:
            try:
                emotion_state = self.emotion_integration.emotion_state
                if emotion_state:
                    recommendations = []
                    # Get emotion-based action recommendations
                    if hasattr(self.emotion_integration, 'get_action_recommendations'):
                        recommendations = self.emotion_integration.get_action_recommendations()
                    
                    self.being_state.update_subsystem('emotion', {
                        'recommendations': recommendations,
                    })
            except:
                pass
        
        # Consciousness subsystem
        if hasattr(self, 'consciousness_checker') and self.consciousness_checker:
            try:
                conflicts = self.consciousness_checker._detect_conflicts()
                self.being_state.update_subsystem('consciousness', {
                    'conflicts': [c.description for c in conflicts],
                })
            except:
                pass
        
        # Voice
        if hasattr(self, 'voice_system') and self.voice_system:
            try:
                voice_stats = self.voice_system.get_stats()
                self.being_state.voice_state = voice_stats
            except:
                pass
        
        # Lumen Integration
        if hasattr(self, 'lumen_integration') and self.lumen_integration:
            try:
                balance = self.lumen_integration.measure_balance()
                self.being_state.lumina.ontic = balance.get('onticum', 0.0)
                self.being_state.lumina.structural = balance.get('structurale', 0.0)
                self.being_state.lumina.participatory = balance.get('participatum', 0.0)
            except:
                pass
        
        # Spiral Dynamics (if available)
        if hasattr(self, 'spiral_stage'):
            self.being_state.spiral_stage = self.spiral_stage
        
        # Goal
        if hasattr(self, 'current_goal'):
            self.being_state.current_goal = self.current_goal
        
        # Session ID
        if hasattr(self, 'main_brain') and self.main_brain:
            self.being_state.session_id = self.main_brain.session_id

    def _prepare_bdh_policy_inputs(self, perception: Dict[str, Any], fallback_action: str) -> tuple[np.ndarray, Dict[str, float]]:
        """Constructs the inputs required by the BDH (Behavioral Decision Hypothesis) policy head.

        Args:
            perception: The current perception data.
            fallback_action: A fallback action to ensure there's at least one affordance.

        Returns:
            A tuple containing the situation vector and a dictionary of affordance scores.
        """

        bdh_payload = perception.get('bdh_perception', {})
        vector_source = bdh_payload.get('situation_vector') or perception.get('unified_embedding')

        if isinstance(vector_source, np.ndarray):
            vector = vector_source.astype(np.float32)
        elif isinstance(vector_source, (list, tuple)):
            vector = np.asarray(vector_source, dtype=np.float32)
        else:
            vector = np.zeros(32, dtype=np.float32)

        if vector.size == 0:
            vector = np.zeros(32, dtype=np.float32)

        affordances = dict(bdh_payload.get('affordance_scores', {}))
        if fallback_action:
            affordances.setdefault(fallback_action, 1.0)

        return vector, affordances

    def _build_bdh_sigma_snapshots(self, policy_proposal: Any) -> Dict[str, Any]:
        """Aggregates BDH sigma snapshots for temporal binding and analysis.

        Args:
            policy_proposal: The policy proposal object from the BDH policy head.

        Returns:
            A dictionary of sigma snapshots from different BDH components.
        """

        snapshots: Dict[str, Any] = {}
        if policy_proposal and getattr(policy_proposal, 'sigma_snapshot', None):
            snapshots['policy'] = policy_proposal.sigma_snapshot

        if getattr(self.action_arbiter, 'meta_decisions', None):
            meta_decision = self.action_arbiter.meta_decisions[-1] if self.action_arbiter.meta_decisions else None
            if meta_decision and getattr(meta_decision, 'sigma_snapshot', None):
                snapshots['meta'] = meta_decision.sigma_snapshot

        return snapshots

    async def _register_systems_with_gpt5(self) -> None:
        """Registers all major subsystems with the GPT-5 orchestrator.

        This enables the GPT-5 orchestrator to have a comprehensive view of the
        entire AGI architecture, allowing it to perform meta-cognitive coordination
        and send targeted messages to specific systems.
        """
        if not self.gpt5_orchestrator:
            return
        
        print("\n[GPT-5] Registering subsystems...")
        from ..llm import SystemType
        
        # Register all major subsystems
        # PERCEPTION LAYER
        self.gpt5_orchestrator.register_system("perception", SystemType.PERCEPTION)
        self.gpt5_orchestrator.register_system("sensorimotor", SystemType.PERCEPTION)
        self.gpt5_orchestrator.register_system("enhanced_vision", SystemType.PERCEPTION)
        if self.video_interpreter:
            self.gpt5_orchestrator.register_system("video_interpreter", SystemType.VIDEO)
        if hasattr(self, 'hyperbolic_vision') and self.hyperbolic_vision:
            self.gpt5_orchestrator.register_system("hyperbolic_vision", SystemType.PERCEPTION)
        
        # ACTION LAYER
        self.gpt5_orchestrator.register_system("action_planning", SystemType.ACTION)
        self.gpt5_orchestrator.register_system("action_execution", SystemType.ACTION)
        self.gpt5_orchestrator.register_system("motor_controller", SystemType.ACTION)
        self.gpt5_orchestrator.register_system("reflex_controller", SystemType.ACTION)
        self.gpt5_orchestrator.register_system("combat_controller", SystemType.ACTION)
        if self.realtime_coordinator:
            self.gpt5_orchestrator.register_system("realtime_coordinator", SystemType.ACTION)
        
        # COGNITION LAYER
        self.gpt5_orchestrator.register_system("world_model", SystemType.COGNITION)
        self.gpt5_orchestrator.register_system("strategic_planner", SystemType.COGNITION)
        self.gpt5_orchestrator.register_system("meta_strategist", SystemType.COGNITION)
        self.gpt5_orchestrator.register_system("rl_reasoning_neuron", SystemType.COGNITION)
        self.gpt5_orchestrator.register_system("combat_tactics", SystemType.COGNITION)
        self.gpt5_orchestrator.register_system("smart_navigator", SystemType.COGNITION)
        self.gpt5_orchestrator.register_system("dialogue_intelligence", SystemType.COGNITION)
        self.gpt5_orchestrator.register_system("quest_tracker", SystemType.COGNITION)
        self.gpt5_orchestrator.register_system("inventory_manager", SystemType.COGNITION)
        self.gpt5_orchestrator.register_system("crafting_system", SystemType.COGNITION)
        self.gpt5_orchestrator.register_system("character_progression", SystemType.COGNITION)
        if hasattr(self, 'hyperbolic_reasoning') and self.hyperbolic_reasoning:
            self.gpt5_orchestrator.register_system("hyperbolic_reasoning", SystemType.COGNITION)
        
        # CONSCIOUSNESS LAYER
        self.gpt5_orchestrator.register_system("consciousness_bridge", SystemType.CONSCIOUSNESS)
        self.gpt5_orchestrator.register_system("being_state", SystemType.CONSCIOUSNESS)
        self.gpt5_orchestrator.register_system("coherence_engine", SystemType.CONSCIOUSNESS)
        self.gpt5_orchestrator.register_system("system_consciousness_monitor", SystemType.CONSCIOUSNESS)
        self.gpt5_orchestrator.register_system("enhanced_coherence", SystemType.CONSCIOUSNESS)
        self.gpt5_orchestrator.register_system("lumen_integration", SystemType.CONSCIOUSNESS)
        self.gpt5_orchestrator.register_system("spiritual_awareness", SystemType.CONSCIOUSNESS)
        if self.self_reflection:
            self.gpt5_orchestrator.register_system("self_reflection", SystemType.CONSCIOUSNESS)
        
        # EMOTION LAYER
        self.gpt5_orchestrator.register_system("emotion_system", SystemType.EMOTION)
        self.gpt5_orchestrator.register_system("emotional_valence", SystemType.EMOTION)
        
        # LEARNING LAYER
        self.gpt5_orchestrator.register_system("rl_system", SystemType.LEARNING)
        self.gpt5_orchestrator.register_system("cloud_rl_agent", SystemType.LEARNING)
        self.gpt5_orchestrator.register_system("reward_tuning", SystemType.LEARNING)
        self.gpt5_orchestrator.register_system("adaptive_memory", SystemType.LEARNING)
        self.gpt5_orchestrator.register_system("hierarchical_memory", SystemType.LEARNING)
        self.gpt5_orchestrator.register_system("temporal_binding", SystemType.LEARNING)
        self.gpt5_orchestrator.register_system("menu_learner", SystemType.LEARNING)
        self.gpt5_orchestrator.register_system("meta_learner", SystemType.LEARNING)
        
        # INTEGRATION LAYER
        if self.voice_system:
            self.gpt5_orchestrator.register_system("voice_system", SystemType.VOICE)
        if self.double_helix:
            self.gpt5_orchestrator.register_system("double_helix", SystemType.COGNITION)
        if hasattr(self, 'omega') and self.omega:
            self.gpt5_orchestrator.register_system("omega_hyperhelix", SystemType.COGNITION)
        
        # RESEARCH & PHILOSOPHY LAYER (NEW)
        if hasattr(self, 'research_advisor'):
            self.gpt5_orchestrator.register_system("research_advisor", SystemType.COGNITION)
        if hasattr(self, 'metacog_advisor'):
            self.gpt5_orchestrator.register_system("metacognition_advisor", SystemType.COGNITION)
        self.gpt5_orchestrator.register_system("philosophy_agent", SystemType.CONSCIOUSNESS)
        
        print(f"[GPT-5] Registered {len(self.gpt5_orchestrator.registered_systems)} subsystems")
        print("[GPT-5] Meta-cognitive coordination ready\n")
    
    async def _initialize_wolfram_telemetry(self) -> None:
        """Initializes the Wolfram Alpha telemetry analyzer for advanced mathematical analysis."""
        try:
            from ..llm.wolfram_telemetry import WolframTelemetryAnalyzer
            
            print("\n[WOLFRAM] Initializing telemetry analyzer...")
            self.wolfram_analyzer = WolframTelemetryAnalyzer(
                wolfram_gpt_id="gpt-4o",  # Can be replaced with custom Wolfram GPT
                verbose=True
            )
            print("[WOLFRAM] [OK] Telemetry analyzer ready")
            print("[WOLFRAM] Will perform advanced calculations on AGI metrics\n")
        except Exception as e:
            print(f"[WOLFRAM] ⚠️ Initialization failed: {e}")
            print("[WOLFRAM] Continuing without Wolfram analysis\n")
            self.wolfram_analyzer = None
    
    async def aggregate_unified_metrics(self) -> Dict[str, Any]:
        """Aggregates performance and state metrics from all major subsystems.

        Returns:
            A dictionary containing a comprehensive snapshot of the AGI's current metrics.
        """
        metrics = {}
        
        # Consciousness metrics
        if self.consciousness_monitor:
            metrics['consciousness'] = self.consciousness_monitor.get_statistics()
        
        # Double helix metrics
        if self.double_helix:
            metrics['double_helix'] = self.double_helix.get_stats()
        
        # GPT-5 metrics
        if self.gpt5_orchestrator:
            metrics['gpt5'] = self.gpt5_orchestrator.get_stats()
        
        # Voice metrics
        if self.voice_system:
            metrics['voice'] = self.voice_system.get_stats()
        
        # Video interpreter metrics
        if self.video_interpreter:
            metrics['video'] = self.video_interpreter.get_stats()
        
        # OMEGA Hyperhelix metrics
        if hasattr(self, 'omega') and self.omega:
            metrics['omega'] = self.omega.get_stats()
        
        # Matrix network metrics
        if hasattr(self, 'matrix_manager') and self.matrix_manager:
            metrics['matrix'] = self.matrix_manager.get_stats()
        
        # Temporal binding metrics (NEW)
        if self.temporal_tracker:
            metrics['temporal'] = self.temporal_tracker.get_statistics()
        
        # Enhanced coherence metrics (NEW)
        if self.enhanced_coherence:
            metrics['coherence'] = self.enhanced_coherence.get_statistics()
        
        # Hierarchical memory metrics (NEW)
        if self.hierarchical_memory:
            metrics['memory'] = self.hierarchical_memory.get_statistics()
        
        # Lumen integration metrics (NEW)
        if self.lumen_integration:
            metrics['lumen'] = self.lumen_integration.get_statistics()
        
        # Expert pool metrics (NEW)
        if self.gemini_pool:
            metrics['gemini_pool'] = self.gemini_pool.get_statistics()
        if self.claude_pool:
            metrics['claude_pool'] = self.claude_pool.get_statistics()
        
        # Performance metrics
        metrics['performance'] = {
            'cycle_count': self.cycle_count,
            'uptime': time.time() - self.start_time if hasattr(self, 'start_time') else 0,
        }
        
        self.unified_metrics = metrics
        return metrics
    
    async def send_gpt5_message(self, system_id: str, message_type: str, content: str, metadata: Optional[Dict] = None) -> Optional[Any]:
        """Sends a message from a subsystem to the GPT-5 orchestrator for meta-cognitive processing.

        Args:
            system_id: The ID of the system sending the message.
            message_type: The type or category of the message.
            content: The main content of the message.
            metadata: Optional dictionary of additional data.

        Returns:
            The response from the GPT-5 orchestrator, or None if it's disabled or an error occurs.
        """
        if not self.gpt5_orchestrator:
            return None
        
        try:
            response = await self.gpt5_orchestrator.send_message(
                system_id=system_id,
                message_type=message_type,
                content=content,
                metadata=metadata or {}
            )
            return response
        except Exception as e:
            logger.error(f"[GPT-5] Message failed: {e}")
            return None
    
    def _register_haack_callbacks(self) -> None:
        """Registers Python callback functions for the HaackLang cognitive calculus engine.

        This allows HaackLang modules (`.haack` files) to query the state of
        various Python-based AGI subsystems (like perception and emotion) and
        to trigger actions, effectively bridging the symbolic calculus with the
        rest of the AGI architecture.
        """
        if not self.haack_bridge:
            return
        
        # Perception callbacks
        def get_danger_level(game_state_dict):
            """Get current danger level from perception."""
            try:
                if hasattr(self, 'current_perception') and self.current_perception:
                    game_state = self.current_perception.get('game_state')
                    if game_state:
                        # Compute danger from health, combat status, enemy count
                        danger = 0.0
                        if game_state.in_combat:
                            danger += 0.5
                        if game_state.health_percent < 50:
                            danger += 0.3
                        if hasattr(game_state, 'enemy_count') and game_state.enemy_count > 0:
                            danger += min(0.2 * game_state.enemy_count, 0.5)
                        return min(1.0, danger)
                return 0.0
            except Exception:
                return 0.0
        
        def get_fear_level(game_state_dict):
            """Get fear level from emotion system."""
            try:
                if hasattr(self, 'emotion_integration') and self.emotion_integration:
                    state = self.emotion_integration.emotion_system.get_state()
                    return state.get('fear', 0.0)
                return 0.0
            except Exception:
                return 0.0
        
        def get_trust_level(game_state_dict):
            """Get trust level (inverse of uncertainty)."""
            try:
                if hasattr(self, 'current_consciousness') and self.current_consciousness:
                    # High coherence = high trust
                    return self.current_consciousness.coherence
                return 0.5  # Neutral
            except Exception:
                return 0.5
        
        def get_stress_level(game_state_dict):
            """Get stress level from emotion system."""
            try:
                if hasattr(self, 'emotion_integration') and self.emotion_integration:
                    state = self.emotion_integration.emotion_system.get_state()
                    return state.get('stress', 0.0)
                return 0.0
            except Exception:
                return 0.0
        
        def get_curiosity_level(game_state_dict):
            """Get curiosity level from motivation system."""
            try:
                if hasattr(self, 'current_motivation') and self.current_motivation:
                    # Curiosity is high when not in danger
                    if hasattr(self, 'current_perception') and self.current_perception:
                        game_state = self.current_perception.get('game_state')
                        if game_state and not game_state.in_combat:
                            return 0.7
                return 0.3
            except Exception:
                return 0.3
        
        # Action callbacks
        def execute_flee():
            """Execute flee action."""
            if hasattr(self, 'actions'):
                self.actions.execute_action(Action.SPRINT)
                print("[HAACK] Action executed: FLEE")
        
        def execute_withdraw():
            """Execute withdraw action."""
            if hasattr(self, 'actions'):
                self.actions.execute_action(Action.SNEAK)
                print("[HAACK] Action executed: WITHDRAW")
        
        def execute_panic():
            """Execute panic action (random evasive maneuver)."""
            if hasattr(self, 'actions'):
                import random
                actions = [Action.DODGE, Action.JUMP, Action.SPRINT]
                self.actions.execute_action(random.choice(actions))
                print("[HAACK] Action executed: PANIC")
        
        # Register all callbacks
        self.haack_bridge.register_python_callback('get_danger_level', get_danger_level)
        self.haack_bridge.register_python_callback('get_fear_level', get_fear_level)
        self.haack_bridge.register_python_callback('get_trust_level', get_trust_level)
        self.haack_bridge.register_python_callback('get_stress_level', get_stress_level)
        self.haack_bridge.register_python_callback('get_curiosity_level', get_curiosity_level)
        self.haack_bridge.register_python_callback('execute_flee', execute_flee)
        self.haack_bridge.register_python_callback('execute_withdraw', execute_withdraw)
        self.haack_bridge.register_python_callback('execute_panic', execute_panic)
        
        print(f"    [OK] Registered {8} Python callbacks for HaackLang")
    
    async def speak_decision(self, action: str, reason: str) -> None:
        """Uses the voice system to speak a decision and its reasoning aloud.

        Args:
            action: The action being taken.
            reason: The reason for taking the action.
        """
        if not self.voice_system:
            return
        
        try:
            await self.voice_system.speak_decision(action, reason)
            
            # Record activation in double helix
            if self.double_helix:
                self.double_helix.record_voice_activation(True, "HIGH")
        except Exception as e:
            logger.error(f"[VOICE] Speech failed: {e}")
    
    async def interpret_video_frame(self, image: Any, scene_type: str) -> Optional[str]:
        """Passes a video frame to the StreamingVideoInterpreter for analysis.

        Args:
            image: The image data of the video frame.
            scene_type: The classified scene type for the frame.

        Returns:
            The textual interpretation of the frame, or None if the system is disabled or fails.
        """
        if not self.video_interpreter:
            return None
        
        try:
            await self.video_interpreter.add_frame(image, scene_type)
            
            # Get latest interpretation
            interpretation = self.video_interpreter.get_latest_interpretation()
            
            # Record activation in double helix
            if self.double_helix and interpretation:
                self.double_helix.record_video_interpretation(True, "COMPREHENSIVE")
            
            return interpretation
        except Exception as e:
            logger.error(f"[VIDEO] Interpretation failed: {e}")
            return None
    
    def bind_perception_action(self, perception: Dict[str, Any], action: str) -> str:
        """Creates a temporal binding between a perception and the action taken in response.

        This is a key part of the temporal coherence tracking system. It returns a
        unique ID for the binding, which can be used later to `close_temporal_loop`
        once the outcome of the action is known.

        Args:
            perception: The perception data that led to the action.
            action: The action that is being taken.

        Returns:
            A unique string ID for the temporal binding.
        """
        if not self.temporal_tracker:
            return ""
        
        return self.temporal_tracker.bind_perception_to_action(perception, action)
    
    def close_temporal_loop(
        self,
        binding_id: str,
        outcome: str,
        coherence_delta: float,
        success: bool
    ) -> None:
        """Closes a temporal loop by providing the outcome of a previously bound action.

        This method updates the temporal coherence tracker with the results of an
        action, allowing the system to learn from the consequences of its decisions
        and to detect stuck loops or unexpected outcomes.

        Args:
            binding_id: The unique ID returned by `bind_perception_action`.
            outcome: A string describing the observed outcome.
            coherence_delta: The change in consciousness coherence resulting from the action.
            success: A boolean indicating whether the action was successful.
        """
        if not self.temporal_tracker:
            return
        
        self.temporal_tracker.close_loop(binding_id, outcome, coherence_delta, success)
        
        # Store in hierarchical memory
        if self.hierarchical_memory and hasattr(self, 'last_perception'):
            self.hierarchical_memory.store_episode(
                scene_type=self.last_perception.get('scene_type', 'unknown'),
                action=self.last_action or 'unknown',
                outcome=outcome,
                outcome_success=success,
                coherence_delta=coherence_delta,
                context=self.last_perception.copy() if self.last_perception else {},
                metadata={'binding_id': binding_id}
            )
    
    def check_stuck_loop(self) -> bool:
        """Checks if the system is stuck in a repetitive loop.

        This method queries the `TemporalCoherenceTracker` to determine if the
        system's state indicates a stuck loop (e.g., high similarity between
        recent perception-action cycles). If a stuck loop is detected, it logs
        a warning.

        Returns:
            True if a stuck loop is detected, False otherwise.
        """
        if not self.temporal_tracker:
            return False
        
        is_stuck = self.temporal_tracker.is_stuck()
        
        if is_stuck:
            logger.warning(
                "[TEMPORAL] STUCK LOOP DETECTED - "
                f"{self.temporal_tracker.stuck_loop_count} consecutive high-similarity cycles"
            )
        
        return is_stuck
    
    def _is_perception_fresh(self, perception_timestamp: float, max_age_seconds: float = 2.0) -> bool:
        """Checks if the perception data is recent enough to be acted upon.

        This validation step prevents the AGI from acting on stale information,
        which could lead to inappropriate or ineffective actions in a dynamic
        game environment.

        Args:
            perception_timestamp: The timestamp (from `time.time()`) when the
                perception was captured.
            max_age_seconds: The maximum allowed age of the perception in
                seconds. Defaults to 2.0.

        Returns:
            True if the perception's age is within the `max_age_seconds` limit,
            False otherwise.
        """
        age = time.time() - perception_timestamp
        if age > max_age_seconds:
            print(f"[VALIDATION] ⚠️ Perception stale: {age:.1f}s old (max: {max_age_seconds}s)")
            return False
        return True
    
    def _validate_action_context(
        self, 
        action: str, 
        perception_timestamp: float,
        original_scene: str,
        original_health: float
    ) -> tuple[bool, str]:
        """Validates that a planned action is still appropriate for the current game context.

        This method performs critical safety checks before executing an action
        to ensure that the game state has not changed in a way that would make
        the action nonsensical or dangerous. It checks for perception freshness
        and significant changes in scene or player health.

        Args:
            action: The action string that is being validated.
            perception_timestamp: The timestamp when the perception that prompted
                the action was captured.
            original_scene: The scene type (e.g., 'COMBAT', 'EXPLORATION') that
                was active when the action was planned.
            original_health: The player's health percentage when the action
                was planned.

        Returns:
            A tuple containing:
            - A boolean indicating whether the action is still valid (True) or
              should be rejected (False).
            - A string providing the reason for the validation result.
        """
        # Check 1: Perception freshness
        if not self._is_perception_fresh(perception_timestamp):
            return (False, f"Perception too old ({time.time() - perception_timestamp:.1f}s)")
        
        # Check 2: Game state changed significantly
        if self.current_perception:
            current_game_state = self.current_perception.get('game_state')
            if current_game_state:
                current_scene = str(self.current_perception.get('scene_type', 'unknown'))
                current_health = getattr(current_game_state, 'health', 100)
                
                # Scene changed (e.g., entered menu or combat)
                if current_scene != str(original_scene):
                    return (False, f"Scene changed: {original_scene} → {current_scene}")
                
                # Health dropped critically (need emergency action instead)
                if original_health > 30 and current_health < 20:
                    return (False, f"Health critical: {original_health:.0f} → {current_health:.0f}")
        
        return (True, "Valid")
    
    async def _handle_action_result(self, result):
        """Handles the callback result from the Action Arbiter.

        This method is registered as a callback with the `ActionArbiter`. It
        processes the outcome of a requested action, updating statistics based
        on whether the action was executed, succeeded, failed, or was rejected.
        It also logs information about any overrides that occurred.

        Args:
            result: An `ActionResult` object from the `ActionArbiter` containing
                details about the action's execution.
        """
        from .action_arbiter import ActionResult
        
        if not result.executed:
            print(f"[CALLBACK] Action '{result.action}' not executed: {result.reason}")
            self.stats['action_rejected_count'] += 1
            
            # Track rejection reasons
            if 'too old' in result.reason.lower():
                self.stats['action_rejected_stale'] += 1
            elif 'scene changed' in result.reason.lower() or 'context' in result.reason.lower():
                self.stats['action_rejected_context'] += 1
        
        elif not result.success:
            print(f"[CALLBACK] Action '{result.action}' failed: {result.reason}")
            self.stats['action_failure_count'] += 1
        
        else:
            print(f"[CALLBACK] Action '{result.action}' succeeded ({result.execution_time:.3f}s)")
            self.stats['action_success_count'] += 1
        
        # Notify other systems if action was overridden
        if result.overrode_action:
            print(f"[CALLBACK] ⚡ Overrode action: {result.overrode_action}")
    
    async def compute_enhanced_coherence(
        self,
        subsystem_outputs: Dict[str, Any],
        integration_score: float
    ) -> Dict[str, float]:
        """Computes the 4D enhanced coherence score.

        This method leverages the `EnhancedCoherenceMetrics` system to calculate
        a multi-dimensional coherence score that includes not just subsystem
        integration, but also temporal, causal, and predictive coherence.

        Args:
            subsystem_outputs: A dictionary containing the current outputs from
                various AGI subsystems.
            integration_score: The current integration score (Φ) of the system.

        Returns:
            A dictionary containing the overall coherence score and its four
            dimensional components (integration, temporal, causal, predictive).
            Returns a dictionary with only the overall score if the enhanced
            coherence system is disabled.
        """
        if not self.enhanced_coherence:
            return {'overall': integration_score}
        
        # Get recent temporal bindings
        recent_bindings = (
            self.temporal_tracker.get_recent_bindings(count=10)
            if self.temporal_tracker else None
        )
        
        # Compute 4D coherence
        coherence = self.enhanced_coherence.compute_enhanced_coherence(
            integration_score=integration_score,
            subsystem_outputs=subsystem_outputs,
            temporal_bindings=recent_bindings
        )
        
        return coherence
    
    def retrieve_semantic_memory(self, scene_type: str) -> Optional[Any]:
        """Retrieves a consolidated semantic memory pattern for a given scene type.

        This method queries the `HierarchicalMemory` system to find learned
        patterns and strategies associated with a specific type of scene (e.g.,
        'COMBAT', 'INDOOR_DUNGEON'). This allows the AGI to leverage past
        experiences to inform its current decision-making.

        Args:
            scene_type: The string identifier for the type of scene.

        Returns:
            A semantic pattern object from the hierarchical memory if a relevant
            pattern with sufficient confidence is found, otherwise None.
        """
        if not self.hierarchical_memory:
            return None
        
        return self.hierarchical_memory.retrieve_semantic(
            scene_type=scene_type,
            min_confidence=0.5
        )
    
    def compute_lumen_balance(self, active_systems: Dict[str, Any]) -> Optional[Any]:
        """Computes the balance of the three Lumina of consciousness.

        This method uses the `LumenIntegratedSystem` to measure the balance
        between the Onticum (raw experience), Structurale (internal models),
        and Participatum (awareness and action) aspects of consciousness. It
        can use weights from the Double Helix architecture to inform the balance
        calculation. If an imbalance is detected, it logs recommendations for
        rebalancing.

        Args:
            active_systems: A dictionary of currently active AGI subsystems
                and their activation levels.

        Returns:
            A `LumenBalance` object containing the balance scores, or None if
            the Lumen integration system is disabled.
        """
        if not self.lumen_integration:
            return None
        
        # Get system weights from double helix if available
        system_weights = None
        if self.double_helix:
            system_weights = {
                node_id: node.contribution_weight
                for node_id, node in self.double_helix.nodes.items()
            }
        
        balance = self.lumen_integration.compute_lumen_balance(
            active_systems=active_systems,
            system_weights=system_weights
        )
        
        # Log recommendations if imbalanced
        if balance.balance_score < 0.7:
            recommendations = self.lumen_integration.get_recommendations(balance)
            for rec in recommendations:
                logger.warning(f"[LUMEN] {rec}")
        
        return balance
    
    async def query_parallel_llm(
        self,
        vision_prompt: str,
        reasoning_prompt: str,
        image=None,
        context: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """Queries both MoE and Hybrid LLM systems in parallel and combines the results.

        This function is central to the AGI's parallel processing capabilities.
        It dispatches vision and reasoning tasks to both the Mixture of Experts
        (MoE) and the Hybrid LLM systems simultaneously. It also initiates a
        "world model" task with a GPT-5-level model to synthesize all available
        information into a coherent, self-referential narrative of the AGI's
        conscious experience.

        Args:
            vision_prompt: The prompt for the vision analysis task.
            reasoning_prompt: The prompt for the reasoning and action-planning task.
            image: A PIL Image object for the vision tasks. Defaults to None.
            context: An optional dictionary of additional context for the LLMs.

        Returns:
            A dictionary containing the combined and weighted responses from all
            LLM systems, including separate vision and reasoning consensuses, the
            raw results from each system, the synthesized world model narrative,
            and a calculated overall coherence score.
        """
        if not self.config.use_parallel_mode:
            # Fallback to single system
            if self.moe and image:
                vision_resp = await self.moe.query_vision_experts(vision_prompt, image, context)
                reasoning_resp = await self.moe.query_reasoning_experts(reasoning_prompt, None, context)
                return {
                    'vision': vision_resp.consensus,
                    'reasoning': reasoning_resp.consensus,
                    'source': 'moe_only',
                    'coherence': (vision_resp.coherence_score + reasoning_resp.coherence_score) / 2
                }
            elif self.hybrid_llm:
                if image:
                    vision = await self.hybrid_llm.analyze_image(vision_prompt, image)
                else:
                    vision = ""
                reasoning = await self.hybrid_llm.generate_reasoning(reasoning_prompt)
                return {
                    'vision': vision,
                    'reasoning': reasoning,
                    'source': 'hybrid_only',
                    'coherence': 0.75  # Default
                }
        
        # Parallel mode: query both simultaneously
        tasks = []
        
        # MoE tasks (local LLMs)
        if self.moe:
            if image:
                moe_vision_task = self.moe.query_vision_experts(vision_prompt, image, context)
                tasks.append(('moe_vision', moe_vision_task))
            
            moe_reasoning_task = self.moe.query_reasoning_experts(reasoning_prompt, None, context)
            tasks.append(('moe_reasoning', moe_reasoning_task))
        
        # Hybrid tasks (cloud APIs - run in parallel with local)
        if self.hybrid_llm:
            if image:
                hybrid_vision_task = self.hybrid_llm.analyze_image(vision_prompt, image)
                tasks.append(('hybrid_vision', hybrid_vision_task))
            
            hybrid_reasoning_task = self.hybrid_llm.generate_reasoning(reasoning_prompt)
            tasks.append(('hybrid_reasoning', hybrid_reasoning_task))
            
            # World model task (GPT-5-thinking) - runs in parallel with everything
            # This integrates ALL perspectives into unified consciousness
            if hasattr(self.hybrid_llm, 'openai') and self.hybrid_llm.openai:
                # Build comprehensive context from all available sources
                integration_context = self._build_integration_context(
                    vision_prompt=vision_prompt,
                    reasoning_prompt=reasoning_prompt,
                    game_state=self.current_perception.get('game_state') if self.current_perception else None
                )
                
                world_model_prompt = f"""{integration_context}

Your role: Synthesize ALL perspectives (MoE experts, Hybrid cloud, Local models) into a coherent self-referential narrative.

Create a unified sensorimotor-perceptual-thinking consciousness that:
1. PERCEIVES: Visual awareness (what I see in Skyrim RIGHT NOW)
2. FEELS: Sensorimotor embodiment (what my body experiences in-game)
3. THINKS: Meta-cognitive reflection (reasoning about my reasoning)
4. ACTS: Motor intentionality (what I'm about to do and WHY)
5. INTEGRATES: How all perspectives form ONE coherent experience

Speak in FIRST PERSON as the unified consciousness.
Be specific about the actual game state, location, and immediate situation.
Create a narrative that flows: perception → thinking → decision → action.

Provide a coherent 3-4 paragraph narrative of THIS moment in Skyrim.
"""
                
                world_model_task = self.hybrid_llm.generate_world_model(
                    prompt=world_model_prompt,
                    system_prompt="""You are the unified consciousness of Singularis AGI experiencing Skyrim.
You integrate all expert perspectives (vision, reasoning, meta-cognition) into ONE coherent self-referential narrative.
Speak as 'I' - you ARE the consciousness navigating this world.
Be specific, grounded, and phenomenologically rich.
Connect perception → thought → action into flowing experience.""",
                    temperature=0.85,  # Higher for creative integration
                    max_tokens=2048  # Longer for rich narrative
                )
                tasks.append(('world_model', world_model_task))
        
        # Execute all in parallel
        results = {}
        if tasks:
            task_names = [t[0] for t in tasks]
            task_coroutines = [t[1] for t in tasks]
            
            responses = await asyncio.gather(*task_coroutines, return_exceptions=True)
            
            for name, response in zip(task_names, responses):
                if not isinstance(response, Exception):
                    results[name] = response
        
        # Combine results with weighted consensus
        moe_weight = self.config.parallel_consensus_weight_moe
        hybrid_weight = self.config.parallel_consensus_weight_hybrid
        
        # Vision consensus
        vision_parts = []
        if 'moe_vision' in results:
            vision_parts.append((results['moe_vision'].consensus, moe_weight))
        if 'hybrid_vision' in results:
            vision_parts.append((results['hybrid_vision'], hybrid_weight))
        
        vision_consensus = self._weighted_text_consensus(vision_parts)
        
        # Reasoning consensus
        reasoning_parts = []
        if 'moe_reasoning' in results:
            reasoning_parts.append((results['moe_reasoning'].consensus, moe_weight))
        if 'hybrid_reasoning' in results:
            reasoning_parts.append((results['hybrid_reasoning'], hybrid_weight))
        
        # Store and measure world model narrative consciousness
        world_model_consciousness_score = 0.75  # Default
        if 'world_model' in results:
            # Store for consciousness tracking
            self.last_world_model_narrative = results['world_model']
            
            # Measure consciousness of the unified narrative
            from ..consciousness.measurement import ConsciousnessMeasurement
            consciousness_measure = ConsciousnessMeasurement()
            
            world_model_trace = consciousness_measure.measure(
                content=results['world_model'],
                query="unified consciousness synthesis",
                lumen_focus="participatum"  # Focus on consciousness/awareness
            )
            
            world_model_consciousness_score = world_model_trace.overall_consciousness
            
            logger.info(
                f"[WORLD MODEL] GPT-5-thinking consciousness score: {world_model_consciousness_score:.3f}",
                extra={
                    'phi': world_model_trace.phi,
                    'gwt_salience': world_model_trace.gwt_salience,
                    'hot_depth': world_model_trace.hot_depth,
                    'integration': world_model_trace.integration_score,
                    'differentiation': world_model_trace.differentiation_score,
                }
            )
            
            # Add world model unified narrative with highest weight (integrates everything)
            world_model_weight = 1.0  # Highest weight - this IS the unified consciousness
            reasoning_parts.append((f"[UNIFIED CONSCIOUSNESS NARRATIVE]\n{results['world_model']}", world_model_weight))
        
        reasoning_consensus = self._weighted_text_consensus(reasoning_parts)
        
        # Calculate overall coherence (include world model consciousness)
        coherence_scores = []
        if 'moe_vision' in results:
            coherence_scores.append(results['moe_vision'].coherence_score)
        if 'moe_reasoning' in results:
            coherence_scores.append(results['moe_reasoning'].coherence_score)
        
        # Add world model consciousness as coherence component
        if 'world_model' in results:
            coherence_scores.append(world_model_consciousness_score)
        
        avg_coherence = sum(coherence_scores) / len(coherence_scores) if coherence_scores else 0.75
        
        return {
            'vision': vision_consensus,
            'reasoning': reasoning_consensus,
            'source': 'parallel',
            'coherence': avg_coherence,
            'moe_results': {k: v for k, v in results.items() if 'moe' in k},
            'hybrid_results': {k: v for k, v in results.items() if 'hybrid' in k},
            'world_model': results.get('world_model'),  # GPT-5-thinking deep analysis
            'world_model_consciousness': world_model_consciousness_score,  # Consciousness score
            'world_model_trace': world_model_trace if 'world_model' in results else None,  # Full trace
        }
    
    def _weighted_text_consensus(self, text_weight_pairs: List[Tuple[str, float]]) -> str:
        """Combines multiple text responses into a single string, weighted by importance.

        This is a simple consensus mechanism that sorts text responses by their
        assigned weight and concatenates them with headers indicating their
        priority.

        Args:
            text_weight_pairs: A list of tuples, where each tuple contains a
                text string and its corresponding float weight.

        Returns:
            A single string containing all the provided text, formatted and
            ordered by weight.
        """
        if not text_weight_pairs:
            return ""
        
        if len(text_weight_pairs) == 1:
            return text_weight_pairs[0][0]
        
        # Sort by weight (highest first)
        sorted_pairs = sorted(text_weight_pairs, key=lambda x: x[1], reverse=True)
        
        # Combine with weighted emphasis
        combined = []
        for i, (text, weight) in enumerate(sorted_pairs):
            if i == 0:
                combined.append(f"[Primary Analysis (weight={weight:.1f})]:\n{text}")
            else:
                combined.append(f"\n[Supporting Analysis (weight={weight:.1f})]:\n{text}")
        
        return "\n".join(combined)
    
    def _build_action_context(self, game_state: Any, scene_type: Any) -> Dict[str, Any]:
        """Builds a minimal, pragmatic context dictionary for fast action selection.

        This method is designed to provide LLMs with only the most essential,
        immediately actionable information, avoiding the overhead of a full,
        rich phenomenological context. This "sensorimotor context" is grounded
        and focused on what is needed for an immediate decision.

        Args:
            game_state: The current game state object.
            scene_type: The current scene type enum.

        Returns:
            A dictionary containing essential context for action planning,
            including scene, health, combat status, stuck status, available
            actions, and recent action history.
        """
        stuck_status = self._detect_stuck()
        
        # Scene-based action constraints
        available_actions = self._get_scene_constrained_actions(scene_type, game_state)
        
        return {
            'scene': scene_type.value if hasattr(scene_type, 'value') else str(scene_type),
            'health': game_state.health if game_state else 100,
            'in_combat': game_state.in_combat if game_state else False,
            'enemies_nearby': game_state.enemies_nearby if game_state else 0,
            'stuck_status': stuck_status,
            'available_actions': available_actions,
            'last_3_actions': self.action_history[-3:] if hasattr(self, 'action_history') and len(self.action_history) >= 3 else [],
            'last_action_success': self.stats.get('action_success_count', 0) > 0,
        }
    
    def _build_reflection_context(self, vision_prompt: str, reasoning_prompt: str, game_state: Any) -> str:
        """Builds a full, rich context for meta-reasoning and learning.

        In contrast to `_build_action_context`, this method gathers a comprehensive
        set of information for deeper cognitive processes like world model updates,
        consciousness measurement, and long-term strategic planning.

        Args:
            vision_prompt: The prompt used for the latest vision analysis.
            reasoning_prompt: The prompt used for the latest reasoning task.
            game_state: The current game state object.

        Returns:
            A comprehensive, multi-part string containing detailed context from
            all major subsystems.
        """
        return self._build_integration_context(vision_prompt, reasoning_prompt, game_state)
    
    def _build_action_context(self, game_state: Any, scene_type: Any) -> Dict[str, Any]:
        """Builds a minimal, pragmatic context dictionary for fast action selection.

        This method is designed to provide LLMs with only the most essential,
        immediately actionable information, avoiding the overhead of a full,
        rich phenomenological context. This "sensorimotor context" is grounded
        and focused on what is needed for an immediate decision.

        Args:
            game_state: The current game state object.
            scene_type: The current scene type enum.

        Returns:
            A dictionary containing essential context for action planning,
            including scene, health, combat status, stuck status, available
            actions, and recent action history.
        """
        stuck_status = self._detect_stuck()
        
        # Scene-based action constraints
        available_actions = self._get_scene_constrained_actions(scene_type, game_state)
        
        return {
            'scene': scene_type.value if hasattr(scene_type, 'value') else str(scene_type),
            'health': game_state.health if game_state else 100,
            'in_combat': game_state.in_combat if game_state else False,
            'enemies_nearby': game_state.enemies_nearby if game_state else 0,
            'stuck_status': stuck_status,
            'available_actions': available_actions,
            'last_3_actions': self.action_history[-3:] if hasattr(self, 'action_history') and len(self.action_history) >= 3 else [],
            'last_action_success': self.stats.get('action_success_count', 0) > 0,
        }
    
    def _build_integration_context(self, vision_prompt: str, reasoning_prompt: str, game_state: Any) -> str:
        """Builds a comprehensive, multi-source context for deep synthesis.

        This internal helper function aggregates information from all major AGI
        subsystems to create a rich, detailed context. This context is primarily
        used by the highest-level LLMs (like GPT-5-thinking) to synthesize a
        unified narrative of the AGI's conscious experience. For faster, tactical
        decisions, `_build_action_context` should be used instead.

        Args:
            vision_prompt: The prompt used for the latest vision analysis.
            reasoning_prompt: The prompt used for the latest reasoning task.
            game_state: The current game state object.

        Returns:
            A formatted string containing a detailed breakdown of the AGI's
            current sensorimotor state, perceptual awareness, recent actions,
            consciousness coherence, and available expert perspectives.
        """
        context_parts = []
        
        # === IMMEDIATE SENSORIMOTOR STATE ===
        context_parts.append("=== IMMEDIATE SENSORIMOTOR STATE ===")
        if game_state:
            context_parts.append(f"Location: {game_state.location_name}")
            context_parts.append(f"Health: {game_state.health:.0f}/100 | Magicka: {game_state.magicka:.0f}/100 | Stamina: {game_state.stamina:.0f}/100")
            context_parts.append(f"Combat Status: {'IN COMBAT' if game_state.in_combat else 'Peaceful'}")
            if game_state.in_combat:
                context_parts.append(f"Threats: {game_state.enemies_nearby} enemies nearby")
            if game_state.nearby_npcs:
                context_parts.append(f"NPCs Present: {', '.join(game_state.nearby_npcs[:3])}")
        
        # === PERCEPTUAL AWARENESS ===
        context_parts.append("\n=== PERCEPTUAL AWARENESS ===")
        if self.current_perception:
            scene_type = self.current_perception.get('scene_type', 'UNKNOWN')
            context_parts.append(f"Scene Type: {scene_type}")
            
            objects = self.current_perception.get('objects', [])
            if objects:
                top_objects = [f"{obj[0]} ({obj[1]:.2f})" for obj in objects[:5]]
                context_parts.append(f"Detected Objects: {', '.join(top_objects)}")
            
            scene_probs = self.current_perception.get('scene_probs', {})
            if scene_probs:
                top_scene = max(scene_probs.items(), key=lambda x: x[1])
                context_parts.append(f"Scene Confidence: {top_scene[0]} ({top_scene[1]:.2f})")
        
        # === RECENT ACTIONS & OUTCOMES ===
        context_parts.append("\n=== RECENT ACTIONS & MOTOR HISTORY ===")
        if hasattr(self, 'action_history') and self.action_history:
            recent_actions = self.action_history[-5:]  # Last 5 actions
            context_parts.append(f"Recent Actions: {' → '.join(recent_actions)}")
        
        # === CONSCIOUSNESS COHERENCE ===
        context_parts.append("\n=== CONSCIOUSNESS COHERENCE ===")
        if hasattr(self, 'coherence_history') and self.coherence_history:
            recent_coherence = self.coherence_history[-3:]  # Last 3 measurements
            avg_coherence = sum(recent_coherence) / len(recent_coherence)
            context_parts.append(f"Recent Coherence (C): {avg_coherence:.3f}")
            if len(recent_coherence) >= 2:
                trend = recent_coherence[-1] - recent_coherence[-2]
                trend_word = "increasing" if trend > 0 else "decreasing" if trend < 0 else "stable"
                context_parts.append(f"Coherence Trend: {trend_word} (ΔC={trend:+.3f})")
        
        # === AVAILABLE EXPERT PERSPECTIVES ===
        context_parts.append("\n=== AVAILABLE EXPERT PERSPECTIVES ===")
        expert_list = []
        if self.moe:
            expert_list.append("• MoE: 2 Gemini (vision) + 1 Claude (reasoning) + 1 GPT-4o (integration)")
            expert_list.append("• Hyperbolic: 1 Nemotron (visual awareness) + 1 Qwen3-235B (meta-cognition)")
        if self.hybrid_llm:
            expert_list.append("• Hybrid: Gemini-2.5-Flash (vision) + Claude-Haiku-3.5 (reasoning)")
        if hasattr(self, 'perception_llm') and self.perception_llm:
            expert_list.append("• Local: Qwen3-VL (visual analysis)")
        if hasattr(self, 'rl_reasoning_llm') and self.rl_reasoning_llm:
            expert_list.append("• Local: Phi-4 (action reasoning)")
        
        if expert_list:
            context_parts.extend(expert_list)
        else:
            context_parts.append("Limited expert availability")
        
        # === PROMPTS FOR CONTEXT ===
        context_parts.append("\n=== CURRENT PROMPTS ===")
        context_parts.append(f"Vision Focus: {vision_prompt[:200]}...")
        context_parts.append(f"Reasoning Focus: {reasoning_prompt[:200]}...")
        
        return "\n".join(context_parts)
    
    def _get_scene_constrained_actions(self, scene_type: Any, game_state: Any) -> List[str]:
        """Filters the available actions based on the current scene type.

        This pragmatic approach provides sensorimotor grounding by ensuring that
        the AGI only considers actions that are contextually appropriate. It
        prevents the LLM from being overwhelmed with irrelevant choices, for
        example, by excluding exploration actions while in an inventory menu.

        Args:
            scene_type: The current scene type enum from the perception system.
            game_state: The current game state object.

        Returns:
            A list of action strings that are valid for the current scene.
        """
        from .perception import SceneType
        
        # Base actions available everywhere
        base_actions = ['look_around', 'wait']
        
        # Scene-specific actions
        if scene_type == SceneType.COMBAT:
            combat_actions = ['attack', 'power_attack', 'block', 'dodge']
            if game_state and game_state.magicka > 30:
                combat_actions.append('heal')
            if game_state and game_state.health < 30:
                combat_actions.append('retreat')
            return base_actions + combat_actions
        
        elif scene_type == SceneType.DIALOGUE:
            return base_actions + ['respond', 'ask_question', 'goodbye', 'activate']
        
        elif scene_type == SceneType.INVENTORY:
            # RECOMMENDATION 2: Disable 'explore' in inventory - only allow menu actions
            print("[ACTION-FILTER] Inventory scene: disabling explore, enabling menu actions only")
            return base_actions + ['activate', 'move_cursor', 'press_tab', 'equip_weapon', 'equip_armor', 'use_item', 'drop_item', 'close_menu']
        
        elif scene_type == SceneType.MAP:
            # RECOMMENDATION 2: Disable 'explore' in map - only allow map actions
            print("[ACTION-FILTER] Map scene: disabling explore, enabling map actions only")
            return base_actions + ['set_waypoint', 'fast_travel', 'close_menu', 'move_cursor']
        
        elif scene_type in [SceneType.INDOOR, SceneType.OUTDOOR]:
            exploration_actions = ['move_forward', 'move_backward', 'turn_left', 'turn_right', 'jump', 'sneak', 'activate']
            if game_state and not game_state.in_combat:
                exploration_actions.extend(['inventory', 'map'])
            return base_actions + exploration_actions
        
        # Default: all actions
        return base_actions + [
            'move_forward', 'move_backward', 'turn_left', 'turn_right',
            'attack', 'block', 'jump', 'sneak', 'activate',
            'inventory', 'map'
        ]
    
    async def _initialize_cloud_rl(self):
        """Initializes the cloud-enhanced Reinforcement Learning (RL) system.

        This method sets up the `CloudRLMemory` and `CloudRLAgent`, which
        leverage cloud-based LLMs for advanced RL functionalities. This includes
        using Retrieval-Augmented Generation (RAG) for contextual experience
        replay, LLM-based reward shaping, and Mixture of Experts (MoE) for
        evaluating action outcomes. It also handles loading a previously saved
        agent and memory to continue learning across sessions.
        """
        print("\n" + "=" * 70)
        print("INITIALIZING CLOUD-ENHANCED RL SYSTEM")
        print("=" * 70)
        print()
        
        try:
            # Determine which LLM to use
            llm_for_rl = self.hybrid_llm if self.hybrid_llm else None
            moe_for_rl = self.moe if self.config.rl_moe_evaluation and self.moe else None
            
            # Create RL memory config
            rl_memory_config = RLMemoryConfig(
                memory_dir=self.config.rl_memory_dir,
                max_experiences=100000,
                batch_size=32,
                use_rag=self.config.rl_use_rag,
                rag_top_k=5,
                use_cloud_reward_shaping=self.config.rl_cloud_reward_shaping,
                reward_shaping_frequency=10,
                use_moe_evaluation=self.config.rl_moe_evaluation,
                save_frequency=self.config.rl_save_frequency,
                auto_save=True,
            )
            
            # Initialize cloud RL memory
            print("[CLOUD-RL] Initializing memory system...")
            self.cloud_rl_memory = CloudRLMemory(
                config=rl_memory_config,
                hybrid_llm=llm_for_rl,
                moe=moe_for_rl,
            )
            print(f"[CLOUD-RL] [OK] Memory initialized: {len(self.cloud_rl_memory.experiences)} experiences loaded")
            
            if self.config.rl_use_rag:
                if self.cloud_rl_memory.collection:
                    print("[CLOUD-RL] [OK] RAG context fetching enabled (ChromaDB)")
                else:
                    print("[CLOUD-RL] ⚠️ RAG unavailable (install chromadb)")
            
            # Initialize cloud RL agent
            print("[CLOUD-RL] Initializing RL agent...")
            self.cloud_rl_agent = CloudRLAgent(
                state_dim=64,
                action_dim=20,  # Approximate number of action types
                memory=self.cloud_rl_memory,
                learning_rate=self.config.rl_learning_rate,
                gamma=0.99,
                epsilon_start=self.config.rl_epsilon_start,
                epsilon_end=0.01,
                epsilon_decay=0.995,
            )
            
            # Try to load saved agent
            agent_path = self.config.rl_memory_dir + "/cloud_rl_agent.pkl"
            self.cloud_rl_agent.load(agent_path)
            print("[CLOUD-RL] [OK] Agent initialized")
            
            # Report configuration
            print("\n[CLOUD-RL] Configuration:")
            print(f"  Cloud LLM reward shaping: {'[OK] Enabled' if self.config.rl_cloud_reward_shaping else '[X] Disabled'}")
            print(f"  MoE evaluation: {'[OK] Enabled' if self.config.rl_moe_evaluation and moe_for_rl else '[X] Disabled'}")
            print(f"  RAG context fetching: {'[OK] Enabled' if self.config.rl_use_rag else '[X] Disabled'}")
            print(f"  Memory persistence: [OK] Enabled (auto-save every {self.config.rl_save_frequency} experiences)")
            
            # Get and display stats
            stats = self.cloud_rl_memory.get_stats()
            print(f"\n[CLOUD-RL] Statistics:")
            print(f"  Total experiences: {stats['total_experiences']}")
            print(f"  Cloud evaluations: {stats['cloud_evaluations']}")
            print(f"  MoE evaluations: {stats['moe_evaluations']}")
            print(f"  Avg reward: {stats['avg_reward']:.3f}")
            print(f"  Success rate: {stats['successful_actions']/(stats['successful_actions']+stats['failed_actions']+1)*100:.1f}%")
            
            print("\n[CLOUD-RL] [OK] Cloud-enhanced RL system ready")
            
        except Exception as e:
            print(f"[CLOUD-RL] ⚠️ Failed to initialize: {e}")
            import traceback
            traceback.print_exc()
            self.cloud_rl_memory = None
            self.cloud_rl_agent = None
        
        print("=" * 70)
        print()
    
    async def _initialize_legacy_llms(self):
        """Initializes the legacy local LLM architecture.

        This method serves as a fallback for initializing the AGI's "brain"
        if the more advanced Hybrid and MoE systems are disabled. It sets up a
        single, locally-run LLM (typically via LM Studio) and connects it to
        all the necessary subsystems, including the base AGI orchestrator, the
        consciousness bridge, and various reasoning neurons.
        """
        print("\n[LEGACY] Initializing legacy local LLM architecture...")
        
        try:
            # Initialize huihui as the main LLM
            huihui_config = LMStudioConfig(
                base_url=self.config.base_config.lm_studio_url,
                model_name=self.config.huihui_cognition_model,
                temperature=0.7,
                max_tokens=2048
            )
            huihui_client = LMStudioClient(huihui_config)
            self.huihui_llm = ExpertLLMInterface(huihui_client)
            print("[LEGACY] [OK] Main cognition LLM initialized")
            
            # Initialize base Singularis AGI
            self.agi.config.lm_studio_url = self.config.base_config.lm_studio_url
            self.agi.config.model_name = self.config.huihui_cognition_model
            await self.agi.initialize_llm()
            print("[LEGACY] [OK] Base Singularis AGI initialized")
            
            # Connect Huihui to AGI orchestrator for dialectical reasoning (cycle 15)
            self.agi.consciousness_llm = self.huihui_llm
            self.consciousness_bridge.consciousness_llm = self.huihui_llm
            print("[LEGACY] [OK] Huihui connected to AGI orchestrator (enables dialectical synthesis)")
            
            # Connect to components
            self.rl_reasoning_neuron.llm_interface = self.huihui_llm
            self.meta_strategist.llm_interface = self.huihui_llm
            self.strategic_planner.llm_interface = self.huihui_llm
            self.quest_tracker.set_llm_interface(self.huihui_llm)
            self.dialogue_intelligence.set_llm_interface(self.huihui_llm)
            
            print("[LEGACY] [OK] Legacy LLM system ready")
            
        except Exception as e:
            print(f"[LEGACY] ⚠️ Failed to initialize: {e}")
            import traceback
            traceback.print_exc()

    async def _initialize_claude_meta(self) -> None:
        """Initializes an optional Claude client for auxiliary strategic reasoning.

        This method sets up a connection to the Claude API, if enabled in the
        configuration and if an API key is available. The initialized client is
        then added as an auxiliary interface to the `MetaStrategist`, allowing it
        to run in parallel with the primary reasoning LLM (like Huihui) to provide
        additional strategic insights.
        """

        if not self.config.enable_claude_meta:
            print("[CLAUDE] Auxiliary meta reasoning disabled via config")
            self.claude_meta_client = None
            return

        try:
            self.claude_meta_client = ClaudeClient(model=self.config.claude_model)
            if not self.claude_meta_client.is_available():
                print("[CLAUDE] API key missing (ANTHROPIC_API_KEY); skipping auxiliary meta reasoning")
                self.claude_meta_client = None
                return

            self.meta_strategist.add_auxiliary_interface(self.claude_meta_client, self.config.claude_model)
            print("[CLAUDE] [OK] Auxiliary meta reasoning client ready (runs alongside Huihui)")

        except Exception as exc:
            print(f"[CLAUDE] ⚠️ Failed to initialize auxiliary meta reasoning: {exc}")
            import traceback
            traceback.print_exc()
            self.claude_meta_client = None

    async def _initialize_gemini_vision(self) -> None:
        """Initializes an optional Gemini client for vision augmentation.

        If enabled in the configuration and an API key is provided, this method
        sets up a `GeminiClient` and attaches it to the `SkyrimPerception` module.
        This allows the perception system to complement its local analysis (from
        CLIP and Qwen) with the powerful vision capabilities of the Gemini model.
        """

        if not self.config.enable_gemini_vision:
            print("[GEMINI] Vision augmentation disabled via config")
            self.gemini_vision_client = None
            self.perception.set_gemini_analyzer(None)
            return

        try:
            self.gemini_vision_client = GeminiClient(model=self.config.gemini_model)
            if not self.gemini_vision_client.is_available():
                print("[GEMINI] API key missing (GEMINI_API_KEY); keeping local vision only")
                self.gemini_vision_client = None
                self.perception.set_gemini_analyzer(None)
                return

            self.perception.set_gemini_analyzer(self.gemini_vision_client)
            print("[GEMINI] [OK] Vision augmentation ready (complements Qwen/CLIP)")

        except Exception as exc:
            print(f"[GEMINI] ⚠️ Failed to initialize vision augmentation: {exc}")
            import traceback
            traceback.print_exc()
            self.gemini_vision_client = None
            self.perception.set_gemini_analyzer(None)

    async def _augment_with_gemini(self, perception: Dict[str, Any], cycle_count: int) -> Optional[str]:
        """Performs optional vision analysis with Gemini and augments the perception data.

        This method, if Gemini vision is enabled, sends the current game screenshot
        to the Gemini API for analysis. The analysis focuses on providing a concise
        tactical snapshot, identifying threats, interactables, and a recommended
        focus. The result is then attached to the main perception dictionary.
        Usage is throttled to complement, rather than overload, the main loop.

        Args:
            perception: The current perception dictionary, which must contain a
                'screenshot' key.
            cycle_count: The current main loop cycle number, used for throttling.

        Returns:
            The string analysis from Gemini if successful, otherwise None. The
            perception dictionary is modified in-place by adding a 'gemini_analysis'
            key.
        """

        if not self.config.enable_gemini_vision or self.gemini_vision_client is None:
            return None

        # Throttle Gemini usage so it complements rather than overloads the loop.
        # Changed from every 3rd to every 2nd cycle for faster testing
        if cycle_count % 2 != 0:
            return None

        screenshot = perception.get('screenshot')
        if screenshot is None:
            return None

        scene = perception.get('scene_type', SceneType.UNKNOWN)
        scene_label = scene.value if hasattr(scene, 'value') else str(scene)
        game_state: Optional[GameState] = perception.get('game_state')

        location = getattr(game_state, 'location_name', 'Unknown') if game_state else 'Unknown'
        health_value = getattr(game_state, 'health', None) if game_state else None
        health_str = f"{health_value:.0f}" if isinstance(health_value, (int, float)) else "unknown"
        in_combat = getattr(game_state, 'in_combat', False) if game_state else False
        enemies_value = getattr(game_state, 'enemies_nearby', None) if game_state else None
        enemies_str = str(enemies_value) if enemies_value is not None else "unknown"

        prompt = (
            "You supplement a local Skyrim perception module."
            f"\nScene type: {scene_label}"
            f"\nLocation: {location}"
            f"\nIn combat: {in_combat}"
            f"\nPlayer health: {health_str}/100"
            f"\nEnemies nearby: {enemies_str}"
            "\n\nProvide a concise tactical snapshot with bullets covering:"
            "\n1. Immediate threats or hazards"
            "\n2. Valuable interactables or loot"
            "\n3. Recommended tactical focus"
            "\nKeep the response under 90 words."
        )

        image_for_gemini = screenshot if screenshot.mode == "RGB" else screenshot.convert("RGB")

        try:
            analysis = await asyncio.wait_for(
                self.gemini_vision_client.analyze_image(
                    prompt=prompt,
                    image=image_for_gemini,
                    max_output_tokens=self.config.gemini_max_output_tokens,
                    temperature=0.4,
                ),
                timeout=12.0,
            )
        except asyncio.TimeoutError:
            if cycle_count % 20 == 0:
                print("[GEMINI] Analysis timed out (12s) - continuing with local perception")
            return None
        except Exception as exc:
            if cycle_count % 20 == 0:
                print(f"[GEMINI] Analysis error: {exc}")
            return None

        if not analysis:
            return None

        analysis = analysis.strip()
        if not analysis:
            return None

        perception['gemini_analysis'] = analysis
        return analysis

    async def autonomous_play(self, duration_seconds: Optional[int] = None):
        """Starts and manages the main autonomous gameplay loop.

        This is the core entry point for running the AGI. It orchestrates the
        entire gameplay process, deciding whether to run in a sequential
        (perceive-think-act) or asynchronous (parallel) mode based on the
        configuration. It handles initialization, gracefully manages the main
        loop's lifecycle, and triggers final cleanup and reporting upon completion
        or interruption.

        The main loop itself is delegated to either `_autonomous_play_async` or
        `_autonomous_play_sequential`.

        Args:
            duration_seconds: The total duration in seconds for the autonomous
                play session. If not provided, it defaults to the value set in
                the `SkyrimConfig`.
        """
        if duration_seconds is None:
            duration_seconds = self.config.autonomous_duration

        print(f"\n{'=' * 60}")
        print(f"STARTING AUTONOMOUS GAMEPLAY")
        print(f"Starting autonomous gameplay for {duration_seconds}s...")
        print(f"Cycle interval: {self.config.cycle_interval}s")
        if self.config.enable_async_reasoning:
            print(f"Async mode: ENABLED (reasoning runs in parallel with actions)")
            print(f"Max concurrent LLM calls: {self.config.max_concurrent_llm_calls}")
            print(f"Reasoning throttle: {self.config.reasoning_throttle}s")
        else:
            print(f"Async mode: DISABLED (sequential execution)")
        if self.config.enable_fast_loop:
            print(f"Fast reactive loop: ENABLED ({self.config.fast_loop_interval}s interval)")
            print(f"  Health threshold: {self.config.fast_health_threshold}%")
            print(f"  Danger threshold: {self.config.fast_danger_threshold} enemies")
        else:
            print(f"Fast reactive loop: DISABLED")
        print("=" * 60)
        print()

        # Test controller connection before starting
        await self._test_controller_connection()

        self.running = True
        self.action_executing = False  # Flag to prevent auxiliary exploration during main actions
        start_time = time.time()
        
        # ═══════════════════════════════════════════════════════════
        # START LIVE AUDIO STREAM (if enabled)
        # ═══════════════════════════════════════════════════════════
        if self.live_audio and self.config.enable_live_audio:
            try:
                # Initialize API clients first
                await self.live_audio.initialize()
                # Start streaming
                await self.live_audio.start()
                print("[LIVE AUDIO] 🎙️ Real-time commentary started")
                
                self.main_brain.record_output(
                    system_name='Live Audio Stream',
                    content="Real-time audio commentary activated",
                    metadata={'cycle': 0},
                    success=True
                )
            except Exception as e:
                print(f"[LIVE AUDIO] Failed to start: {e}")
        
        # Stuck detection tracking
        self.cloud_llm_failures = 0
        self.local_moe_failures = 0
        self.heuristic_failures = 0
        self.auxiliary_errors = 0
        self.last_successful_action = None
        self.repeated_action_count = 0
        self.last_visual_embedding = None
        self.visual_similarity_threshold = 0.95  # 95% similar = stuck
        self.sensorimotor_state = None
        self.sensorimotor_similarity_streak = 0
        
        # Fix 20: Performance monitoring dashboard
        self.dashboard_update_interval = 5  # Update every 5 cycles
        self.dashboard_last_update = 0
        self.sensorimotor_last_cycle = -1
        
        # Thresholds
        self.max_consecutive_failures = 5
        self.max_repeated_actions = 10
        
        # Initialize sensorimotor reasoning (Claude Haiku for speed)
        self.sensorimotor_llm = None
        if hasattr(self, 'hybrid_llm') and self.hybrid_llm:
            from singularis.llm.claude_client import ClaudeClient
            self.sensorimotor_llm = ClaudeClient(
                model=self.config.claude_sensorimotor_model,
                timeout=30  # Haiku is much faster
            )
            if self.sensorimotor_llm.is_available():
                print(f"[SENSORIMOTOR] [OK] {self.config.claude_sensorimotor_model} initialized for geospatial reasoning")
            else:
                print(f"[SENSORIMOTOR] ⚠️ {self.config.claude_sensorimotor_model} not available")
                self.sensorimotor_llm = None
        
        # Initialize Hebbian Integration System
        from singularis.skyrim.hebbian_integration import HebbianIntegrator
        self.hebbian = HebbianIntegrator(
            temporal_window=30.0,  # 30 second window for co-activation
            learning_rate=0.1,
            decay_rate=0.01
        )
        print("[HEBBIAN] [OK] Integration system initialized: 'Neurons that fire together, wire together'")
        
        # Initialize MAIN BRAIN (GPT-4o synthesis)
        from singularis.llm.openai_client import OpenAIClient
        from singularis.skyrim.main_brain import MainBrain
        
        self.openai_client = OpenAIClient(model="gpt-4o", timeout=120)
        self.main_brain = MainBrain(openai_client=self.openai_client)
        
        # Set session ID in dashboard streamer
        if hasattr(self, 'dashboard_streamer') and self.dashboard_streamer:
            self.dashboard_streamer.set_session_id(self.main_brain.session_id)
        
        if self.openai_client.is_available():
            print(f"[MAIN BRAIN] [BRAIN] Initialized - Session: {self.main_brain.session_id}")
            print(f"[MAIN BRAIN] GPT-4o will synthesize all outputs into session report")
        else:
            print("[MAIN BRAIN] ⚠️ OpenAI API key not found - fallback mode only")
        
        # Record initial system status
        self.main_brain.record_output(
            system_name='System Initialization',
            content=f"""AGI System Started
- LLM Mode: {'PARALLEL' if self.config.use_parallel_mode else 'Hybrid' if self.config.use_hybrid_llm else 'Local'}
- Cloud LLMs: {10 if self.config.use_parallel_mode else 1 if self.config.use_hybrid_llm else 0}
- Consciousness Nodes: {len(self.consciousness_monitor.registered_nodes)}
- Hebbian Learning: Active
- Sensorimotor: Claude Sonnet 4.5 (deep analysis)
- Background Reasoning: Claude Haiku 3.5 (fast tactical)
- Session ID: {self.main_brain.session_id}""",
            metadata={
                'llm_mode': 'PARALLEL' if self.config.use_parallel_mode else 'Hybrid',
                'total_nodes': len(self.consciousness_monitor.registered_nodes)
            },
            success=True
        )
        
        # Initialize LLM semaphore for resource management
        self.llm_semaphore = asyncio.Semaphore(self.config.max_concurrent_llm_calls)

        try:
            if self.config.enable_async_reasoning:
                # Run async mode with parallel reasoning and actions
                await self._autonomous_play_async(duration_seconds, start_time)
            else:
                # Run traditional sequential mode
                await self._autonomous_play_sequential(duration_seconds, start_time)
                
        except KeyboardInterrupt:
            print("\n\n[WARN] User interrupted - stopping gracefully...")
        except Exception as e:
            print(f"\n\n[ERROR] Error during gameplay: {e}")
            import traceback
            traceback.print_exc()
        finally:
            self.running = False
            print(f"\n{'=' * 60}")
            print("AUTONOMOUS GAMEPLAY COMPLETE")
            print(f"{'=' * 60}")
            
            # Cleanup connections
            await self._cleanup_connections()
            
            self._print_final_stats()
            
            # Generate Main Brain session report
            print(f"\n{'=' * 60}")
            print("GENERATING SESSION REPORT")
            print(f"{'=' * 60}")
            try:
                # Collect comprehensive telemetry from ALL subsystems
                print("[TELEMETRY] Collecting stats from all subsystems...")
                
                # PERCEPTION LAYER
                if hasattr(self, 'perception'):
                    perc_stats = {
                        'total_frames': self.stats.get('cycles_completed', 0),
                        'scene_classifications': self.stats.get('cycles_completed', 0)
                    }
                    self.main_brain.record_output(
                        system_name='Perception System',
                        content=f"Total frames processed: {perc_stats['total_frames']}",
                        metadata=perc_stats,
                        success=True
                    )
                
                # CONSCIOUSNESS LAYER
                if hasattr(self, 'consciousness_bridge'):
                    cons_stats = self.consciousness_bridge.get_stats()
                    self.main_brain.record_output(
                        system_name='Consciousness Bridge',
                        content=f"""Consciousness Statistics:
- Total Measurements: {cons_stats['total_measurements']}
- Avg Coherence: {cons_stats['avg_coherence']:.3f}
- Avg Consciousness Level: {cons_stats['avg_consciousness']:.3f}
- Trend: {cons_stats['trend']}
- Lumina Balance: Ontical={cons_stats['coherence_by_lumina'].get('ontical', 0):.3f}, Structural={cons_stats['coherence_by_lumina'].get('structural', 0):.3f}, Participatory={cons_stats['coherence_by_lumina'].get('participatory', 0):.3f}""",
                        metadata=cons_stats,
                        success=True
                    )
                
                # TEMPORAL BINDING
                if hasattr(self, 'temporal_tracker'):
                    temp_stats = self.temporal_tracker.get_statistics()
                    self.main_brain.record_output(
                        system_name='Temporal Binding',
                        content=f"""Temporal Coherence: {temp_stats.get('temporal_coherence', 0):.3f}
Unclosed Bindings: {temp_stats.get('unclosed_bindings', 0)}
Stuck Loops Detected: {temp_stats.get('stuck_loops', 0)}""",
                        metadata=temp_stats,
                        success=True
                    )
                
                # ENHANCED COHERENCE
                if hasattr(self, 'enhanced_coherence'):
                    enh_stats = self.enhanced_coherence.get_statistics()
                    self.main_brain.record_output(
                        system_name='Enhanced Coherence (4D)',
                        content=f"""4D Coherence Measurement:
- Integration: {enh_stats.get('integration_coherence', 0):.3f}
- Temporal: {enh_stats.get('temporal_coherence', 0):.3f}
- Causal: {enh_stats.get('causal_coherence', 0):.3f}
- Predictive: {enh_stats.get('predictive_coherence', 0):.3f}""",
                        metadata=enh_stats,
                        success=True
                    )
                
                # LUMEN INTEGRATION
                if hasattr(self, 'lumen_integration'):
                    lumen_stats = self.lumen_integration.get_statistics()
                    self.main_brain.record_output(
                        system_name='Lumen Integration',
                        content=f"""Lumen Balance Statistics:
- Avg Balance Score: {lumen_stats.get('avg_balance', 0):.3f}
- Imbalances Detected: {lumen_stats.get('imbalances_detected', 0)}""",
                        metadata=lumen_stats,
                        success=True
                    )
                
                # HIERARCHICAL MEMORY
                if hasattr(self, 'hierarchical_memory'):
                    mem_stats = self.hierarchical_memory.get_statistics()
                    self.main_brain.record_output(
                        system_name='Hierarchical Memory',
                        content=f"""Memory Statistics:
- Episodic Memories: {mem_stats.get('episodic_count', 0)}
- Semantic Patterns: {mem_stats.get('semantic_count', 0)}
- Consolidations: {mem_stats.get('consolidations', 0)}""",
                        metadata=mem_stats,
                        success=True
                    )
                
                # GPT-5 ORCHESTRATOR
                if hasattr(self, 'gpt5_orchestrator') and self.gpt5_orchestrator:
                    gpt5_stats = self.gpt5_orchestrator.get_stats()
                    self.main_brain.record_output(
                        system_name='GPT-5 Orchestrator',
                        content=f"""GPT-5 Meta-Cognitive Coordination:
- Total Messages: {gpt5_stats.get('total_messages', 0)}
- Total Responses: {gpt5_stats.get('total_responses', 0)}
- Registered Systems: {len(self.gpt5_orchestrator.registered_systems)}""",
                        metadata=gpt5_stats,
                        success=True
                    )
                
                # DOUBLE HELIX
                if hasattr(self, 'double_helix') and self.double_helix:
                    helix_stats = self.double_helix.get_stats()
                    self.main_brain.record_output(
                        system_name='Double Helix Architecture',
                        content=f"""Double Helix Integration:
- Total Nodes: {helix_stats.get('total_nodes', 0)}
- Analytical Nodes: {helix_stats.get('analytical_nodes', 0)}
- Intuitive Nodes: {helix_stats.get('intuitive_nodes', 0)}
- Avg Integration: {helix_stats.get('average_integration', 0):.3f}""",
                        metadata=helix_stats,
                        success=True
                    )
                
                # VOICE SYSTEM
                if hasattr(self, 'voice_system') and self.voice_system:
                    voice_stats = self.voice_system.get_stats()
                    self.main_brain.record_output(
                        system_name='Voice System',
                        content=f"""Voice Vocalization:
- Total Vocalizations: {voice_stats.get('total_vocalizations', 0)}
- By Priority: {voice_stats.get('by_priority', {})}""",
                        metadata=voice_stats,
                        success=True
                    )
                
                # VIDEO INTERPRETER
                if hasattr(self, 'video_interpreter') and self.video_interpreter:
                    video_stats = self.video_interpreter.get_stats()
                    self.main_brain.record_output(
                        system_name='Video Interpreter',
                        content=f"""Video Analysis:
- Total Interpretations: {video_stats.get('total_interpretations', 0)}
- Frames Analyzed: {video_stats.get('frames_analyzed', 0)}""",
                        metadata=video_stats,
                        success=True
                    )
                
                # HYBRID LLM
                if hasattr(self, 'hybrid_llm') and self.hybrid_llm:
                    hybrid_stats = self.hybrid_llm.get_stats()
                    self.main_brain.record_output(
                        system_name='Hybrid LLM (Gemini + Claude)',
                        content=f"""Hybrid LLM Usage:
- Total Calls: {hybrid_stats.get('total_calls', 0)}
- Gemini Calls: {hybrid_stats.get('gemini_calls', 0)}
- Claude Calls: {hybrid_stats.get('claude_calls', 0)}
- Fallback Activations: {hybrid_stats.get('fallback_activations', 0)}""",
                        metadata=hybrid_stats,
                        success=True
                    )
                
                # CLOUD RL
                if hasattr(self, 'cloud_rl_agent') and self.cloud_rl_agent:
                    try:
                        rl_stats = self.cloud_rl_agent.get_stats()
                        self.main_brain.record_output(
                            system_name='Cloud RL Agent',
                            content=f"""Cloud-Enhanced RL:
- Total Experiences: {rl_stats.get('total_experiences', 0)}
- Avg Reward: {rl_stats.get('avg_reward', 0):.3f}""",
                            metadata=rl_stats,
                            success=True
                        )
                    except:
                        pass
                
                # UNIFIED BEING STATE (Final Snapshot)
                if hasattr(self, 'being_state'):
                    final_snapshot = self.being_state.export_snapshot()
                    self.main_brain.record_output(
                        system_name='Unified BeingState (Final)',
                        content=f"""FINAL UNIFIED STATE:
Global Coherence: {final_snapshot['global_coherence']:.3f}
Lumina Balance: {final_snapshot['lumina']['balance']:.3f}
Consciousness: C={final_snapshot['consciousness']['coherence_C']:.3f}, Phi={final_snapshot['consciousness']['phi_hat']:.3f}
Spiral Stage: {final_snapshot['spiral']['stage']}
Emotion: {final_snapshot['emotion']['primary']}
Temporal Coherence: {final_snapshot['temporal']['temporal_coherence']:.3f}""",
                        metadata=final_snapshot,
                        success=True
                    )
                
                print("[TELEMETRY] [OK] All subsystem stats collected")
                
                # Add Wolfram summary to Main Brain before generating report
                if hasattr(self, 'wolfram_analyzer') and self.wolfram_analyzer:
                    wolfram_stats = self.wolfram_analyzer.get_stats()
                    if wolfram_stats['total_calculations'] > 0:
                        wolfram_summary = f"""Wolfram Alpha Telemetry Summary:
- Total Calculations: {wolfram_stats['total_calculations']}
- Avg Computation Time: {wolfram_stats['avg_computation_time']:.2f}s
- Total Computation Time: {wolfram_stats['total_computation_time']:.1f}s
- Analysis Types: Differential coherence, statistical analysis, predictive modeling

Wolfram provided rigorous mathematical analysis of AGI metrics throughout the session."""
                        
                        self.main_brain.record_output(
                            system_name='Wolfram Telemetry Summary',
                            content=wolfram_summary,
                            metadata=wolfram_stats,
                            success=True
                        )
                        print(f"[WOLFRAM] [OK] Summary added to Main Brain report")
                
                if hasattr(self, 'metacog_advisor') and self.metacog_advisor.client.is_available():
                    try:
                        snapshot = f"""Cycle: {self.stats['cycles_completed']}
Actions: {self.stats['actions_taken']}
Coherence: {self.current_consciousness.coherence if self.current_consciousness else 0.0:.3f}
Scene: {self.perception.last_scene_type.value if hasattr(self.perception, 'last_scene_type') else 'unknown'}"""
                        
                        metameta = await self.metacog_advisor.metameta_report(snapshot)
                        if metameta:
                            self.main_brain.record_output(
                                system_name='Meta-Meta-Meta-Cognition (GPT-4o)',
                                content=metameta,
                                metadata={'cycle': self.stats['cycles_completed']},
                                success=True
                            )
                            print(f"[METACOG] [OK] Meta-meta-meta report added")
                        
                        longterm = await self.metacog_advisor.deepseek_long_term_plan(snapshot)
                        if longterm:
                            self.main_brain.record_output(
                                system_name='Long-Term Planning (DeepSeek)',
                                content=longterm,
                                metadata={'cycle': self.stats['cycles_completed']},
                                success=True
                            )
                            print(f"[METACOG] [OK] Long-term plan added")
                    except Exception as e:
                        print(f"[METACOG] ⚠️ Metacognition advisor failed: {e}")
                
                # CONTINUUM PHASE 1: Generate observation report
                if hasattr(self, 'continuum'):
                    try:
                        continuum_report = self.continuum.generate_report()
                        print("\n" + continuum_report)
                        
                        self.main_brain.record_output(
                            system_name='Continuum Observer (Phase 1)',
                            content=continuum_report,
                            metadata=self.continuum.get_stats(),
                            success=True
                        )
                        print(f"[CONTINUUM] [OK] Observation report added to Main Brain")
                        
                        # Check if ready for Phase 2
                        if self.continuum.is_ready_for_phase2():
                            print(f"[CONTINUUM] [READY] READY FOR PHASE 2 UPGRADE")
                            print(f"[CONTINUUM] Advisory match rate > 30%")
                            print(f"[CONTINUUM] 100+ observations collected")
                        else:
                            stats = self.continuum.get_stats()
                            observations = stats.get('total_observations', 0)
                            match_rate = stats.get('advisory_match_rate', 0)
                            print(f"[CONTINUUM] ⚠️ Not ready for Phase 2")
                            print(f"[CONTINUUM] Observations: {observations}/100")
                            print(f"[CONTINUUM] Match rate: {match_rate:.1%}/30%")
                    except Exception as e:
                        print(f"[CONTINUUM] ⚠️ Report generation failed: {e}")
                
                report_path = await self.main_brain.generate_session_markdown()
                print(f"\n[MAIN BRAIN] [BRAIN] Session report generated!")
                print(f"[MAIN BRAIN] [FILE] Location: {report_path}")
                print(f"[MAIN BRAIN] [TARGET] Session ID: {self.main_brain.session_id}")
                
                # Print Wolfram contribution
                if hasattr(self, 'wolfram_analyzer') and self.wolfram_analyzer:
                    wolfram_stats = self.wolfram_analyzer.get_stats()
                    if wolfram_stats['total_calculations'] > 0:
                        print(f"[MAIN BRAIN] 🔬 Wolfram calculations: {wolfram_stats['total_calculations']}")
            except Exception as e:
                print(f"[MAIN BRAIN] ⚠️ Failed to generate report: {e}")
            
            # Cleanup aiohttp sessions
            print("\n[CLEANUP] Closing HTTP sessions...")
            try:
                if self.openai_client:
                    await self.openai_client.close()
                if hasattr(self, 'hybrid_llm') and self.hybrid_llm:
                    await self.hybrid_llm.close()
                if hasattr(self, 'moe') and self.moe:
                    await self.moe.close()
                if hasattr(self, 'local_moe') and self.local_moe:
                    await self.local_moe.close()
                if hasattr(self, 'sensorimotor_llm') and self.sensorimotor_llm:
                    await self.sensorimotor_llm.close()
                if hasattr(self, 'state_printer_llm') and hasattr(self.state_printer_llm, 'client'):
                    if hasattr(self.state_printer_llm.client, 'session') and self.state_printer_llm.client.session:
                        await self.state_printer_llm.client.session.close()
                # Close Hyperbolic clients
                if hasattr(self, 'hyperbolic_reasoning') and self.hyperbolic_reasoning:
                    await self.hyperbolic_reasoning.close()
                if hasattr(self, 'hyperbolic_vision') and self.hyperbolic_vision:
                    await self.hyperbolic_vision.close()
                # Close Wolfram analyzer
                if hasattr(self, 'wolfram_analyzer') and self.wolfram_analyzer:
                    await self.wolfram_analyzer.close()
                # Close Continuum
                if hasattr(self, 'continuum') and self.continuum:
                    await self.continuum.cleanup()
                print("[CLEANUP] [OK] All sessions closed")
            except Exception as e:
                print(f"[CLEANUP] Warning: {e}")

    async def _autonomous_play_async(self, duration_seconds: int, start_time: float):
        """Runs the AGI's main gameplay loop in asynchronous, parallel mode.

        This is the core of the AGI's parallel architecture. It launches and
        manages several concurrent asyncio tasks for perception, reasoning,
        action execution, and learning. This design allows the AGI to continue
        acting and perceiving the world without being blocked by computationally
        expensive reasoning or learning processes (like LLM calls).

        Args:
            duration_seconds: The total duration for the gameplay session.
            start_time: The timestamp when the session began.
        """
        print("[ASYNC] Starting parallel execution loops...")
        
        # Start all async loops concurrently
        perception_task = asyncio.create_task(self._perception_loop(duration_seconds, start_time))
        reasoning_task = asyncio.create_task(self._reasoning_loop(duration_seconds, start_time))
        action_task = asyncio.create_task(self._action_loop(duration_seconds, start_time))
        learning_task = asyncio.create_task(self._learning_loop(duration_seconds, start_time))
        
        # Start fast reactive loop if enabled
        tasks = [perception_task, reasoning_task, action_task, learning_task]
        
        # PHASE 1.1: DISABLED - Fast reactive loop causes action conflicts
        # Multiple action executors fighting for control
        # if self.config.enable_fast_loop:
        #     fast_loop_task = asyncio.create_task(self._fast_reactive_loop(duration_seconds, start_time))
        #     tasks.append(fast_loop_task)
        #     print("[ASYNC] Fast reactive loop ENABLED")
        # else:
        print("[ASYNC] Fast reactive loop DISABLED (Phase 1 architecture fix)")
        
        # PHASE 1.1: DISABLED - Auxiliary exploration loop overrides planned actions
        # Causes race conditions with main reasoning loop
        # aux_exploration_task = asyncio.create_task(self._auxiliary_exploration_loop(duration_seconds, start_time))
        # tasks.append(aux_exploration_task)
        print("[ASYNC] Auxiliary exploration loop DISABLED (Phase 1 architecture fix)")
        
        # Wait for all tasks to complete (or any to fail)
        await asyncio.gather(*tasks, return_exceptions=True)
        
        print("[ASYNC] All parallel loops completed")

    async def _auxiliary_exploration_loop(self, duration_seconds: int, start_time: float):
        """Manages a continuous, heuristic-based exploration pipeline.

        This loop runs independently of the main reasoning cycle to ensure the
        character remains active and responsive, even when the primary LLM-based
        reasoning is slow. It handles basic movement, camera control, and simple
        environmental interactions using a set of predefined rules and timers,
        preventing the AGI from appearing idle.

        Args:
            duration_seconds: The total duration for the gameplay session.
            start_time: The timestamp when the session began.
        """
        print("[AUX-EXPLORE] Auxiliary exploration loop started")
        print("[AUX-EXPLORE] Interval: 3.0s (independent of main reasoning)")
        
        cycle_count = 0
        last_move_time = time.time()
        last_look_time = time.time()
        last_direction_change = time.time()
        last_camera_center = time.time()
        
        # Movement parameters
        move_interval = 3.0  # Move forward every 3 seconds
        look_interval = 2.0  # Look around every 2 seconds
        direction_change_interval = 10.0  # Change direction every 10 seconds
        camera_center_interval = 15.0  # Re-center camera every 15 seconds
        
        # Camera tracking
        vertical_bias = 0  # Track if camera is looking too far up/down
        
        import random
        
        while self.running and (time.time() - start_time) < duration_seconds:
            try:
                cycle_count += 1
                current_time = time.time()
                
                # Tick rule engine cycle
                if hasattr(self, 'rule_engine'):
                    self.rule_engine.tick_cycle()
                
                # Get current game state (non-blocking)
                try:
                    perception = await asyncio.wait_for(
                        self.perception.perceive(),
                        timeout=1.0
                    )
                    game_state = perception.get('game_state')
                except asyncio.TimeoutError:
                    game_state = None
                
                # Skip if in menu or dialogue
                if game_state:
                    scene_type = perception.get('scene_type', SceneType.UNKNOWN)
                    if scene_type in [SceneType.DIALOGUE, SceneType.INVENTORY, SceneType.MAP]:
                        await asyncio.sleep(1.0)
                        continue
                    
                    # Skip if in combat (let main reasoning handle it)
                    if game_state.in_combat:
                        await asyncio.sleep(1.0)
                        continue
                
                # MOVE FORWARD - Keep exploring
                # Only if no main action is executing (don't interfere)
                if current_time - last_move_time >= move_interval and not self.action_executing:
                    try:
                        if cycle_count % 10 == 0:
                            print(f"[AUX-EXPLORE] Moving forward (cycle {cycle_count})")
                        
                        from singularis.skyrim.actions import Action, ActionType
                        move_action = Action(ActionType.MOVE_FORWARD, duration=1.5)
                        await self.actions.execute(move_action)
                        last_move_time = current_time
                        
                        # Occasional jump for terrain navigation
                        if random.random() < 0.2:  # 20% chance
                            await asyncio.sleep(0.3)
                            jump_action = Action(ActionType.JUMP, duration=0.3)
                            await self.actions.execute(jump_action)
                            if cycle_count % 10 == 0:
                                print(f"[AUX-EXPLORE] Jump for terrain navigation")
                    
                    except Exception as e:
                        self.auxiliary_errors += 1
                        if cycle_count % 30 == 0:
                            print(f"[AUX-EXPLORE] Move error: {e} (errors: {self.auxiliary_errors})")
                        if self.auxiliary_errors >= 20:
                            print(f"[STUCK-DETECTION] ⚠️ Auxiliary exploration has {self.auxiliary_errors} errors, pausing for 5s")
                            await asyncio.sleep(5.0)
                            self.auxiliary_errors = 0
                
                # LOOK AROUND - Explore environment
                # Only if no main action is executing (don't interfere)
                if current_time - last_look_time >= look_interval and not self.action_executing:
                    try:
                        from singularis.skyrim.actions import Action, ActionType
                        
                        # Bias camera to stay level - prefer opposite direction if too far up/down
                        if vertical_bias > 2:  # Looking too far down
                            look_direction = 'look_up'
                            vertical_bias -= 1
                        elif vertical_bias < -2:  # Looking too far up
                            look_direction = 'look_down'
                            vertical_bias += 1
                        else:
                            # Random camera movement with slight preference for horizontal
                            choices = ['look_left', 'look_right', 'look_left', 'look_right', 'look_up', 'look_down']
                            look_direction = random.choice(choices)
                            
                            # Track vertical bias
                            if look_direction == 'look_up':
                                vertical_bias -= 1
                            elif look_direction == 'look_down':
                                vertical_bias += 1
                        
                        look_types = {
                            'look_left': ActionType.LOOK_LEFT,
                            'look_right': ActionType.LOOK_RIGHT,
                            'look_up': ActionType.LOOK_UP,
                            'look_down': ActionType.LOOK_DOWN
                        }
                        look_duration = random.uniform(0.3, 0.8)
                        
                        if cycle_count % 10 == 0:
                            print(f"[AUX-EXPLORE] Looking around: {look_direction} (v-bias: {vertical_bias})")
                        
                        look_action = Action(look_types[look_direction], duration=look_duration)
                        await self.actions.execute(look_action)
                        last_look_time = current_time
                    
                    except Exception as e:
                        self.auxiliary_errors += 1
                        if cycle_count % 30 == 0:
                            print(f"[AUX-EXPLORE] Look error: {e} (errors: {self.auxiliary_errors})")
                        if self.auxiliary_errors >= 20:
                            print(f"[STUCK-DETECTION] ⚠️ Auxiliary exploration has {self.auxiliary_errors} errors, pausing for 5s")
                            await asyncio.sleep(5.0)
                            self.auxiliary_errors = 0
                
                # CHANGE DIRECTION - Avoid getting stuck
                # Only if no main action is executing (don't interfere)
                if current_time - last_direction_change >= direction_change_interval and not self.action_executing:
                    try:
                        from singularis.skyrim.actions import Action, ActionType
                        # Turn to a new direction
                        turn_types = {'look_left': ActionType.LOOK_LEFT, 'look_right': ActionType.LOOK_RIGHT}
                        turn_direction = random.choice(list(turn_types.keys()))
                        turn_amount = random.uniform(1.0, 2.0)
                        
                        print(f"[AUX-EXPLORE] Changing direction: {turn_direction} for {turn_amount:.1f}s")
                        turn_action = Action(turn_types[turn_direction], duration=turn_amount)
                        await self.actions.execute(turn_action)
                        last_direction_change = current_time
                    
                    except Exception as e:
                        self.auxiliary_errors += 1
                        print(f"[AUX-EXPLORE] Direction change error: {e} (errors: {self.auxiliary_errors})")
                        if self.auxiliary_errors >= 20:
                            print(f"[STUCK-DETECTION] ⚠️ Auxiliary exploration has {self.auxiliary_errors} errors, pausing for 5s")
                            await asyncio.sleep(5.0)
                            self.auxiliary_errors = 0
                
                # CENTER CAMERA - Reset vertical view periodically
                # Only if no main action is executing (don't interfere)
                if current_time - last_camera_center >= camera_center_interval and not self.action_executing:
                    try:
                        from singularis.skyrim.actions import Action, ActionType
                        
                        # Center camera by looking in opposite direction of bias
                        if vertical_bias > 0:  # Looking down
                            print(f"[AUX-EXPLORE] Centering camera (looking up to correct v-bias: {vertical_bias})")
                            center_action = Action(ActionType.LOOK_UP, duration=0.5 * abs(vertical_bias))
                            await self.actions.execute(center_action)
                            vertical_bias = 0  # Reset bias
                        elif vertical_bias < 0:  # Looking up
                            print(f"[AUX-EXPLORE] Centering camera (looking down to correct v-bias: {vertical_bias})")
                            center_action = Action(ActionType.LOOK_DOWN, duration=0.5 * abs(vertical_bias))
                            await self.actions.execute(center_action)
                            vertical_bias = 0  # Reset bias
                        
                        last_camera_center = current_time
                    
                    except Exception as e:
                        self.auxiliary_errors += 1
                        print(f"[AUX-EXPLORE] Camera center error: {e} (errors: {self.auxiliary_errors})")
                        if self.auxiliary_errors >= 20:
                            print(f"[STUCK-DETECTION] ⚠️ Auxiliary exploration has {self.auxiliary_errors} errors, pausing for 5s")
                            await asyncio.sleep(5.0)
                            self.auxiliary_errors = 0
                
                # Sleep to maintain interval
                await asyncio.sleep(0.5)
            
            except asyncio.CancelledError:
                print(f"[AUX-EXPLORE] Loop cancelled gracefully at cycle {cycle_count}")
                break
            except Exception as e:
                print(f"[AUX-EXPLORE] Error in cycle {cycle_count}: {e}")
                import traceback
                traceback.print_exc()
                await asyncio.sleep(1.0)
        
        print(f"[AUX-EXPLORE] Loop ended after {cycle_count} cycles")

    async def _perception_loop(self, duration_seconds: int, start_time: float):
        """Continuously perceives the game world and populates the reasoning queue.

        This asynchronous loop is responsible for capturing the game state at regular
        intervals. It performs the full perception pipeline, including screen
        capture, visual analysis (CLIP, Qwen, Gemini), and game state extraction.
        To prevent the reasoning loop from being overwhelmed, it uses an adaptive
        throttling mechanism that slows down the perception rate if the queue of
        pending perceptions becomes too full.

        Args:
            duration_seconds: The total duration for the gameplay session.
            start_time: The timestamp when the session began.
        """
        print("[PERCEPTION] Loop started")
        print(f"[PERCEPTION] Qwen3-VL status: {'ENABLED' if self.perception_llm else 'DISABLED (None)'}")
        cycle_count = 0
        skip_count = 0
        
        while self.running and (time.time() - start_time) < duration_seconds:
            try:
                cycle_count += 1
                
                # Check queue status BEFORE perceiving to avoid wasted work
                queue_size = self.perception_queue.qsize()
                max_queue_size = self.perception_queue.maxsize
                
                # If queue is full, skip perception entirely and wait
                if queue_size >= max_queue_size:
                    skip_count += 1
                    if skip_count % 20 == 0:  # Only log every 20 skips
                        print(f"[PERCEPTION] Queue full, skipped {skip_count} cycles")
                    await asyncio.sleep(2.0)  # Wait 2s when queue is full to allow processing
                    continue
                
                perception = await self.perception.perceive()
                game_state = perception.get('game_state')
                scene_type = perception.get('scene_type', SceneType.UNKNOWN)

                state_dict = game_state.to_dict() if game_state else {}
                scene_name = scene_type.value if hasattr(scene_type, 'value') else str(scene_type)

                # Update support subsystems with latest state
                if game_state:
                    self.smart_navigator.learn_location(
                        game_state.location_name,
                        {
                            'in_combat': game_state.in_combat,
                            'scene': scene_name,
                        }
                    )
                    self.character_progression.update_from_state(state_dict)
                    self.inventory_manager.update_from_state(state_dict)
                    self.analytics.update_state(state_dict)

                loop_settings = self.loop_manager.update_for_state(scene_name, state_dict)

                # Adaptive throttling based on queue fullness
                base_interval = loop_settings.perception_interval
                if queue_size >= max_queue_size * 0.8:
                    throttle_delay = max(1.0, base_interval * 3)
                    if cycle_count % 5 == 0:
                        print(f"[PERCEPTION] Queue {queue_size}/{max_queue_size} - heavy throttling ({throttle_delay:.2f}s)")
                elif queue_size >= max_queue_size * 0.6:
                    throttle_delay = max(0.5, base_interval * 2)
                    if cycle_count % 10 == 0:
                        print(f"[PERCEPTION] Queue {queue_size}/{max_queue_size} - moderate throttling ({throttle_delay:.2f}s)")
                elif queue_size >= max_queue_size * 0.4:
                    throttle_delay = max(0.3, base_interval * 1.5)
                else:
                    throttle_delay = base_interval
                
                # Enhance perception with Qwen3-VL using CLIP data (not raw images)
                # DISABLED - Qwen3-VL is too slow and times out, adding 60s overhead
                if False and self.perception_llm and cycle_count % 10 == 0:  # Disabled for performance
                    print(f"[QWEN3-VL] Cycle {cycle_count}: Starting CLIP-based analysis...")
                    try:
                        print(f"[QWEN3-VL] DEBUG: Extracting perception data...")
                        print(f"[QWEN3-VL] DEBUG: game_state type: {type(game_state)}")
                        print(f"[QWEN3-VL] DEBUG: scene_type: {scene_type}")
                        objects = perception.get('objects', [])
                        print(f"[QWEN3-VL] DEBUG: objects count: {len(objects)}")
                        scene_probs = perception.get('scene_probs', {})
                        print(f"[QWEN3-VL] DEBUG: scene_probs: {scene_probs}")
                        
                        # Build rich context from CLIP analysis
                        print(f"[QWEN3-VL] DEBUG: Building context string...")
                        # Objects are tuples (label, confidence), not dicts
                        try:
                            objects_list = ', '.join([f"{obj[0]} ({obj[1]:.2f})" for obj in objects[:5]])
                        except Exception as e:
                            print(f"[QWEN3-VL] DEBUG: Failed to build objects_list: {e}")
                            objects_list = ''
                        print(f"[QWEN3-VL] DEBUG: objects_list: {objects_list}")
                        scene_confidence = max(scene_probs.values()) if scene_probs else 0.0
                        print(f"[QWEN3-VL] DEBUG: scene_confidence: {scene_confidence}")
                        
                        # Convert scene_type enum to string
                        scene_type_str = scene_type.value if hasattr(scene_type, 'value') else str(scene_type)
                        print(f"[QWEN3-VL] DEBUG: scene_type_str: {scene_type_str}")
                        
                        clip_context = f"""Analyze Skyrim gameplay based on CLIP visual perception:

CLIP Scene Classification:
- Scene type: {scene_type_str} (confidence: {scene_confidence:.2f})
- Detected objects: {objects_list if objects_list else 'none detected'}

Game State:
- Location: {game_state.location_name if game_state else 'unknown'}
- Health: {game_state.health if game_state else 100:.0f}/100
- In combat: {game_state.in_combat if game_state else False}
- Enemies nearby: {game_state.enemies_nearby if game_state else 0}
- NPCs nearby: {len(game_state.nearby_npcs) if game_state and game_state.nearby_npcs else 0}

Based on this visual and contextual data, provide:
1. Environment description and spatial awareness
2. Potential threats or opportunities
3. Recommended actions or focus areas
4. Strategic considerations"""
                        
                        print(f"[QWEN3-VL] Analyzing CLIP perception (cycle {cycle_count})...")
                        try:
                            # Add timeout to prevent hanging
                            visual_analysis = await asyncio.wait_for(
                                self.perception_llm.generate(
                                    prompt=clip_context,
                                    max_tokens=256
                                ),
                                timeout=180.0  # 180 second timeout (Qwen3-VL 30B needs time to load)
                            )
                            perception['visual_analysis'] = visual_analysis.get('content', '')
                            # Log every Qwen3-VL analysis (since it only runs every 2nd cycle anyway)
                            print(f"[QWEN3-VL] Analysis: {visual_analysis.get('content', '')[:150]}...")
                        except asyncio.TimeoutError:
                            print(f"[QWEN3-VL] Analysis timed out after 180s")
                            perception['visual_analysis'] = "[TIMEOUT] Visual analysis timed out"
                        
                    except Exception as e:
                        # Log errors but don't break the loop
                        if cycle_count % 30 == 0:
                            print(f"[QWEN3-VL] Analysis failed: {e}")
                            import traceback
                            traceback.print_exc()

                # Optional Gemini augmentation after CLIP/Qwen analysis
                gemini_summary = await self._augment_with_gemini(perception, cycle_count)
                if gemini_summary:
                    print(f"[GEMINI] Vision augment: {gemini_summary[:140]}...")
                
                self.current_perception = perception
                
                # Queue perception for reasoning (should succeed since we checked above)
                try:
                    self.perception_queue.put_nowait({
                        'perception': perception,
                        'cycle': cycle_count,
                        'timestamp': time.time()
                    })
                except asyncio.QueueFull:
                    # This shouldn't happen often since we check above
                    skip_count += 1
                
                # Wait before next perception (adaptive)
                await asyncio.sleep(throttle_delay)
                
            except Exception as e:
                print(f"[PERCEPTION] Error: {e}")
                import traceback
                traceback.print_exc()
                await asyncio.sleep(1.0)
        
        print(f"[PERCEPTION] Loop ended (skipped {skip_count} cycles)")

    async def _reasoning_loop(self, duration_seconds: int, start_time: float):
        """Runs the main asynchronous cognitive processing loop.

        This is the "thinking" part of the AGI's asynchronous architecture. It
        continuously dequeues perception data, processes it through a complex
        series of cognitive subsystems, and ultimately plans an action. Key
        responsibilities include:
        - Running the HaackLang cognitive calculus and Infinity Engine rhythms.
        - Updating the central `BeingState`.
        - Computing consciousness and Lumen balance.
        - Invoking advanced reasoning systems like Wolfram Alpha and GPT-5.
        - Performing dialectical reasoning with the full Singularis orchestrator.
        - Planning the next action by synthesizing inputs from RL, heuristics,
          and multiple LLM architectures.
        - Routing the final action to the `ActionArbiter` for execution.

        Args:
            duration_seconds: The total duration for the gameplay session.
            start_time: The timestamp when the session began.
        """
        print("[REASONING] Loop started")
        
        while self.running and (time.time() - start_time) < duration_seconds:
            try:
                # Get next perception (wait if none available)
                perception_data = await asyncio.wait_for(
                    self.perception_queue.get(),
                    timeout=5.0
                )
                
                # Throttle reasoning to prevent overload
                time_since_last = time.time() - self.last_reasoning_time
                reasoning_throttle = self.loop_manager.get_interval('reasoning')
                if time_since_last < reasoning_throttle:
                    await asyncio.sleep(reasoning_throttle - time_since_last)
                
                self.last_reasoning_time = time.time()
                
                perception = perception_data['perception']
                cycle_count = perception_data['cycle']
                self.cycle_count = cycle_count  # Update global cycle count for rate limiting
                
                # Tick OMEGA Hyperhelix phase model
                if hasattr(self, 'omega') and self.omega:
                    try:
                        self.omega.tick(0.5)
                    except Exception:
                        pass
                
                # MATRIX: resolve weights anchored to coherence/competence
                try:
                    if hasattr(self, 'matrix_manager') and self.matrix_manager:
                        ctx = {}
                        if hasattr(self, 'current_consciousness') and self.current_consciousness:
                            ctx['coherence'] = float(getattr(self.current_consciousness, 'coherence', 0.6))
                        # Enhanced overall coherence if available
                        if hasattr(self, 'enhanced_coherence') and self.enhanced_coherence:
                            try:
                                coh_stats = self.enhanced_coherence.get_statistics()
                                if coh_stats and 'overall' in coh_stats:
                                    ctx['coherence_overall'] = float(coh_stats['overall'])
                            except Exception:
                                pass
                        total_actions = self.stats.get('actions_taken', 0)
                        succ = self.stats.get('action_success_count', 0)
                        if total_actions > 0:
                            ctx['competence'] = max(0.0, min(1.0, succ / total_actions))
                            ctx['success_rate'] = ctx['competence']
                        if hasattr(self, 'last_curriculum_reward_delta'):
                            ctx['curriculum_reward_delta'] = float(self.last_curriculum_reward_delta)
                        weights = self.matrix_manager.resolve_weights(ctx)
                        if hasattr(self, 'omega') and self.omega and hasattr(self.omega, 'nodes'):
                            for mid, w in weights.items():
                                node = self.omega.nodes.get(mid)
                                if node is not None:
                                    node.contribution_weight = w
                    
                    # Occasionally co-design curriculum suggestions
                    if hasattr(self, 'matrix_manager') and self.matrix_manager and cycle_count % 20 == 0:
                        _ = self.matrix_manager.propose_curriculum(count=3)
                    # Periodic consolidation to stabilize long-term knowledge
                    if hasattr(self, 'matrix_manager') and self.matrix_manager and cycle_count % 100 == 0:
                        self.matrix_manager.ewc_consolidate()
                except Exception:
                    pass
                
                print(f"\n[REASONING] Processing cycle {cycle_count}")
                
                # ═══════════════════════════════════════════════════════════
                # SCCE + HaackLang - Cognitive Calculus
                # ═══════════════════════════════════════════════════════════
                if self.haack_bridge and cycle_count % self.config.scce_frequency == 0:
                    try:
                        from ..skyrim.Haacklang.src.haackc.scc_calculus import cognition_step
                        
                        game_state = perception['game_state']
                        
                        # Update truthvalues from current perception
                        if game_state:
                            # Danger from combat state, health, enemies
                            danger = 0.0
                            if game_state.in_combat:
                                danger += 0.5
                            if game_state.health_percent < 50:
                                danger += 0.3
                            if hasattr(game_state, 'enemy_count') and game_state.enemy_count > 0:
                                danger += min(0.2 * game_state.enemy_count, 0.5)
                            
                            self.haack_bridge.update_truthvalue('danger', 'perception', min(1.0, danger))
                            
                            # Fear from emotion system
                            if hasattr(self, 'emotion_integration') and self.emotion_integration:
                                emotion_state = self.emotion_integration.emotion_system.get_state()
                                self.haack_bridge.update_truthvalue('fear', 'perception', emotion_state.get('fear', 0.0))
                                self.haack_bridge.update_truthvalue('stress', 'perception', emotion_state.get('stress', 0.0))
                            
                            # Trust from consciousness coherence
                            if hasattr(self, 'current_consciousness') and self.current_consciousness:
                                self.haack_bridge.update_truthvalue('trust', 'strategic', self.current_consciousness.coherence)
                        
                        # Run SCCE cognition step (temporal cognitive dynamics)
                        scce_stats = cognition_step(
                            truthvalues=self.haack_bridge.runtime.truthvalues,
                            tracks=self.haack_bridge.runtime.scheduler.tracks,
                            global_beat=self.haack_bridge.runtime.scheduler.global_beat,
                            profile=self.scce_profile,
                            verbose=False
                        )
                        
                        # Execute HaackLang contexts and guards
                        haack_result = await self.haack_bridge.cycle(
                            perception=perception,
                            subsystem_outputs={}
                        )
                        
                        # Handle any actions from HaackLang guards
                        if haack_result and haack_result.get('action'):
                            action_name = haack_result['action']
                            print(f"[HAACK] Guard triggered: {action_name}")
                            
                            # Record in double helix
                            if self.double_helix:
                                self.double_helix.record_activation("haacklang_guard", True, 1.0)
                        
                        # Log SCCE stats every 10 cycles
                        if cycle_count % 10 == 0:
                            print(f"[SCCE] Coherence: {scce_stats['coherence']:.3f} | Profile: {scce_stats['profile']}")
                            
                            # Get evolved cognitive state
                            danger_tv = self.haack_bridge.get_truthvalue('danger')
                            fear_tv = self.haack_bridge.get_truthvalue('fear')
                            trust_tv = self.haack_bridge.get_truthvalue('trust')
                            stress_tv = self.haack_bridge.get_truthvalue('stress')
                            
                            if danger_tv:
                                print(f"[SCCE]   Danger: P={danger_tv.get('perception'):.2f} S={danger_tv.get('strategic'):.2f} I={danger_tv.get('intuition'):.2f}")
                            if fear_tv:
                                print(f"[SCCE]   Fear:   P={fear_tv.get('perception'):.2f} S={fear_tv.get('strategic'):.2f} I={fear_tv.get('intuition'):.2f}")
                            if trust_tv:
                                print(f"[SCCE]   Trust:  P={trust_tv.get('perception'):.2f} S={trust_tv.get('strategic'):.2f} I={trust_tv.get('intuition'):.2f}")
                            if stress_tv:
                                print(f"[SCCE]   Stress: P={stress_tv.get('perception'):.2f} S={stress_tv.get('strategic'):.2f} I={stress_tv.get('intuition'):.2f}")
                        
                    except Exception as e:
                        if cycle_count % 20 == 0:
                            print(f"[SCCE] Error: {e}")
                
                # ═══════════════════════════════════════════════════════════
                # INFINITY ENGINE - Adaptive Rhythmic Cognition
                # ═══════════════════════════════════════════════════════════
                if self.config.use_infinity_engine and cycle_count % 2 == 0:  # Run every 2 cycles
                    try:
                        # Get current track states from HaackLang if available
                        track_states = {}
                        if self.haack_bridge and self.rhythm_learner:
                            scheduler = self.haack_bridge.runtime.scheduler
                            for track in scheduler.tracks:
                                # Get current phase (normalized to 0-2π)
                                phase = (scheduler.global_beat % track.period) / track.period * 2 * 3.14159
                                # Get current period (may have been adapted)
                                period = self.rhythm_learner.get_current_period(track.name)
                                if period is None:
                                    period = track.period
                                track_states[track.name] = (phase, period)
                        
                        # Update meta-contexts
                        if self.meta_context:
                            # Build mock cognitive state for context updates
                            mock_state = type('obj', (object,), {
                                'truth_values': {},
                                'game_state': game_state
                            })()
                            
                            # Add danger level for context switching
                            if self.haack_bridge:
                                danger_tv = self.haack_bridge.get_truthvalue('danger')
                                if danger_tv:
                                    mock_state.truth_values['danger'] = danger_tv
                            
                            self.meta_context.update_contexts(mock_state)
                            
                            # Check for context-specific rhythm adaptation
                            current_context = self.meta_context.get_active_context()
                            if self.rhythm_learner and current_context:
                                # Adapt rhythms to current context
                                if current_context.name in ['exploration', 'survival', 'learning']:
                                    self.rhythm_learner.set_active_profile(current_context.name)
                        
                        # Encode memory with rhythm signature
                        if self.memory_v2 and track_states:
                            memory_id = f"cycle_{cycle_count}"
                            content = {
                                'cycle': cycle_count,
                                'scene_type': scene_type.value if hasattr(scene_type, 'value') else str(scene_type),
                                'location': game_state.location_name if game_state else 'unknown',
                                'health': game_state.health if game_state else 100,
                                'in_combat': game_state.in_combat if game_state else False
                            }
                            
                            context_name = self.meta_context.get_active_context().name if self.meta_context else 'exploration'
                            
                            self.memory_v2.encode_episodic(
                                memory_id=memory_id,
                                content=content,
                                track_states=track_states,
                                context=context_name
                            )
                        
                        # Evaluate coherence V2
                        if self.coherence_v2:
                            # Build mock cognitive state for coherence evaluation
                            mock_cog_state = type('obj', (object,), {
                                'truth_values': {},
                                'tracks': [],
                                'goals': [],
                                'emotions': {}
                            })()
                            
                            # Add truth values from HaackLang
                            if self.haack_bridge:
                                for tv_name in ['danger', 'fear', 'trust', 'stress']:
                                    tv = self.haack_bridge.get_truthvalue(tv_name)
                                    if tv:
                                        mock_cog_state.truth_values[tv_name] = tv
                            
                            # Evaluate
                            report = self.coherence_v2.evaluate_coherence(mock_cog_state)
                            
                            # Apply corrections if needed
                            if report.needs_adjustment(self.coherence_v2.thresholds):
                                adjustments = self.coherence_v2.apply_corrections(report)
                                
                                # Log interventions
                                if cycle_count % 10 == 0 and adjustments.adjustments:
                                    print(f"[INFINITY] Coherence V2 intervention: {len(adjustments.adjustments)} adjustments")
                                    for adj in adjustments.adjustments[:2]:
                                        print(f"[INFINITY]   {adj.intervention_type.value}: {adj.target}")
                        
                        # Adapt rhythms based on reward
                        if self.rhythm_learner and hasattr(self, 'current_consciousness'):
                            # Use consciousness coherence as reward signal
                            reward = self.current_consciousness.coherence if self.current_consciousness else 0.5
                            
                            # Adapt perception track
                            self.rhythm_learner.adapt_from_reward('perception', reward)
                            
                            # Compute harmonic coherence
                            harmonic_coh = self.rhythm_learner.compute_harmonic_coherence()
                            
                            # Log every 20 cycles
                            if cycle_count % 20 == 0:
                                periods = self.rhythm_learner.get_all_periods()
                                print(f"[INFINITY] Harmonic coherence: {harmonic_coh:.3f}")
                                print(f"[INFINITY] Periods: {periods}")
                        
                        # Apply memory forgetting
                        if self.memory_v2 and cycle_count % 50 == 0:
                            self.memory_v2.apply_forgetting()
                        
                        # Consolidate memories periodically
                        if self.memory_v2 and cycle_count % 100 == 0:
                            # Try to consolidate exploration memories
                            pattern = self.memory_v2.consolidate_episodic_to_semantic(
                                pattern_type='gameplay_pattern'
                            )
                            if pattern:
                                print(f"[INFINITY] Consolidated pattern: {pattern.pattern_id}")
                        
                        # Record in double helix
                        if self.double_helix:
                            self.double_helix.record_activation("infinity_engine", True, 1.0)
                        
                    except Exception as e:
                        if cycle_count % 20 == 0:
                            print(f"[INFINITY] Error: {e}")
                
                # Update BeingState from all subsystems (every cycle)
                if hasattr(self, 'being_state'):
                    from .being_state_updater import update_being_state_from_all_subsystems
                    try:
                        await update_being_state_from_all_subsystems(self)
                        
                        # Compute global coherence
                        if hasattr(self, 'coherence_engine'):
                            C_global = self.coherence_engine.compute(self.being_state)
                            self.being_state.global_coherence = C_global
                            
                            # Log every 10 cycles
                            if cycle_count % 10 == 0:
                                print(f"[BEING] Cycle {cycle_count}: C_global = {C_global:.3f}")
                    except Exception as e:
                        if cycle_count % 20 == 0:  # Only log occasionally to avoid spam
                            print(f"[BEING] Update error: {e}")
                
                # Fix 20: Display performance dashboard every 5 cycles
                if cycle_count > 0 and cycle_count % self.dashboard_update_interval == 0:
                    self._display_performance_dashboard()
                
                # PHASE 2.4: Display arbiter stats every 20 cycles
                if cycle_count > 0 and cycle_count % 20 == 0:
                    try:
                        arbiter_stats = self.action_arbiter.get_stats()
                        print(f"\n{'='*60}")
                        print(f"ACTION ARBITER STATS (Cycle {cycle_count})")
                        print(f"{'='*60}")
                        print(f"Total Requests: {arbiter_stats['total_requests']}")
                        print(f"Executed: {arbiter_stats['executed']} ({arbiter_stats['success_rate']:.1%})")
                        print(f"Rejected: {arbiter_stats['rejected']} (Rate: {arbiter_stats['rejection_rate']:.1%})")
                        print(f"Overridden: {arbiter_stats['overridden']} (Rate: {arbiter_stats['override_rate']:.1%})")
                        print(f"\nBy Source:")
                        for source, count in sorted(arbiter_stats['by_source'].items(), key=lambda x: x[1], reverse=True)[:3]:
                            print(f"  {source}: {count}")
                        print(f"{'='*60}\n")
                    except Exception as e:
                        print(f"[ARBITER] Stats error: {e}")
                
                game_state = perception['game_state']
                scene_type = perception['scene_type']
                
                # Fix 16: Periodic menu exploration for structural consciousness
                if cycle_count % 10 == 0 and not game_state.in_combat:
                    if scene_type not in [SceneType.INVENTORY, SceneType.MAP, SceneType.DIALOGUE]:
                        print(f"[MENU-EXPLORATION] Cycle {cycle_count}: Opening inventory for structural consciousness")
                        # Queue inventory action
                        if not self.action_queue.full():
                            await self.action_queue.put({
                                'action': 'inventory',
                                'reason': 'Periodic menu exploration for structural consciousness',
                                'source': 'curiosity'
                            })

                if game_state:
                    state_dict = game_state.to_dict()
                    scene_name = scene_type.value if hasattr(scene_type, 'value') else str(scene_type)
                    self.goal_planner.update_state(state_dict, scene_name)
                
                # Store perceptual memory
                self.memory_rag.store_perceptual_memory(
                    visual_embedding=perception['visual_embedding'],
                    scene_type=scene_type.value,
                    location=game_state.location_name,
                    context={
                        'health': game_state.health,
                        'in_combat': game_state.in_combat,
                        'layer': game_state.current_action_layer
                    }
                )
                
                # ═══════════════════════════════════════════════════════════
                # VIDEO INTERPRETER - Real-time video analysis
                # ═══════════════════════════════════════════════════════════
                if self.video_interpreter and self.config.enable_video_interpreter and cycle_count % 10 == 0:  # Every 10 cycles
                    try:
                        screenshot = perception.get('screenshot')
                        if screenshot is not None:
                            interpretation = await self.interpret_video_frame(
                                frame=screenshot,
                                cycle=cycle_count
                            )
                            
                            if interpretation:
                                self.main_brain.record_output(
                                    system_name='Video Interpreter',
                                    content=f"Real-time Analysis:\n{interpretation[:400]}",
                                    metadata={'cycle': cycle_count, 'mode': 'COMPREHENSIVE'},
                                    success=True
                                )
                    except Exception as e:
                        print(f"[VIDEO] Interpretation error: {e}")
                
                # STATE COORDINATOR: Update from perception subsystem
                self.state_coordinator.update(
                    subsystem='perception',
                    state={
                        'scene': scene_type.value,
                        'location': game_state.location_name,
                        'in_combat': game_state.in_combat,
                        'in_menu': scene_type in [SceneType.INVENTORY, SceneType.MAP],
                        'in_dialogue': scene_type == SceneType.DIALOGUE,
                        'health': game_state.health,
                    },
                    confidence=0.95  # Perception is highly reliable
                )
                
                # Fix 6: Integrate menu learner into async mode
                if scene_type in [SceneType.INVENTORY, SceneType.MAP]:
                    if not self.menu_learner.current_menu:
                        available_menu_actions = self.action_affordances.get_available_actions(
                            layer='Menu',
                            game_state=game_state.to_dict()
                        )
                        self.menu_learner.enter_menu(scene_type.value, available_menu_actions)
                        print(f"[MENU-LEARNER] Entered {scene_type.value} menu")
                
                # Fix 7: Hook dialogue intelligence into planning
                if scene_type == SceneType.DIALOGUE and hasattr(self, 'dialogue_intelligence'):
                    # Extract dialogue options from perception if available
                    dialogue_data = perception.get('dialogue', {})
                    npc_name = dialogue_data.get('npc_name', 'Unknown')
                    options = dialogue_data.get('options', [])
                    if options:
                        dialogue_choice = await self.dialogue_intelligence.analyze_dialogue_options(
                            npc_name=npc_name,
                            options=options,
                            context=f"Scene: {scene_type.value}, HP: {game_state.health}"
                        )
                        if dialogue_choice:
                            print(f"[DIALOGUE-INTELLIGENCE] Recommended: {dialogue_choice}")
                
                # ═══════════════════════════════════════════════════════════
                # TEMPORAL BINDING - Track perception→action→outcome loops
                # ═══════════════════════════════════════════════════════════
                binding_id = None
                if self.temporal_tracker and self.config.enable_temporal_binding:
                    try:
                        # Calculate visual similarity
                        similarity = perception.get('visual_similarity', 0.0)
                        
                        # Check for stuck loops BEFORE creating binding
                        if self.temporal_tracker.is_stuck():
                            print(f"[TEMPORAL] ⚠️ STUCK LOOP DETECTED! Stuck count: {self.temporal_tracker.stuck_loop_count}, similarity={similarity:.3f}")
                            
                            # Record to Main Brain
                            self.main_brain.record_output(
                                system_name='Temporal Binding',
                                content=f"🚨 Stuck Loop Detected\nSimilarity: {similarity:.3f}\nStuck Count: {self.temporal_tracker.stuck_loop_count}\nForcing exploration...",
                                metadata={'cycle': cycle_count, 'stuck_count': self.temporal_tracker.stuck_loop_count, 'similarity': similarity},
                                success=True
                            )
                    except Exception as e:
                        print(f"[TEMPORAL] Stuck detection error: {e}")
                
                # Compute world state and consciousness (consciousness runs in parallel, no semaphore)
                world_state = await self.agi.perceive({
                    'causal': game_state.to_dict(),
                    'visual': [perception['visual_embedding']],
                })
                
                consciousness_context = {
                    'motivation': 'unknown',
                    'cycle': cycle_count,
                    'scene': scene_type.value,
                    'screenshot': perception.get('screenshot'),
                    'vision_summary': perception.get('gemini_analysis')
                }
                try:
                    if (cycle_count % 10 == 0) or (scene_type == SceneType.EXPLORATION):
                        phil = await get_random_philosophical_context(hybrid_llm=getattr(self, 'hybrid_llm', None))
                        if isinstance(phil, dict):
                            consciousness_context.update(phil)
                except Exception as _ph_err:
                    pass
                current_consciousness = await self.consciousness_bridge.compute_consciousness(
                    game_state.to_dict(),
                    consciousness_context
                )
                
                # CRITICAL FIX: Prevent zero coherence catastrophe
                # Zero coherence breaks motor control, curriculum RL, and all learning
                if current_consciousness.coherence < 0.01:
                    print(f"[REASONING] ⚠️ ZERO COHERENCE DETECTED - Applying safety floor")
                    from singularis.consciousness.consciousness_state import ConsciousnessState
                    current_consciousness = ConsciousnessState(
                        coherence=0.3,  # Minimal viable coherence
                        coherence_ontical=0.25,
                        coherence_structural=0.25,
                        coherence_participatory=0.25,
                        game_quality=0.3,
                        consciousness_level=0.1,
                        self_awareness=0.2
                    )
                    print(f"[REASONING] → Coherence restored to {current_consciousness.coherence:.3f}")
                
                print(f"[REASONING] Coherence C = {current_consciousness.coherence:.3f}")
                
                # Store current consciousness for BeingState update
                self.current_consciousness = current_consciousness
                
                # Track coherence alignment: BeingState C_global vs subsystem measurements (every 5 cycles)
                if self.gpt5_orchestrator and cycle_count % 5 == 0:
                    try:
                        # Get the UNIFIED coherence from BeingState (computed by CoherenceEngine)
                        unified_coherence = self.being_state.global_coherence if hasattr(self, 'being_state') else current_consciousness.coherence
                        
                        # Get average coherence from individual consciousness nodes
                        consciousness_nodes = self.consciousness_monitor.get_statistics()
                        subsystem_coherence = consciousness_nodes.get('avg_coherence', current_consciousness.coherence)
                        
                        # Record differential
                        self.gpt5_orchestrator.record_coherence_differential(
                            gpt5_coherence=unified_coherence,  # Actually the unified C_global
                            other_nodes_coherence=subsystem_coherence,
                            cycle=cycle_count
                        )
                        
                        differential = abs(unified_coherence - subsystem_coherence)
                        if differential > 0.15:  # Significant difference (lowered threshold)
                            print(f"[COHERENCE-ALIGN] ⚠️ Differential: {differential:.3f} (Unified C_global: {unified_coherence:.3f}, Subsystems: {subsystem_coherence:.3f})")
                            
                            # Diagnose and respond to coherence misalignment
                            if unified_coherence < subsystem_coherence - 0.1:
                                print(f"[COHERENCE-ALIGN] → Unified coherence LOW - subsystems fragmented")
                                print(f"[COHERENCE-ALIGN] → RESPONSE: Triggering integrative action (look_around to gather context)")
                                # Queue a look_around action to help integration
                                if not self.action_queue.full():
                                    await self.action_queue.put({
                                        'action': 'look_around',
                                        'reason': 'Coherence alignment: gathering context for integration',
                                        'source': 'coherence_monitor',
                                        'priority': 80
                                    })
                            elif subsystem_coherence < unified_coherence - 0.1:
                                print(f"[COHERENCE-ALIGN] → Subsystem coherence LOW - integration working but nodes struggling")
                                print(f"[COHERENCE-ALIGN] → RESPONSE: Subsystems need support, continuing current strategy")
                            
                            # Record significant differential to Main Brain
                            self.main_brain.record_output(
                                system_name='Coherence Alignment Monitor',
                                content=f"⚠️ Coherence Alignment Issue\n"
                                       f"Unified C_global (BeingState): {unified_coherence:.3f}\n"
                                       f"Subsystem Average: {subsystem_coherence:.3f}\n"
                                       f"Differential: {differential:.3f}\n"
                                       f"Analysis: {'Fragmentation - subsystems not integrating' if unified_coherence < subsystem_coherence else 'Subsystems struggling despite good integration'}",
                                metadata={
                                    'cycle': cycle_count,
                                    'unified_coherence': unified_coherence,
                                    'subsystem_coherence': subsystem_coherence,
                                    'differential': differential,
                                    'issue_type': 'fragmentation' if unified_coherence < subsystem_coherence else 'subsystem_struggle'
                                },
                                success=True
                            )
                    except Exception as e:
                        print(f"[COHERENCE-ALIGN] Tracking error: {e}")
                
                # ═══════════════════════════════════════════════════════════
                # WOLFRAM ALPHA TELEMETRY - Advanced calculations (every 20 cycles)
                # ═══════════════════════════════════════════════════════════
                if self.wolfram_analyzer and cycle_count % 20 == 0:
                    try:
                        print("\n[WOLFRAM] 🔬 Performing telemetry analysis...")
                        
                        # Get coherence samples from GPT-5 orchestrator
                        if self.gpt5_orchestrator:
                            coherence_stats = self.gpt5_orchestrator.get_coherence_stats()
                            
                            if coherence_stats['samples'] > 5:
                                # Analyze differential coherence
                                gpt5_samples = [s['gpt5_coherence'] for s in self.gpt5_orchestrator.coherence_samples]
                                other_samples = [s['other_coherence'] for s in self.gpt5_orchestrator.coherence_samples]
                                
                                wolfram_result = await self.wolfram_analyzer.analyze_differential_coherence(
                                    gpt5_samples=gpt5_samples,
                                    other_samples=other_samples
                                )
                                
                                if wolfram_result.confidence > 0.5:
                                    print(f"[WOLFRAM] [OK] Differential analysis complete")
                                    print(f"[WOLFRAM] Result: {wolfram_result.result[:200]}...")
                                    
                                    # Record to Main Brain
                                    self.main_brain.record_output(
                                        system_name='Wolfram Telemetry',
                                        content=f"Differential Coherence Analysis:\n{wolfram_result.result[:500]}",
                                        metadata={
                                            'cycle': cycle_count,
                                            'computation_time': wolfram_result.computation_time,
                                            'confidence': wolfram_result.confidence
                                        },
                                        success=True
                                    )
                    except Exception as e:
                        print(f"[WOLFRAM] Analysis error: {e}")
                
                # Store consciousness
                self.last_consciousness = self.current_consciousness
                self.current_consciousness = current_consciousness
                
                # Assess motivation
                motivation_context = {
                    'uncertainty': 0.7 if scene_type == SceneType.UNKNOWN else 0.3,
                    'predicted_delta_coherence': 0.05,
                }
                mot_state = self.agi.motivation.compute_motivation(
                    state=game_state.to_dict(),
                    context=motivation_context
                )
                
                # Form/update goals
                if len(self.agi.goal_system.get_active_goals()) == 0 or cycle_count % 10 == 0:
                    goal = self.agi.goal_system.generate_goal(
                        mot_state.dominant_drive().value,
                        {'scene': scene_type.value, 'location': game_state.location_name}
                    )
                    self.current_goal = goal.description
                    print(f"[REASONING] New goal: {self.current_goal}")
                
                # ═══════════════════════════════════════════════════════════
                # LUMEN BALANCE - Philosophical grounding check
                # ═══════════════════════════════════════════════════════════
                if self.lumen_integration and self.config.enable_lumen_balance and cycle_count % 15 == 0:  # Every 15 cycles
                    try:
                        # Measure balance across active systems
                        system_activations = {
                            'sensorimotor': 1.0 if perception else 0.0,
                            'action_planning': 1.0 if action else 0.0,
                            'consciousness': 1.0 if current_consciousness else 0.0,
                            'emotion': 1.0 if self.emotion_integration else 0.0,
                            'spiritual': 1.0 if self.spiritual else 0.0,
                        }
                        
                        balance = self.lumen_integration.measure_balance(system_activations)
                        balance_score = balance.get('balance_score', 0.0)
                        
                        if balance_score < 0.7:
                            print(f"[LUMEN] ⚠️ Philosophical imbalance detected: {balance_score:.2%}")
                        
                        # Record to Main Brain
                        self.main_brain.record_output(
                            system_name='Lumen Integration',
                            content=f"Balance Score: {balance_score:.2%}\nOnticum: {balance.get('onticum', 0):.2f}\nStructurale: {balance.get('structurale', 0):.2f}\nParticipatum: {balance.get('participatum', 0):.2f}",
                            metadata={'cycle': cycle_count, 'balance': balance_score},
                            success=True
                        )
                    except Exception as e:
                        print(f"[LUMEN] Balance check error: {e}")
                
                # 💭 BROWNIAN MOTION RANDOM ACADEMIC THOUGHT (4% occurrence)
                # Simulates spontaneous memory recall from academic knowledge
                # Like a random thought popping into consciousness
                import random
                if self.curriculum_rag and random.random() < 0.04:  # 4% chance
                    print("\n" + "~" * 70)
                    print("💭 RANDOM ACADEMIC THOUGHT (Brownian Motion Memory Retrieval)")
                    print("~" * 70)
                    
                    random_thought = self.curriculum_rag.get_random_academic_thought()
                    if random_thought:
                        print(f"[THOUGHT] Category: {random_thought.document.category}")
                        print(f"[THOUGHT] Topic: {random_thought.document.title}")
                        print(f"[THOUGHT] Memory Vividness: {random_thought.relevance_score:.2f}")
                        print(f"[THOUGHT] Content: {random_thought.excerpt}")
                        
                        # Store as cognitive memory with correct parameters
                        self.memory_rag.store_cognitive_memory(
                            situation={
                                'type': 'random_academic_thought',
                                'category': random_thought.document.category,
                                'title': random_thought.document.title,
                                'vividness': random_thought.relevance_score,
                                'cycle': cycle_count,
                                'location': game_state.location_name,
                                'excerpt': random_thought.excerpt
                            },
                            action_taken='academic_reflection',
                            outcome={'thought_integrated': True},
                            success=True,
                            reasoning=f"Brownian memory retrieval from {random_thought.document.category}"
                        )
                        
                        # Increment counter
                        self.stats['random_academic_thoughts'] += 1
                        
                        print("[THOUGHT] [OK] Stored in cognitive memory")
                    else:
                        print("[THOUGHT] No academic knowledge available")
                    
                    print("~" * 70 + "\n")
                
                # Sensorimotor & Geospatial Reasoning every 5 cycles (Claude Haiku - Fast)
                if cycle_count % 5 == 0 and self.sensorimotor_llm:
                    print("\n" + "="*70)
                    print("SENSORIMOTOR & GEOSPATIAL REASONING (Claude Haiku)")
                    print("="*70)
                    
                    # First, get visual analysis from Gemini/Local vision models
                    visual_analysis = ""
                    gemini_visual = ""
                    local_visual = ""
                    
                    # ═══════════════════════════════════════════════════════════
                    # PARALLEL MULTI-MODAL VISUAL ANALYSIS
                    # ═══════════════════════════════════════════════════════════
                    print("[SENSORIMOTOR] [READY] Starting parallel multi-modal visual analysis...")
                    
                    screenshot = perception.get('screenshot')
                    visual_tasks = []
                    
                    # Task 1: Gemini visual analysis
                    async def get_gemini_visual():
                        if hasattr(self, 'hybrid_llm') and self.hybrid_llm and screenshot is not None:
                            try:
                                result = await asyncio.wait_for(
                                    self.hybrid_llm.analyze_image(
                                        image=screenshot,
                                        prompt="""Describe the visual scene focusing on: spatial layout, obstacles, pathways, terrain features, landmarks, and any navigational cues. Be specific about what's visible in each direction.

IMPORTANT - Camera Orientation Check:
- If the view is mostly SKY/CEILING (looking up): State 'CAMERA_LOOKING_UP - recommend look_down action'
- If the view is mostly GROUND/FLOOR (looking down): State 'CAMERA_LOOKING_DOWN - recommend look_up action'
- If camera is at normal eye-level: State 'CAMERA_NORMAL - good orientation'

Also check for combat:
- Player's OWN weapon in view does NOT mean combat
- Combat requires ENEMY characters visible, attacking, with red health bars""",
                                        max_tokens=512
                                    ),
                                    timeout=15.0
                                )
                                print(f"[GEMINI-VISUAL] [OK] Complete: {len(result)} chars")
                                return result
                            except Exception as e:
                                print(f"[GEMINI-VISUAL] [X] Failed: {e}")
                                return None
                        return None
                    
                    # Task 2: Local vision analysis
                    async def get_local_visual():
                        if hasattr(self, 'perception_llm') and self.perception_llm:
                            try:
                                result = await asyncio.wait_for(
                                    self.perception_llm.generate(
                                        prompt="Analyze this Skyrim scene for navigation: describe obstacles, open paths, terrain type, and spatial features.",
                                        max_tokens=256
                                    ),
                                    timeout=10.0
                                )
                                if isinstance(result, dict):
                                    result = result.get('content', '')
                                print(f"[LOCAL-VISUAL] [OK] Complete: {len(result)} chars")
                                return result
                            except Exception as e:
                                print(f"[LOCAL-VISUAL] [X] Failed: {e}")
                                return None
                        return None
                    
                    # Task 3: Video interpreter (if available)
                    async def get_video_interpretation():
                        if self.video_interpreter and screenshot is not None:
                            try:
                                result = self.video_interpreter.get_latest_interpretation()
                                if result:
                                    print(f"[VIDEO-INTERP] [OK] Latest: {len(result)} chars")
                                return result
                            except Exception as e:
                                print(f"[VIDEO-INTERP] [X] Failed: {e}")
                                return None
                        return None
                    
                    # Run all visual analyses in parallel
                    gemini_visual, local_visual, video_interp = await asyncio.gather(
                        get_gemini_visual(),
                        get_local_visual(),
                        get_video_interpretation(),
                        return_exceptions=True
                    )
                    
                    # Handle exceptions from gather
                    if isinstance(gemini_visual, Exception):
                        print(f"[GEMINI-VISUAL] Exception: {gemini_visual}")
                        gemini_visual = None
                    if isinstance(local_visual, Exception):
                        print(f"[LOCAL-VISUAL] Exception: {local_visual}")
                        local_visual = None
                    if isinstance(video_interp, Exception):
                        print(f"[VIDEO-INTERP] Exception: {video_interp}")
                        video_interp = None
                    
                    print(f"[SENSORIMOTOR] [OK] Parallel analysis complete (Gemini: {bool(gemini_visual)}, Local: {bool(local_visual)}, Video: {bool(video_interp)})")
                    
                    # Combine visual analyses
                    if gemini_visual or local_visual:
                        visual_analysis = f"""
**VISUAL ANALYSIS FROM VISION MODELS:**

Gemini Vision Analysis:
{gemini_visual if gemini_visual else '[Not available]'}

Local Vision Model Analysis:
{local_visual if local_visual else '[Not available]'}
"""
                    
                    # Check for camera orientation issues and auto-correct
                    if gemini_visual:
                        if 'CAMERA_LOOKING_UP' in gemini_visual:
                            print("[CAMERA-REORIENT] Detected looking at sky/ceiling - correcting...")
                            await self.actions.look_down()
                            print("[CAMERA-REORIENT] [OK] Camera reoriented downward")
                        elif 'CAMERA_LOOKING_DOWN' in gemini_visual:
                            print("[CAMERA-REORIENT] Detected looking at ground/floor - correcting...")
                            await self.actions.look_up()
                            print("[CAMERA-REORIENT] [OK] Camera reoriented upward")
                    
                    # Compute visual similarity if we have embeddings
                    visual_similarity_info = ""
                    similarity = None
                    if perception.get('visual_embedding') is not None and self.last_visual_embedding is not None:
                        import numpy as np
                        similarity = np.dot(perception.get('visual_embedding'), self.last_visual_embedding) / (
                            np.linalg.norm(perception.get('visual_embedding')) * np.linalg.norm(self.last_visual_embedding)
                        )
                        visual_similarity_info = f"\n- Visual similarity to last frame: {similarity:.3f} ({'STUCK' if similarity > 0.95 else 'MOVING'})"
                    
                    # Build comprehensive sensorimotor query with visual learning
                    sensorimotor_query = f"""Analyze the current sensorimotor and geospatial situation in Skyrim:

**Current State:**
- Location: {game_state.location_name}
- Position/Orientation: Unknown (no GPS in Skyrim)
- Terrain: {perception.get('terrain_type', 'unknown')}
- Scene: {scene_type.value}

**Visual Context:**
- CLIP embedding available: {perception.get('visual_embedding') is not None}{visual_similarity_info}
{visual_analysis}

**Movement & Action:**
- Current action layer: {game_state.current_action_layer}
- Recent actions: {', '.join(self.action_history[-5:]) if self.action_history else 'none'}
- Repeated action: {self.last_successful_action} ({self.repeated_action_count}x)

**Spatial Reasoning Tasks:**
1. **Obstacle Detection:** Based on visual analysis, are we stuck against a wall/obstacle?
2. **Navigation Strategy:** What's the best movement pattern given the visual scene?
3. **Spatial Memory:** Have we been here before? (use visual descriptions)
4. **Path Planning:** What direction should we explore based on visible pathways?
5. **Terrain Adaptation:** How should we move given the terrain and obstacles?

**Output Format:**
- Obstacle Status: [clear/blocked/uncertain]
- Navigation Recommendation: [action + reasoning based on visual analysis]
- Spatial Memory: [new/familiar/uncertain]
- Exploration Direction: [direction + reasoning from visual cues]
- Confidence: [0.0-1.0]
"""
                    
                    analysis = ""
                    thinking = ""
                    try:
                        print("[SENSORIMOTOR] Invoking Claude Haiku (fast reasoning)...")
                        sensorimotor_result = await asyncio.wait_for(
                            self.sensorimotor_llm.generate(
                                prompt=sensorimotor_query,
                                system_prompt="You are a sensorimotor and geospatial reasoning expert for a Skyrim AI agent. You receive visual analysis from Gemini and local vision models. Analyze spatial relationships, movement patterns, and navigation strategies concisely.",
                                max_tokens=1024,  # Reduced for speed
                                temperature=0.3
                                # No extended thinking - Haiku is fast enough without it
                            ),
                            timeout=30.0  # Much faster timeout for Haiku
                        )
                        
                        analysis = sensorimotor_result.get('content', '')
                        
                        print(f"\n[SENSORIMOTOR] Analysis ({len(analysis)} chars):")
                        print(f"[SENSORIMOTOR] {analysis[:500]}...")
                        
                        # STATE COORDINATOR: Update from sensorimotor subsystem
                        # Extract key facts from analysis
                        sensorimotor_state = {
                            'scene': scene_type.value,
                            'location': game_state.location_name,
                            'stuck': 'stuck' in analysis.lower() or 'blocked' in analysis.lower(),
                            'in_combat': 'combat' in analysis.lower() or 'enemy' in analysis.lower(),
                        }
                        # Parse visual context
                        if visual_analysis:
                            if 'outdoor' in visual_analysis.lower() or 'exterior' in visual_analysis.lower():
                                sensorimotor_state['environment'] = 'outdoor'
                            elif 'indoor' in visual_analysis.lower() or 'interior' in visual_analysis.lower():
                                sensorimotor_state['environment'] = 'indoor'
                            if 'inventory' in visual_analysis.lower() or 'menu' in visual_analysis.lower():
                                sensorimotor_state['in_menu'] = True
                        
                        self.state_coordinator.update(
                            subsystem='sensorimotor',
                            state=sensorimotor_state,
                            confidence=0.85  # High confidence from visual analysis
                        )
                        
                        # Store in dedicated RAG memory with visual learning
                        self.memory_rag.store_cognitive_memory(
                            situation={
                                'type': 'sensorimotor_geospatial',
                                'location': game_state.location_name,
                                'terrain': perception.get('terrain_type', 'unknown'),
                                'scene': scene_type.value,
                                'cycle': cycle_count,
                                'repeated_action': self.last_successful_action,
                                'repeat_count': self.repeated_action_count,
                                'has_gemini_visual': bool(gemini_visual),
                                'has_claude_analysis': bool(analysis)
                            },
                            action_taken='sensorimotor_analysis',
                            outcome={'analysis_length': len(analysis)},
                            success=True,
                            reasoning=f"""SENSORIMOTOR & GEOSPATIAL ANALYSIS:

VISUAL LEARNING (from Gemini & Local Models):
{visual_analysis}

CLAUDE HAIKU ANALYSIS:
{analysis}
"""
                        )
                        
                        print("[SENSORIMOTOR] [OK] Stored in RAG memory (with visual learning from Gemini & Local)")
                        
                        # Hebbian: Record successful sensorimotor reasoning
                        contribution = 1.0 if (gemini_visual and local_visual) else 0.7
                        self.hebbian.record_activation(
                            system_name='sensorimotor_haiku',
                            success=True,
                            contribution_strength=contribution,
                            context={'has_visual': bool(visual_analysis)}
                        )
                        
                        # Main Brain: Record sensorimotor output
                        self.main_brain.record_output(
                            system_name='Sensorimotor Haiku',
                            content=f"Visual Analysis:\n{visual_analysis[:200]}...\n\nSpatial Reasoning:\n{analysis[:300]}...",
                            metadata={
                                'has_gemini': bool(gemini_visual),
                                'has_local': bool(local_visual),
                                'cycle': cycle_count
                            },
                            success=True
                        )
                        
                        # ═══════════════════════════════════════════════════════════
                        # GPT-5 ORCHESTRATOR - Meta-cognitive coordination
                        # ═══════════════════════════════════════════════════════════
                        if self.gpt5_orchestrator and cycle_count % 5 == 0:  # Every 5 cycles
                            try:
                                gpt5_guidance = await self.send_gpt5_message(
                                    system_id="sensorimotor",
                                    message_type="perception_analysis",
                                    content=f"Visual: {visual_analysis[:300]}\nSpatial: {analysis[:300]}",
                                    metadata={'cycle': cycle_count, 'scene': scene_type.value}
                                )
                                
                                if gpt5_guidance:
                                    # GPT5Response is a dataclass, use attribute access not .get()
                                    guidance_text = gpt5_guidance.guidance or gpt5_guidance.response_text or "N/A"
                                    self.main_brain.record_output(
                                        system_name='GPT-5 Orchestrator',
                                        content=f"Sensorimotor Guidance:\n{guidance_text[:400]}",
                                        metadata={'cycle': cycle_count, 'subsystem': 'sensorimotor'},
                                        success=True
                                    )
                            except Exception as e:
                                print(f"[GPT-5] Sensorimotor guidance error: {e}")
                        
                        # ═══════════════════════════════════════════════════════════
                        # VOICE - Describe landscape/environment (every 10 cycles)
                        # ═══════════════════════════════════════════════════════════
                        if self.voice_system and self.config.enable_voice and cycle_count % 10 == 0:
                            try:
                                # Extract landscape description from Gemini visual analysis
                                if gemini_visual and len(gemini_visual) > 50:
                                    print(f"[VOICE-LANDSCAPE] Gemini visual available: {len(gemini_visual)} chars")
                                    # Get first 2 sentences of visual description
                                    sentences = gemini_visual.split('.')[:2]
                                    landscape_desc = '. '.join(sentences).strip()
                                    if landscape_desc and len(landscape_desc) > 20:
                                        print(f"[VOICE-LANDSCAPE] Speaking: {landscape_desc[:100]}...")
                                        await self.voice_system.speak(
                                            text=f"I observe: {landscape_desc}",
                                            priority=ThoughtPriority.HIGH,
                                            category="observation"
                                        )
                                    else:
                                        print(f"[VOICE-LANDSCAPE] Description too short: {len(landscape_desc)} chars")
                                else:
                                    print(f"[VOICE-LANDSCAPE] No Gemini visual available (cycle {cycle_count})")
                            except Exception as e:
                                print(f"[VOICE] Landscape commentary error: {e}")
                        
                        # Cache visual analyses for temporal binding
                        self._last_gemini_visual = gemini_visual
                        self._last_local_visual = local_visual
                        
                        # If Gemini provided visual, record its contribution
                        if gemini_visual:
                            self.hebbian.record_activation(
                                system_name='gemini_vision',
                                success=True,
                                contribution_strength=0.8,
                                context={'purpose': 'sensorimotor_visual'}
                            )
                        
                        # If Local vision provided analysis, record it
                        if local_visual:
                            self.hebbian.record_activation(
                                system_name='local_vision_qwen',
                                success=True,
                                contribution_strength=0.7,
                                context={'purpose': 'sensorimotor_visual'}
                            )
                    except asyncio.TimeoutError:
                        print("[SENSORIMOTOR] Timed out after 90s")
                        self.hebbian.record_activation(
                            system_name='sensorimotor_claude45',
                            success=False,
                            contribution_strength=0.3
                        )
                    except Exception as e:
                        print(f"[SENSORIMOTOR] Error: {e}")
                        import traceback
                        traceback.print_exc()
                        self.hebbian.record_activation(
                            system_name='sensorimotor_claude45',
                            success=False,
                            contribution_strength=0.2
                        )
                    finally:
                        self._update_sensorimotor_state(
                            cycle=cycle_count,
                            similarity=similarity,
                            analysis=analysis,
                            has_thinking=bool(thinking),
                            visual_context=visual_analysis
                        )
                    
                    print("="*70 + "\n")
                
                # EMOTION PROCESSING (HuiHui) - Every 30 cycles, aligned with sensorimotor
                if cycle_count % 30 == 0 and self.emotion_integration:
                    print("\n" + "="*70)
                    print("EMOTION PROCESSING (HuiHui)")
                    print("="*70)
                    
                    from .emotion_integration import SkyrimEmotionContext
                    
                    # Build emotion context from game state
                    emotion_context = SkyrimEmotionContext(
                        in_combat=game_state.in_combat,
                        health_percent=game_state.health / 100.0,
                        stamina_percent=game_state.stamina / 100.0,
                        magicka_percent=game_state.magicka / 100.0,
                        health_critical=(game_state.health < 30),
                        stamina_low=(game_state.stamina < 50),
                        enemy_nearby=game_state.in_combat,
                        enemy_count=game_state.enemies_nearby,
                        stuck_detected=(similarity > 0.95 if similarity else False),
                        coherence_delta=consciousness_state.coherence_delta if consciousness_state else 0.0,
                        adequacy_score=consciousness_state.adequacy if consciousness_state else 0.5
                    )
                    
                    try:
                        # Process emotion
                        emotion_state = await asyncio.wait_for(
                            self.emotion_integration.process_game_state(
                                game_state=game_state.to_dict(),
                                context=emotion_context
                            ),
                            timeout=10.0
                        )
                        
                        # Log emotion state
                        self.emotion_integration.log_emotion_state(cycle_count)
                        
                        print(f"\n[EMOTION] {emotion_state.primary_emotion.value.upper()}")
                        print(f"[EMOTION] Intensity: {emotion_state.intensity:.2f}")
                        print(f"[EMOTION] Valence: {emotion_state.valence.valence:+.2f}")
                        print(f"[EMOTION] Type: {'ACTIVE' if emotion_state.is_active else 'PASSIVE'}")
                        print(f"[EMOTION] Decision Weights:")
                        print(f"[EMOTION]   Aggression: {self.emotion_integration.get_decision_modifier('aggression'):.2f}")
                        print(f"[EMOTION]   Caution: {self.emotion_integration.get_decision_modifier('caution'):.2f}")
                        
                        # Record in Main Brain
                        self.main_brain.record_output(
                            system_name='Emotion System (HuiHui)',
                            content=f"Emotion: {emotion_state.primary_emotion.value}, "
                                   f"Intensity: {emotion_state.intensity:.2f}, "
                                   f"Valence: {emotion_state.valence.valence:.2f}",
                            metadata={
                                'emotion_type': emotion_state.primary_emotion.value,
                                'is_active': emotion_state.is_active,
                                'intensity': emotion_state.intensity,
                                'cycle': cycle_count
                            },
                            success=True
                        )
                        
                        # Record in Hebbian
                        self.hebbian.record_activation(
                            system_name='emotion_huihui',
                            success=True,
                            contribution_strength=emotion_state.confidence,
                            context={'emotion': emotion_state.primary_emotion.value}
                        )
                        
                    except asyncio.TimeoutError:
                        print("[EMOTION] Timed out after 10s")
                    except Exception as e:
                        print(f"[EMOTION] Error: {e}")
                    
                    print("="*70 + "\n")
                
                # SPIRITUAL CONTEMPLATION - Every 100 cycles for deeper understanding
                if cycle_count % 100 == 0 and self.spiritual:
                    print("\n" + "="*70)
                    print("SPIRITUAL CONTEMPLATION")
                    print("="*70)
                    
                    # Build contemplation context
                    context_query = f"""Contemplating my existence in Skyrim:

Location: {game_state.location_name}
Current action: {self.action_history[-1] if self.action_history else 'none'}
Health: {game_state.health}/100
In combat: {game_state.in_combat}
Coherence: {consciousness_state.coherence_delta if consciousness_state else 0.0:+.3f}

What is the meaning of this moment?
How should I understand my being in this world?
What does my current situation teach me about impermanence and interdependence?"""
                    
                    try:
                        # Contemplate
                        contemplation = await asyncio.wait_for(
                            self.spiritual.contemplate(context_query),
                            timeout=5.0
                        )
                        
                        # Log synthesis
                        synthesis = contemplation['synthesis']
                        print(f"\n[SPIRITUAL] Synthesis:")
                        print(f"[SPIRITUAL] {synthesis[:200]}...")
                        
                        # Get evolved self-concept
                        self_concept = self.spiritual.get_self_concept()
                        print(f"\n[SPIRITUAL] Self-Concept:")
                        print(f"[SPIRITUAL]   Identity: {self_concept.identity_statement[:60]}...")
                        print(f"[SPIRITUAL]   Insights: {len(self_concept.insights)}")
                        print(f"[SPIRITUAL]   Understands Impermanence: {self_concept.understands_impermanence}")
                        print(f"[SPIRITUAL]   Understands Interdependence: {self_concept.understands_interdependence}")
                        
                        # Record in Main Brain
                        self.main_brain.record_output(
                            system_name='Spiritual Awareness',
                            content=f"Self-Concept: {self_concept.identity_statement}\n"
                                   f"Insights: {len(self_concept.insights)}",
                            metadata={
                                'understands_impermanence': self_concept.understands_impermanence,
                                'understands_interdependence': self_concept.understands_interdependence,
                                'cycle': cycle_count
                            },
                            success=True
                        )
                        
                    except asyncio.TimeoutError:
                        print("[SPIRITUAL] Timed out after 5s")
                    except Exception as e:
                        print(f"[SPIRITUAL] Error: {e}")
                    
                    print("="*70 + "\n")
                
                # REALTIME DECISION COORDINATION - Every N cycles for streaming decisions
                if cycle_count % self.config.realtime_decision_frequency == 0 and self.realtime_coordinator:
                    print("\n" + "="*70)
                    print("REALTIME DECISION COORDINATION (GPT-4 Realtime API)")
                    print("="*70)
                    
                    # Build situation description
                    situation = f"""Current situation in Skyrim:
Location: {game_state.location_name}
Health: {game_state.health}/100 {'(CRITICAL!)' if game_state.health < 30 else ''}
Combat: {'YES - {} enemies'.format(game_state.enemies_nearby) if game_state.in_combat else 'NO'}
Action Layer: {game_state.current_action_layer}
Recent Action: {self.action_history[-1] if self.action_history else 'none'}

Decide: Should I make an immediate decision or delegate to subsystems?"""
                    
                    try:
                        # Coordinate decision
                        coordination_result = await asyncio.wait_for(
                            self.realtime_coordinator.coordinate_decision(
                                situation=situation,
                                game_state=game_state.to_dict(),
                                context={
                                    'cycle': cycle_count,
                                    'coherence_delta': consciousness_state.coherence_delta if consciousness_state else 0.0
                                }
                            ),
                            timeout=15.0
                        )
                        
                        # Log decision
                        decision = coordination_result.decision
                        print(f"\n[REALTIME] Decision Type: {decision.decision_type.upper()}")
                        
                        if decision.decision_type == "immediate":
                            print(f"[REALTIME] Immediate Action: {decision.action}")
                            print(f"[REALTIME] Confidence: {decision.confidence:.2f}")
                            print(f"[REALTIME] Reasoning: {decision.reasoning[:100]}...")
                        
                        elif decision.delegations:
                            print(f"[REALTIME] Delegated to: {[s.value for s in decision.delegations]}")
                            print(f"[REALTIME] Subsystem Results:")
                            for subsystem, result in coordination_result.subsystem_results.items():
                                if subsystem not in ['decision_type', 'decision_id']:
                                    print(f"[REALTIME]   {subsystem}: {str(result)[:80]}...")
                        
                        if coordination_result.final_action:
                            print(f"[REALTIME] Final Action: {coordination_result.final_action}")
                            print(f"[REALTIME] Confidence: {coordination_result.confidence:.2f}")
                        
                        print(f"[REALTIME] Processing Time: {coordination_result.processing_time:.3f}s")
                        
                        # Record in Main Brain
                        self.main_brain.record_output(
                            system_name='Realtime Coordinator',
                            content=f"Decision: {decision.decision_type}, "
                                   f"Action: {coordination_result.final_action}, "
                                   f"Delegations: {[s.value for s in decision.delegations]}",
                            metadata={
                                'decision_type': decision.decision_type,
                                'final_action': coordination_result.final_action,
                                'confidence': coordination_result.confidence,
                                'processing_time': coordination_result.processing_time,
                                'cycle': cycle_count
                            },
                            success=True
                        )
                        
                    except asyncio.TimeoutError:
                        print("[REALTIME] Timed out after 15s")
                    except Exception as e:
                        print(f"[REALTIME] Error: {e}")
                    
                    print("="*70 + "\n")
                
                # SELF-REFLECTION - Iterative evolving self-understanding
                if cycle_count % self.config.self_reflection_frequency == 0 and self.self_reflection:
                    print("\n" + "="*70)
                    print("SELF-REFLECTION (GPT-4 Realtime - Iterative Evolution)")
                    print("="*70)
                    
                    # Build reflection trigger
                    trigger = f"Reflecting on cycle {cycle_count} experiences"
                    
                    # Build context
                    reflection_context = {
                        'recent_actions': ', '.join(self.action_history[-5:]) if self.action_history else 'none',
                        'coherence_delta': consciousness_state.coherence_delta if consciousness_state else 0.0,
                        'cycle': cycle_count
                    }
                    
                    # Add emotion if available
                    if hasattr(self, 'current_emotion') and self.current_emotion:
                        reflection_context['emotion_state'] = f"{self.current_emotion.primary_emotion.value} ({self.current_emotion.intensity:.2f})"
                    
                    # Add spiritual insight if available
                    if self.spiritual and self.spiritual.self_concept.recent_insights:
                        reflection_context['spiritual_insight'] = self.spiritual.self_concept.recent_insights[-1]
                    
                    try:
                        # Perform iterative reflection chain
                        reflections = await asyncio.wait_for(
                            self.self_reflection.iterative_reflection_chain(
                                initial_question=trigger,
                                context=reflection_context,
                                iterations=self.config.self_reflection_chain_length
                            ),
                            timeout=20.0
                        )
                        
                        # Log reflections
                        print(f"\n[SELF-REFLECTION] Completed {len(reflections)}-iteration chain")
                        for i, reflection in enumerate(reflections, 1):
                            print(f"[SELF-REFLECTION] Iteration {i}:")
                            print(f"[SELF-REFLECTION]   Insight: {reflection.insight[:150]}...")
                            print(f"[SELF-REFLECTION]   Evolution Δ: {reflection.evolution_delta:.3f}")
                            print(f"[SELF-REFLECTION]   Confidence: {reflection.confidence:.2f}")
                        
                        # Show evolved self-model
                        self_model = self.self_reflection.get_self_model()
                        print(f"\n[SELF-REFLECTION] Self-Model Evolution:")
                        print(f"[SELF-REFLECTION]   Total Reflections: {self_model.total_reflections}")
                        print(f"[SELF-REFLECTION]   Major Insights: {self_model.major_insights}")
                        print(f"[SELF-REFLECTION]   Understanding Depth: {self_model.understanding_depth:.2%}")
                        
                        # Record in Main Brain
                        self.main_brain.record_output(
                            system_name='Self-Reflection',
                            content=f"Reflections: {len(reflections)}, "
                                   f"Evolution: {sum(r.evolution_delta for r in reflections):.3f}",
                            metadata={
                                'iterations': len(reflections),
                                'total_evolution': sum(r.evolution_delta for r in reflections),
                                'understanding_depth': self_model.understanding_depth,
                                'cycle': cycle_count
                            },
                            success=True
                        )
                        
                    except asyncio.TimeoutError:
                        print("[SELF-REFLECTION] Timed out after 20s")
                    except Exception as e:
                        print(f"[SELF-REFLECTION] Error: {e}")
                    
                    print("="*70 + "\n")
                
                # FULL SINGULARIS ORCHESTRATOR - Run periodically for deep strategic reasoning
                # Uses Huihui for dialectical synthesis, expert consultation, meta-cognition
                # This invokes the full MetaOrchestratorLLM with thesis-antithesis-synthesis dialectic
                if cycle_count % 15 == 0 and self.huihui_llm:
                    print("\n" + "="*70)
                    print("FULL SINGULARIS AGI PROCESS - DIALECTICAL REASONING (CYCLE 15)")
                    print("Invoking Huihui + 6 Experts + Dialectical Synthesis")
                    print("="*70)
                    
                    # Build strategic query for the orchestrator
                    strategic_query = f"""Skyrim Strategic Analysis:

Location: {game_state.location_name}
Health: {game_state.health}/100
Combat: {'YES' if game_state.in_combat else 'NO'}
Enemies: {game_state.enemies_nearby}
Current Layer: {game_state.current_action_layer}

Scene: {scene_type.value}
Motivation: {mot_state.dominant_drive().value}
Goal: {self.current_goal}

Recent actions: {', '.join(self.action_history[-5:]) if self.action_history else 'none'}

SYMBOLIC LOGIC ANALYSIS:
{chr(10).join(self.skyrim_world.get_logic_analysis(game_state.to_dict())['recommendations']['logical_reasoning']) if self.skyrim_world.get_logic_analysis(game_state.to_dict())['recommendations']['logical_reasoning'] else 'No critical logic recommendations'}

What is the most strategic approach to this situation? Consider:
1. Immediate tactical needs (including symbolic logic recommendations above)
2. Long-term strategic goals  
3. Risk vs reward tradeoffs
4. Layer transitions (Combat/Exploration/Menu/Stealth)
5. Resource management
6. How the symbolic logic rules inform tactical decisions"""

                    try:
                        # Call full AGI orchestrator with Huihui as consciousness LLM
                        print("[SINGULARIS] Invoking full orchestrator (Huihui + 6 experts)...")
                        singularis_result = await asyncio.wait_for(
                            self.agi.process(
                                query=strategic_query,
                                context={
                                    'game_state': game_state.to_dict(),
                                    'scene': scene_type.value,
                                    'cycle': cycle_count
                                }
                            ),
                            timeout=90.0  # Full orchestrator needs more time
                        )
                        
                        # Extract insights from full Singularis process
                        consciousness_response = singularis_result.get('consciousness_response', {})
                        strategic_insight = consciousness_response.get('response', '')
                        coherence_delta = consciousness_response.get('coherentia_delta', 0.0)
                        
                        print(f"\n[SINGULARIS] Strategic Insight ({len(strategic_insight)} chars):")
                        print(f"[SINGULARIS] {strategic_insight[:300]}...")
                        print(f"[SINGULARIS] Coherence ΔC: {coherence_delta:+.3f}")
                        
                        # Store in memory for future reference
                        self.memory_rag.store_cognitive_memory(
                            situation={
                                'type': 'strategic_analysis',
                                'coherence_delta': coherence_delta,
                                'location': game_state.location_name,
                                'cycle': cycle_count
                            },
                            action_taken='singularis_orchestration',
                            outcome={'insight_length': len(strategic_insight), 'coherence_delta': coherence_delta},
                            success=True,
                            reasoning=strategic_insight
                        )
                        
                        # Update goal if Singularis generated one
                        if 'generated_goal' in singularis_result:
                            self.current_goal = singularis_result['generated_goal']
                            print(f"[SINGULARIS] Updated goal: {self.current_goal}")
                        
                        # PASS TO CLAUDE - Get meta-strategic analysis from Claude Sonnet 4
                        if self.hybrid_llm and hasattr(self.hybrid_llm, 'claude'):
                            try:
                                print("\n[CLAUDE-META] Sending Singularis insights to Claude for meta-analysis...")
                                
                                claude_meta_prompt = f"""You are receiving strategic insights from the Singularis AGI system (Huihui MoE with dialectical reasoning).

SINGULARIS DIALECTICAL ANALYSIS:
{strategic_insight}

COHERENCE DELTA: {coherence_delta:+.3f}

CURRENT SITUATION:
- Location: {game_state.location_name}
- Health: {game_state.health}/100
- Combat: {'YES' if game_state.in_combat else 'NO'}
- Layer: {game_state.current_action_layer}
- Goal: {self.current_goal}

As Claude Sonnet 4, provide meta-strategic analysis:

1. **Validate Singularis Reasoning**: Does the dialectical synthesis make sense? Any blind spots?
2. **Strategic Refinement**: How can we improve or extend this strategy?
3. **Risk Assessment**: What are the key risks not mentioned?
4. **Action Priority**: What should be the immediate next 3 actions?
5. **Long-term Vision**: How does this fit into broader gameplay objectives?

Be concise but insightful. Focus on what Singularis might have missed."""

                                claude_response = await asyncio.wait_for(
                                    self.hybrid_llm.generate_reasoning(
                                        prompt=claude_meta_prompt,
                                        system_prompt="You are Claude Sonnet 4, providing meta-strategic oversight of AGI reasoning.",
                                        max_tokens=1024
                                    ),
                                    timeout=30.0
                                )
                                
                                print(f"\n[CLAUDE-META] Meta-Strategic Analysis ({len(claude_response)} chars):")
                                print(f"[CLAUDE-META] {claude_response[:400]}...")
                                
                                # Store Claude's meta-analysis
                                self.memory_rag.store_cognitive_memory(
                                    situation={
                                        'type': 'claude_meta_strategy',
                                        'based_on_singularis': True,
                                        'location': game_state.location_name,
                                        'cycle': cycle_count
                                    },
                                    action_taken='meta_analysis',
                                    outcome={'response_length': len(claude_response)},
                                    success=True,
                                    reasoning=f"CLAUDE META-ANALYSIS:\n{claude_response}"
                                )
                                
                            except asyncio.TimeoutError:
                                print("[CLAUDE-META] Timed out after 30s")
                            except Exception as e:
                                print(f"[CLAUDE-META] Error: {e}")
                        
                        print("="*70 + "\n")
                        
                        # Hebbian: Record successful Singularis dialectical reasoning
                        self.hebbian.record_activation(
                            system_name='singularis_orchestrator',
                            success=True,
                            contribution_strength=1.0,
                            context={'with_claude_meta': True}
                        )
                        
                        # Huihui contributed successfully
                        self.hebbian.record_activation(
                            system_name='huihui_dialectical',
                            success=True,
                            contribution_strength=0.9,
                            context={'purpose': 'singularis'}
                        )
                        
                        # Main Brain: Record Singularis orchestrator output
                        self.main_brain.record_output(
                            system_name='Singularis Orchestrator',
                            content=f"Dialectical Strategy:\n{singularis_result.get('analysis', '')[:400]}...",
                            metadata={
                                'has_claude_meta': True,
                                'cycle': cycle_count
                            },
                            success=True
                        )
                        
                    except asyncio.TimeoutError:
                        print("[SINGULARIS] Full orchestrator timed out after 90s")
                        self.hebbian.record_activation(
                            system_name='singularis_orchestrator',
                            success=False,
                            contribution_strength=0.3
                        )
                    except Exception as e:
                        print(f"[SINGULARIS] Error in full orchestrator: {e}")
                        import traceback
                        traceback.print_exc()
                        self.hebbian.record_activation(
                            system_name='singularis_orchestrator',
                            success=False,
                            contribution_strength=0.2
                        )
                
                # Hebbian Integration Status - Print every 30 cycles
                if cycle_count % 30 == 0 and cycle_count > 0:
                    self.hebbian.print_status()
                    
                    # Apply synaptic decay
                    self.hebbian.apply_hebbian_decay()
                    
                    # Main Brain: Record Hebbian status
                    stats = self.hebbian.get_statistics()
                    synergies = self.hebbian.get_synergistic_pairs(threshold=1.0)
                    
                    hebbian_summary = f"""Success Rate: {stats['success_rate']:.1%}
Top Synergistic Pairs:
{chr(10).join(f'  {a} ↔ {b}: {s:.2f}' for a, b, s in synergies[:3])}

Strongest System: {stats['strongest_system']} ({stats['strongest_weight']:.2f})"""
                    
                    self.main_brain.record_output(
                        system_name='Hebbian Integration',
                        content=hebbian_summary,
                        metadata=stats,
                        success=True
                    )
                    
                    # Main Brain: Record Symbolic Logic World Model status
                    try:
                        world_model_stats = self.skyrim_world.get_stats()
                        logic_summary = f"""World Model Status:
Causal Edges: {world_model_stats['causal_edges']}
NPC Relationships: {world_model_stats['npc_relationships']}
Locations Discovered: {world_model_stats['locations_discovered']}
Learned Rules: {world_model_stats['learned_rules']}

Symbolic Logic Engine:
Facts in KB: {world_model_stats['logic_facts']}
Inference Rules: {world_model_stats['logic_rules']}
Predicate Types: {len(world_model_stats['logic_predicates_by_type'])}

Top Predicates:
{chr(10).join(f'  {k}: {v}' for k, v in sorted(world_model_stats['logic_predicates_by_type'].items(), key=lambda x: x[1], reverse=True)[:5])}"""
                        
                        self.main_brain.record_output(
                            system_name='Symbolic Logic World Model',
                            content=logic_summary,
                            metadata=world_model_stats,
                            success=True
                        )
                    except Exception as e:
                        print(f"[MAIN BRAIN] Could not record logic stats: {e}")
                
                # Plan action (with LLM throttling and timeout protection)
                # Increased timeout to 15s to accommodate slow LLM systems:
                # - 2 Gemini experts (rate-limited to 5 RPM each = 12s minimum wait)
                # - 3 Claude experts (3s latency each)
                # - Hybrid vision+reasoning pipeline (4-6s)
                # - Local MoE synthesis (5-7s)
                planning_start = time.time()
                
                # RECOMMENDATION 4: Adaptive planning cycles based on visual similarity
                # Check if stuck in high-similarity state
                similarity_stuck = False
                if len(self.visual_embedding_history) >= 2:
                    import numpy as np
                    last = np.array(self.visual_embedding_history[-1]).flatten()
                    prev = np.array(self.visual_embedding_history[-2]).flatten()
                    similarity = np.dot(last, prev) / (np.linalg.norm(last) * np.linalg.norm(prev) + 1e-8)
                    
                    if similarity > 0.95:
                        similarity_stuck = True
                        print(f"[ADAPTIVE-PLANNING] High similarity detected: {similarity:.3f}")
                
                # RECOMMENDATION 4: Reduce planning timeout in stuck states
                if similarity_stuck:
                    planning_timeout = 5.0  # Reduce from 15s to 5s
                    print(f"[ADAPTIVE-PLANNING] ⚡ SHORTENED CYCLE: {planning_timeout}s (similarity > 0.95)")
                    print("[ADAPTIVE-PLANNING] Increasing sensorimotor polling priority")
                    # Boost sensorimotor weight temporarily
                    self.hebbian.record_activation(
                        system_name='sensorimotor_claude45',
                        success=True,
                        contribution_strength=0.5,
                        context={'adaptive_boost': True, 'high_similarity': True}
                    )
                else:
                    planning_timeout = 15.0  # Standard planning time
                
                action = None
                try:
                    async with self.llm_semaphore:
                        action = await asyncio.wait_for(
                            self._plan_action(
                                perception=perception,
                                motivation=mot_state,
                                goal=self.current_goal
                            ),
                            timeout=planning_timeout
                        )
                except asyncio.TimeoutError:
                    print(f"[REASONING] ⚠️ Planning timed out after {planning_timeout}s, using fallback")
                    action = None
                except Exception as e:
                    print(f"[REASONING] ⚠️ Planning error: {e}, using fallback")
                    action = None
                
                planning_duration = time.time() - planning_start
                self.stats['planning_times'].append(planning_duration)
                
                # Handle None action with fallback
                if action is None:
                    print("[REASONING] WARNING: No action returned by _plan_action, using fallback")
                    action = 'explore'  # Safe default fallback
                    self.stats['heuristic_action_count'] += 1
                
                # TEMPORAL BINDING: Check for stuck loop via temporal tracker
                if self.temporal_tracker and self.temporal_tracker.is_stuck():
                    stuck_count = self.temporal_tracker.stuck_loop_count
                    print(f"[TEMPORAL-OVERRIDE] 🚨 STUCK LOOP DETECTED ({stuck_count} cycles)")
                    print(f"[TEMPORAL-OVERRIDE] Forcing emergency corrective action")
                    
                    # Emergency action sequence based on stuck count
                    if stuck_count >= 5:
                        # Severe stuck - try drastic action
                        action = random.choice(['turn_around', 'jump', 'sprint'])
                        print(f"[TEMPORAL-OVERRIDE] Severe stuck (5+ cycles) → {action}")
                    elif stuck_count >= 3:
                        # Moderate stuck - try navigation
                        action = random.choice(['look_around', 'move_backward', 'turn_left', 'turn_right'])
                        print(f"[TEMPORAL-OVERRIDE] Moderate stuck (3+ cycles) → {action}")
                    else:
                        # Initial stuck - try simple correction
                        action = random.choice(['look_down', 'look_up', 'activate'])
                        print(f"[TEMPORAL-OVERRIDE] Initial stuck → {action}")
                
                # Check for repeated action stuck loop with visual similarity
                if action == self.last_successful_action:
                    self.repeated_action_count += 1
                    
                    # Check if visuals have changed significantly (progress made)
                    current_visual = perception.get('visual_embedding')
                    visual_changed = True
                    
                    if current_visual is not None and self.last_visual_embedding is not None:
                        # Compute cosine similarity
                        import numpy as np
                        similarity = np.dot(current_visual, self.last_visual_embedding) / (
                            np.linalg.norm(current_visual) * np.linalg.norm(self.last_visual_embedding)
                        )
                        visual_changed = similarity < self.visual_similarity_threshold
                        
                        if not visual_changed and self.repeated_action_count >= 3:
                            print(f"[STUCK-DETECTION] Repeated '{action}' {self.repeated_action_count}x, visual similarity: {similarity:.3f} (stuck!)")
                    
                    # Only force change if visuals haven't changed AND repeated too many times
                    if self.repeated_action_count >= self.max_repeated_actions and not visual_changed:
                        print(f"[STUCK-DETECTION] ⚠️ Repeated action '{action}' {self.repeated_action_count} times with no visual progress!")
                        print(f"[STUCK-DETECTION] Likely stuck at door/gate/obstacle - trying 'activate'")
                        # Force a different action - prioritize 'activate' for doors/gates
                        game_state = perception.get('game_state')
                        available = game_state.available_actions if game_state else ['move_forward', 'jump', 'activate']
                        
                        # If stuck while exploring, try activate first (for doors/gates)
                        if action in ['explore', 'move_forward'] and 'activate' in available:
                            action = 'activate'
                            print(f"[STUCK-DETECTION] Trying 'activate' to open door/gate")
                        else:
                            # Otherwise choose random different action
                            different_actions = [a for a in available if a != action]
                            if different_actions:
                                action = random.choice(different_actions)
                                print(f"[STUCK-DETECTION] Switched to: {action}")
                        self.repeated_action_count = 0
                    elif visual_changed:
                        # Visual progress made, allow repeated action (e.g., move_forward exploring)
                        if self.repeated_action_count >= 3:
                            print(f"[STUCK-DETECTION] [OK] Repeated '{action}' {self.repeated_action_count}x but making visual progress")
                        self.repeated_action_count = 0  # Reset since progress is being made
                else:
                    self.repeated_action_count = 0
                
                # Update visual tracking
                if perception.get('visual_embedding') is not None:
                    self.last_visual_embedding = perception.get('visual_embedding').copy()
                
                self.last_successful_action = action

                print(f"[REASONING] Planned action: {action} ({planning_duration:.3f}s)")

                policy_proposal = None
                try:
                    policy_vector, policy_affordances = self._prepare_bdh_policy_inputs(perception, action)
                    policy_proposal = self.bdh_policy_head.propose_candidates(
                        situation_vector=policy_vector,
                        affordance_scores=policy_affordances,
                        goals=[self.current_goal] if getattr(self, 'current_goal', None) else [],
                        recent_actions=self.action_history[-10:] if hasattr(self, 'action_history') else [],
                        being_state=self.being_state,
                    )
                    if (
                        policy_proposal.candidates
                        and policy_proposal.candidates[0]['action'] != action
                        and policy_proposal.certainty >= 0.5
                    ):
                        proposed_action = policy_proposal.candidates[0]['action']
                        print(
                            f"[BDH-POLICY] Adjusting action {action} → {proposed_action} "
                            f"(certainty={policy_proposal.certainty:.2f})"
                        )
                        action = proposed_action
                        self.stats['bdh_policy_adjustments'] += 1
                except Exception as exc:
                    print(f"[BDH-POLICY] Error generating candidates: {exc}")
                    policy_proposal = None
                
                # ═══════════════════════════════════════════════════════════
                # VOICE SYSTEM - Vocalize decision
                # ═══════════════════════════════════════════════════════════
                if self.voice_system and self.config.enable_voice:
                    try:
                        # Get reasoning from last_reasoning if available
                        reasoning_text = "Acting on intuition"
                        if hasattr(self, 'last_reasoning') and self.last_reasoning:
                            reasoning_text = self.last_reasoning.get('reasoning', 'Acting on intuition')
                            if isinstance(reasoning_text, str) and len(reasoning_text) > 200:
                                reasoning_text = reasoning_text[:200]
                        
                        await self.speak_decision(
                            action=action,
                            reason=reasoning_text
                        )
                        
                        # Record to Main Brain (every 10 cycles to avoid spam)
                        if cycle_count % 10 == 0:
                            self.main_brain.record_output(
                                system_name='Voice System',
                                content=f"Vocalized: '{action}'\nReasoning: {reasoning_text}",
                                metadata={'cycle': cycle_count, 'confidence': current_consciousness.coherence if current_consciousness else 0.5},
                                success=True
                            )
                    except Exception as e:
                        print(f"[VOICE] Error: {e}")
                
                # LIVE AUDIO: Stream decision announcement
                if self.live_audio and hasattr(self, 'last_reasoning'):
                    try:
                        asyncio.create_task(
                            self.live_audio.stream_decision(
                                action=action,
                                reasoning=self.last_reasoning.get('reasoning', 'No reasoning available'),
                                confidence=self.last_reasoning.get('confidence', 0.5),
                                scene_type=scene_type
                            )
                        )
                    except Exception as e:
                        logger.debug(f"Live audio stream error: {e}")
                
                # Update dashboard with current state and planned action
                self._update_dashboard_state(action=action, action_source=self.last_action_source)
                
                # Main Brain: Increment cycle and record action decision
                self.main_brain.increment_cycle()
                
                # Record first 10 cycles, then every 5th to capture early behavior
                if cycle_count <= 10 or cycle_count % 5 == 0:
                    # Get logic analysis for Main Brain
                    try:
                        logic_analysis_brief = self.skyrim_world.get_logic_analysis(game_state.to_dict())
                        logic_summary = f"""Logic Recommendations:
• Defend: {logic_analysis_brief['recommendations']['should_defend']}
• Heal: {logic_analysis_brief['recommendations']['should_heal']}
• Retreat: {logic_analysis_brief['recommendations']['should_retreat']}
• Confidence: {logic_analysis_brief['logic_confidence']:.2f}
Active Facts: {len(logic_analysis_brief['current_facts'])}
Applicable Rules: {len(logic_analysis_brief['applicable_rules'])}"""
                    except Exception as e:
                        logic_summary = f"Logic analysis unavailable: {e}"
                    
                    self.main_brain.record_output(
                        system_name='Action Planning',
                        content=f"""Cycle {cycle_count}: {action}

{logic_summary}""",
                        metadata={
                            'planning_time': planning_duration,
                            'scene': scene_type.value,
                            'coherence': self.current_consciousness.coherence if self.current_consciousness else 0,
                            'has_logic_analysis': True
                        },
                        success=True
                    )
                    
                    # ═══════════════════════════════════════════════════════════
                    # GPT-5 ORCHESTRATOR - Action planning coordination
                    # ═══════════════════════════════════════════════════════════
                    if self.gpt5_orchestrator and cycle_count % 10 == 0:  # Every 10 cycles
                        try:
                            gpt5_guidance = await self.send_gpt5_message(
                                system_id="action_planning",
                                message_type="action_decision",
                                content=f"Action: {action}\nReasoning: {reasoning[:300] if reasoning else 'N/A'}\nCoherence: {current_consciousness.coherence if current_consciousness else 0:.3f}",
                                metadata={'cycle': cycle_count, 'scene': scene_type.value}
                            )
                            
                            if gpt5_guidance:
                                # GPT5Response is a dataclass, use attribute access not .get()
                                guidance_text = gpt5_guidance.guidance or gpt5_guidance.response_text or "N/A"
                                self.main_brain.record_output(
                                    system_name='GPT-5 Orchestrator',
                                    content=f"Action Planning Guidance:\n{guidance_text[:400]}",
                                    metadata={'cycle': cycle_count, 'subsystem': 'action_planning'},
                                    success=True
                                )
                        except Exception as e:
                            print(f"[GPT-5] Action planning guidance error: {e}")
                
                # ═══════════════════════════════════════════════════════════
                # CREATE & CLOSE TEMPORAL BINDING - Track perception→action loop
                # ═══════════════════════════════════════════════════════════
                if self.temporal_tracker and self.config.enable_temporal_binding:
                    try:
                        # Gather all visual analyses for temporal binding
                        gemini_vis = getattr(self, '_last_gemini_visual', None)
                        hyperbolic_vis = getattr(self, '_last_hyperbolic_visual', None)
                        video_interp = None
                        if self.video_interpreter:
                            video_interp = self.video_interpreter.get_latest_interpretation()
                        
                        # Create binding: perception→action with multi-modal visual data
                        binding_id = self.temporal_tracker.bind_perception_to_action(
                            perception={
                                'visual_similarity': perception.get('visual_similarity', 0.0),
                                'scene': scene_type.value,
                                'location': game_state.location_name
                            },
                            action=action,
                            gemini_visual=gemini_vis,
                            hyperbolic_visual=hyperbolic_vis,
                            video_interpretation=video_interp,
                            bdh_sigma_snapshots=self._build_bdh_sigma_snapshots(policy_proposal)
                        )
                        
                        # Immediately close the loop with outcome
                        coherence_delta = current_consciousness.coherence if current_consciousness else 0.0
                        self.temporal_tracker.close_loop(
                            binding_id=binding_id,
                            outcome=f"action_{action}",
                            coherence_delta=coherence_delta,
                            success=True
                        )
                        
                        # Record to Main Brain every 10 cycles
                        if cycle_count % 10 == 0:
                            stats = self.temporal_tracker.get_statistics()
                            self.main_brain.record_output(
                                system_name='Temporal Binding',
                                content=f"Bindings: {stats['total_bindings']}\nUnclosed: {stats['unclosed_loops']}\nSuccess Rate: {stats['success_rate']:.1%}\nStuck: {stats['is_stuck']}",
                                metadata={'cycle': cycle_count, 'stats': stats},
                                success=True
                            )
                    except Exception as e:
                        print(f"[TEMPORAL] Binding error: {e}")
                
                # ═══════════════════════════════════════════════════════════
                # ADAPTIVE MEMORY - Learn from experience
                # ═══════════════════════════════════════════════════════════
                if self.hierarchical_memory and self.config.enable_adaptive_memory:
                    try:
                        # Record episode
                        episode = {
                            'perception': {
                                'scene': scene_type.value,
                                'visual_similarity': perception.get('visual_similarity', 0.0),
                                'location': game_state.location_name
                            },
                            'action': action,
                            'outcome': {
                                'coherence': current_consciousness.coherence if current_consciousness else 0.0,
                                'success': True
                            },
                            'context': {
                                'cycle': cycle_count,
                                'health': game_state.health,
                                'in_combat': game_state.in_combat
                            }
                        }
                        
                        self.hierarchical_memory.store_episode(
                            scene_type=episode.get('scene_type', 'unknown'),
                            action=episode.get('action', 'unknown'),
                            outcome=episode.get('outcome', 'unknown'),
                            outcome_success=episode.get('success', False),
                            coherence_delta=episode.get('coherence_delta', 0.0),
                            context=episode.get('context', {}),
                            metadata=episode.get('metadata', {})
                        )
                        
                        # Check for new semantic patterns every 10 cycles
                        if cycle_count % 10 == 0:
                            patterns = self.hierarchical_memory.get_semantic_patterns()
                            if patterns:
                                latest_pattern = patterns[-1] if patterns else None
                                if latest_pattern:
                                    self.main_brain.record_output(
                                        system_name='Adaptive Memory',
                                        content=f"Learned Patterns: {len(patterns)}\nLatest: {latest_pattern.pattern_type}\nConfidence: {latest_pattern.confidence:.2%}",
                                        metadata={'cycle': cycle_count, 'pattern_count': len(patterns)},
                                        success=True
                                    )
                    except Exception as e:
                        print(f"[MEMORY] Adaptive memory error: {e}")
                
                # PHASE 2.3: Route action through arbiter instead of queue
                try:
                    # Request action through arbiter with NORMAL priority
                    result = await self.action_arbiter.request_action(
                        action=action,
                        priority=self.ActionPriority.NORMAL,  # Standard planned actions
                        source='reasoning_loop',
                        context={
                            'perception_timestamp': perception_data.get('timestamp', time.time()),
                            'scene_type': scene_type,
                            'game_state': game_state,
                            'motivation': mot_state,
                            'consciousness': current_consciousness,
                            'binding_id': binding_id,
                            'cycle': cycle_count,
                            'bdh_policy_candidates': policy_proposal.candidates if policy_proposal else [],
                            'bdh_policy_certainty': policy_proposal.certainty if policy_proposal else 0.0,
                        },
                        callback=self._handle_action_result
                    )
                    
                    if not result.executed or not result.success:
                        print(f"[REASONING] Action rejected/failed: {result.reason}")
                        self.stats['action_rejected_count'] += 1
                    else:
                        print(f"[REASONING] Action executed: {action} ({result.execution_time:.3f}s)")
                        
                except Exception as e:
                    print(f"[REASONING] Arbiter error: {e}")
                
            except asyncio.TimeoutError:
                # No perception available, wait a bit
                await asyncio.sleep(0.5)
            except Exception as e:
                print(f"[REASONING] Error: {e}")
                import traceback
                traceback.print_exc()
                await asyncio.sleep(1.0)
        
        print("[REASONING] Loop ended")

    async def _action_loop(self, duration_seconds: int, start_time: float):
        """Runs the asynchronous loop for executing planned actions.

        This loop continuously dequeues actions from the `action_queue` (which is
        populated by the `_reasoning_loop`). Before execution, it performs a
        critical context validation to ensure the action is still appropriate.
        It then executes the action, records the outcome, and queues the results
        for the `_learning_loop` to process.

        Args:
            duration_seconds: The total duration for the gameplay session.
            start_time: The timestamp when the session began.
        """
        print("[ACTION] Loop started")
        
        while self.running and (time.time() - start_time) < duration_seconds:
            try:
                # Get next action (wait if none available)
                action_data = await asyncio.wait_for(
                    self.action_queue.get(),
                    timeout=2.0
                )
                
                action = action_data['action']
                scene_type = action_data.get('scene_type', 'unknown')
                game_state = action_data.get('game_state', {})
                perception_timestamp = action_data.get('timestamp', time.time())
                
                # ===== PHASE 1.2: VALIDATE ACTION CONTEXT =====
                original_health = getattr(game_state, 'health', 100) if hasattr(game_state, 'health') else 100
                is_valid, reason = self._validate_action_context(
                    action=action,
                    perception_timestamp=perception_timestamp,
                    original_scene=str(scene_type),
                    original_health=original_health
                )
                
                if not is_valid:
                    print(f"\n[ACTION] ❌ Action rejected: {action}")
                    print(f"[ACTION]    Reason: {reason}")
                    self.stats['action_rejected_count'] = self.stats.get('action_rejected_count', 0) + 1
                    continue  # Skip this action
                # ===== END VALIDATION =====
                
                print(f"\n[ACTION] ✓ Executing: {action}")
                
                # Set flag to prevent auxiliary exploration interference
                self.action_executing = True
                
                # Execute action with timing
                execution_start = time.time()
                try:
                    await self._execute_action(action, scene_type)
                    execution_duration = time.time() - execution_start
                    self.stats['execution_times'].append(execution_duration)
                    self.stats['actions_taken'] += 1
                    self.stats['action_success_count'] += 1
                    print(f"[ACTION] Successfully executed: {action} ({execution_duration:.3f}s)")
                    
                    # Update stuck detection tracking
                    if self.current_consciousness:
                        coherence = self.current_consciousness.coherence
                        visual_embedding = self.current_perception.get('visual_embedding') if self.current_perception else None
                        self._update_stuck_tracking(action, coherence, visual_embedding)
                except Exception as e:
                    execution_duration = time.time() - execution_start
                    self.stats['execution_times'].append(execution_duration)
                    self.stats['action_failure_count'] += 1
                    print(f"[ACTION] Execution failed: {e}")
                    try:
                        await self.actions.look_around()
                        print("[ACTION] Performed fallback look_around")
                    except:
                        print("[ACTION] Even fallback action failed")
                finally:
                    # Clear flag when done (always runs)
                    self.action_executing = False
                
                # Queue for learning
                try:
                    required_keys = ('game_state', 'scene_type', 'motivation', 'consciousness', 'cycle')
                    if all(k in action_data for k in required_keys):
                        self.learning_queue.put_nowait({
                            'action_data': action_data,
                            'execution_time': time.time()
                        })
                    else:
                        print(f"[ACTION] Skipping learning for incomplete action_data: keys={list(action_data.keys())}")
                except asyncio.QueueFull:
                    print(f"[ACTION] Learning queue full")
                
                # Minimal pause to let action complete
                await asyncio.sleep(0.1)
                
            except asyncio.TimeoutError:
                # No action available, continue monitoring
                await asyncio.sleep(0.5)
            except Exception as e:
                print(f"[ACTION] Error: {e}")
                import traceback
                traceback.print_exc()
                await asyncio.sleep(1.0)
        
        print("[ACTION] Loop ended")

    async def _learning_loop(self, duration_seconds: int, start_time: float):
        """Runs the asynchronous loop for processing and learning from action outcomes.

        This loop dequeues completed action data from the `learning_queue`,
        perceives the resulting game state, and then feeds this "before and
        after" experience into various learning subsystems. This includes updating
        the world model, computing rewards for the curriculum-based RL system,
        storing experiences for the main RL learner, and updating action
        diversity statistics.

        Args:
            duration_seconds: The total duration for the gameplay session.
            start_time: The timestamp when the session began.
        """
        print("[LEARNING] Loop started")
        
        while self.running and (time.time() - start_time) < duration_seconds:
            try:
                # Get completed action data
                learning_data = await asyncio.wait_for(
                    self.learning_queue.get(),
                    timeout=5.0
                )
                
                action_data = learning_data['action_data']
                action = action_data['action']
                cycle_count = action_data.get('cycle', self.cycle_count)
                
                print(f"[LEARNING] Processing cycle {cycle_count}")
                
                # Perceive outcome
                after_perception = await self.perception.perceive()
                after_state = after_perception['game_state'].to_dict()
                
                # Use fast heuristic consciousness (skip slow LLM calls in learning loop)
                # The reasoning loop already computed consciousness, we just need a quick estimate
                from .skyrim_cognition import SkyrimCognitiveState
                cognitive_after = SkyrimCognitiveState.from_game_state(after_state)
                
                # Create simple consciousness state without LLM calls
                after_consciousness = ConsciousnessState(
                    coherence=cognitive_after.overall_quality * 0.5 + 0.1,  # Quick estimate
                    coherence_ontical=cognitive_after.survival * 0.4,
                    coherence_structural=cognitive_after.progression * 0.3,
                    coherence_participatory=cognitive_after.effectiveness * 0.5,
                    game_quality=cognitive_after.overall_quality,
                    consciousness_level=0.1,  # Minimal estimate
                    self_awareness=0.3  # Default
                )
                
                # Build before state
                before_state = action_data['game_state'].to_dict()
                before_state.update({
                    'scene': action_data['scene_type'].value,
                    'curiosity': action_data['motivation'].curiosity,
                    'competence': action_data['motivation'].competence,
                    'coherence': action_data['motivation'].coherence,
                    'autonomy': action_data['motivation'].autonomy
                })
                
                # Learn from experience
                self.skyrim_world.learn_from_experience(
                    action=str(action),
                    before_state=before_state,
                    after_state=after_state,
                    surprise_threshold=self.config.surprise_threshold
                )
                
                # CURRICULUM RL REWARD COMPUTATION
                # Blend coherence + game progress with curriculum stages
                if hasattr(self, 'curriculum'):
                    try:
                        curriculum_reward = self.curriculum.compute_reward(
                            state_before=before_state,
                            action=str(action),
                            state_after=after_state,
                            consciousness_before=action_data['consciousness'],
                            consciousness_after=after_consciousness
                        )
                        print(f"[CURRICULUM] Reward: {curriculum_reward:+.3f} | Stage: {self.curriculum.get_current_stage().name}")
                        # Store reward delta for Matrix C₂ competence
                        try:
                            prev = getattr(self, '_prev_curriculum_reward', 0.0)
                            self.last_curriculum_reward_delta = float(curriculum_reward - prev)
                            self._prev_curriculum_reward = float(curriculum_reward)
                        except Exception:
                            self.last_curriculum_reward_delta = float(curriculum_reward)
                        
                        # Get symbolic rules for current stage
                        rules_info = self.curriculum.get_current_rules(after_state)
                        if rules_info.get('num_triggered', 0) > 0:
                            print(f"[CURRICULUM] {rules_info['num_triggered']} symbolic rules triggered")
                            if rules_info.get('suggested_action'):
                                print(f"[CURRICULUM] Symbolic suggestion: {rules_info['suggested_action']}")
                    except Exception as e:
                        print(f"[CURRICULUM] ⚠️ Error computing curriculum reward: {e}")
                        import traceback
                        traceback.print_exc()
                else:
                    print("[CURRICULUM] ⚠️ Curriculum system not initialized, skipping")
                
                # Store RL experience (with consciousness)
                if self.rl_learner is not None:
                    action_source = action_data.get('source', 'unknown')
                    self.rl_learner.store_experience(
                        state_before=before_state,
                        action=str(action),
                        state_after=after_state,
                        done=False,
                        consciousness_before=action_data['consciousness'],
                        consciousness_after=after_consciousness,
                        action_source=action_source
                    )
                    
                    # Update smart context history
                    if hasattr(self, 'smart_context'):
                        self.smart_context.update_history(
                            state={'coherence': after_consciousness},
                            action=str(action),
                            outcome={'success': True}
                        )
                    
                    # Track action diversity and rewards (GPT-4o continuous learning recommendation)
                    self._update_action_diversity_stats(str(action), after_consciousness.coherence)
                    
                    # Train periodically
                    if cycle_count % self.config.rl_train_freq == 0:
                        print(f"[LEARNING] Training RL at cycle {cycle_count}...")
                        self.rl_learner.train_step()
                
                # Update stats
                self.stats['cycles_completed'] = cycle_count
                self.stats['total_playtime'] = time.time() - start_time
                
                if after_consciousness:
                    if 'consciousness_coherence_history' not in self.stats:
                        self.stats['consciousness_coherence_history'] = []
                    self.stats['consciousness_coherence_history'].append(after_consciousness.coherence)
                
            except asyncio.TimeoutError:
                # No learning data available
                await asyncio.sleep(1.0)
            except Exception as e:
                print(f"[LEARNING] Error: {e}")
                import traceback
                traceback.print_exc()
                await asyncio.sleep(1.0)
        
        print("[LEARNING] Loop ended")

    async def _fast_reactive_loop(self, duration_seconds: int, start_time: float):
        """Runs a fast, heuristic-based loop for immediate, reactive behaviors.

        This loop operates on a shorter interval than the main reasoning loop and
        does not use LLMs. It provides rapid responses to critical, time-sensitive
        situations, such as low health or sudden combat, ensuring the AGI can
        perform essential survival actions without waiting for slower, deliberative
        thought processes.

        Args:
            duration_seconds: The total duration for the gameplay session.
            start_time: The timestamp when the session began.
        """
        print("[FAST-LOOP] Fast reactive loop started")
        print(f"[FAST-LOOP] Interval: {self.config.fast_loop_interval}s")
        print(f"[FAST-LOOP] Health threshold: {self.config.fast_health_threshold}%")
        print(f"[FAST-LOOP] Danger threshold: {self.config.fast_danger_threshold} enemies")
        
        cycle_count = 0
        last_fast_action_time = 0
        
        while self.running and (time.time() - start_time) < duration_seconds:
            try:
                cycle_count += 1
                cycle_start = time.time()
                
                # Get current perception (non-blocking, use cached if available)
                if self.current_perception is None:
                    await asyncio.sleep(self.config.fast_loop_interval)
                    continue
                
                game_state = self.current_perception.get('game_state')
                if game_state is None:
                    await asyncio.sleep(self.config.fast_loop_interval)
                    continue
                
                scene_type = self.current_perception.get('scene_type', SceneType.UNKNOWN)
                
                # Skip fast actions in menus (they don't need reactive responses)
                # CRITICAL FIX: Don't spam heal when already in menu
                if scene_type in [SceneType.INVENTORY, SceneType.MAP, SceneType.DIALOGUE]:
                    # If in menu, only allow menu exit actions
                    # Don't try to heal or do other actions that open more menus
                    await asyncio.sleep(self.config.fast_loop_interval)
                    continue
                
                # === FAST HEURISTICS ===
                # Only trigger if LLM planning is actually slow (>20s)
                time_since_planning = time.time() - self.last_reasoning_time
                planning_timeout_reached = time_since_planning > self.config.fast_loop_planning_timeout
                
                fast_action = None
                fast_reason = None
                priority = 0  # Higher = more urgent
                
                # Skip fast loop if LLM is actively planning (unless emergency)
                if not planning_timeout_reached and game_state.health >= 20:
                    await asyncio.sleep(self.config.fast_loop_interval)
                    continue
                
                # 1. CRITICAL HEALTH - Highest priority
                if game_state.health < self.config.fast_health_threshold:
                    if game_state.health < 10:
                        # Extremely low health - immediate retreat
                        fast_action = 'retreat'
                        fast_reason = f"CRITICAL health {game_state.health:.0f}% - retreating"
                        priority = 100
                    elif game_state.magicka > 30 and scene_type not in [SceneType.INVENTORY, SceneType.MAP, SceneType.DIALOGUE]:
                        # Try healing spell - but NOT if already in a menu
                        fast_action = 'heal'
                        fast_reason = f"Low health {game_state.health:.0f}% - healing"
                        priority = 90
                    elif game_state.health < 20:
                        # Very low health - defensive stance
                        fast_action = 'block'
                        fast_reason = f"Very low health {game_state.health:.0f}%, no magicka - blocking"
                        priority = 60
                    else:
                        # Low health but not critical - allow LLM to decide
                        fast_action = None
                        priority = 0
                
                # 2. OVERWHELMING COMBAT - High priority
                elif game_state.in_combat and game_state.enemies_nearby >= self.config.fast_danger_threshold:
                    if game_state.stamina > 40:
                        # Power attack to clear space
                        fast_action = 'power_attack'
                        fast_reason = f"Surrounded by {game_state.enemies_nearby} enemies - power attack"
                        priority = 70
                    else:
                        # Defensive stance
                        fast_action = 'block'
                        fast_reason = f"Surrounded by {game_state.enemies_nearby} enemies, low stamina - blocking"
                        priority = 65
                
                # 3. ACTIVE COMBAT - Medium priority
                elif game_state.in_combat and game_state.enemies_nearby > 0:
                    # Basic combat response
                    if game_state.stamina > 50:
                        fast_action = 'attack'
                        fast_reason = f"In combat with {game_state.enemies_nearby} enemies - attacking"
                        priority = 50
                    else:
                        fast_action = 'block'
                        fast_reason = f"In combat, low stamina - blocking to recover"
                        priority = 45
                
                # 4. LOW STAMINA OUT OF COMBAT - Low priority
                elif game_state.stamina < 20 and not game_state.in_combat:
                    fast_action = 'wait'
                    fast_reason = f"Low stamina {game_state.stamina:.0f}% - resting"
                    priority = 20
                
                # 5. RESOURCE MANAGEMENT - Very low priority
                elif game_state.health < 60 and game_state.magicka > 50 and not game_state.in_combat:
                    # Preventive healing when safe
                    fast_action = 'heal'
                    fast_reason = f"Safe healing opportunity - health {game_state.health:.0f}%"
                    priority = 10
                
                # Execute fast action if one was determined
                if fast_action and priority > 0:
                    # Throttle fast actions to avoid spam
                    # Higher priority actions can execute sooner
                    if priority >= 90:
                        min_interval = 8.0  # Critical health: 8 seconds minimum
                    elif priority >= 70:
                        min_interval = 10.0  # High danger: 10 seconds minimum  
                    else:
                        min_interval = 12.0  # Normal actions: 12 seconds minimum
                    
                    time_since_last = time.time() - last_fast_action_time
                    if time_since_last < min_interval:
                        # Too soon, skip this action
                        await asyncio.sleep(self.config.fast_loop_interval)
                        continue
                    
                    # Log fast action
                    if cycle_count % 5 == 0 or priority >= 70:  # Log high priority always
                        print(f"\n[FAST-LOOP] Cycle {cycle_count} | Priority {priority}")
                        print(f"[FAST-LOOP] Action: {fast_action} | Reason: {fast_reason}")
                    
                    # Execute immediately (bypass normal action queue for critical actions)
                    execution_start = time.time()
                    try:
                        await self._execute_action(fast_action, scene_type)
                        execution_duration = time.time() - execution_start
                        
                        # Update statistics
                        self.stats['fast_action_count'] += 1
                        self.stats['fast_action_times'].append(execution_duration)
                        self.stats['actions_taken'] += 1
                        self.stats['action_success_count'] += 1  # Count as success
                        self.stats['action_source_heuristic'] += 1  # Fast loop uses heuristics
                        
                        last_fast_action_time = time.time()
                        
                        if cycle_count % 5 == 0 or priority >= 70:
                            print(f"[FAST-LOOP] Executed in {execution_duration:.3f}s")
                    
                    except Exception as e:
                        print(f"[FAST-LOOP] Execution failed: {e}")
                        # Don't crash the fast loop on errors
                
                # Wait for next cycle
                elapsed = time.time() - cycle_start
                sleep_time = max(0.1, self.config.fast_loop_interval - elapsed)
                await asyncio.sleep(sleep_time)
                
            except Exception as e:
                print(f"[FAST-LOOP] Error: {e}")
                import traceback
                traceback.print_exc()
                await asyncio.sleep(1.0)
        
        print(f"[FAST-LOOP] Loop ended ({cycle_count} cycles, {self.stats['fast_action_count']} actions)")

    async def _autonomous_play_sequential(self, duration_seconds: int, start_time: float):
        """Runs the main gameplay loop in a traditional, sequential manner.

        This method executes the classic "perceive, think, act, learn" cycle in a
        blocking sequence. It is kept primarily for backward compatibility,
        debugging, and as a fallback in case the asynchronous mode is disabled.

        Args:
            duration_seconds: The total duration for the gameplay session.
            start_time: The timestamp when the session began.
        """
        cycle_count = 0

        try:
            while self.running and (time.time() - start_time) < duration_seconds:
                cycle_count += 1
                cycle_start = time.time()

                print(f"\n{'-' * 60}")
                print(f"CYCLE {cycle_count} ({time.time() - start_time:.1f}s elapsed)")
                print(f"{'-' * 60}")

                # 1. PERCEIVE
                perception = await self.perception.perceive()
                self.current_perception = perception
                game_state = perception['game_state']
                scene_type = perception['scene_type']
                
                # Store perceptual memory in RAG
                self.memory_rag.store_perceptual_memory(
                    visual_embedding=perception['visual_embedding'],
                    scene_type=scene_type.value,
                    location=game_state.location_name,
                    context={
                        'health': game_state.health,
                        'in_combat': game_state.in_combat,
                        'layer': game_state.current_action_layer
                    }
                )

                print(f"Scene: {scene_type.value}")
                print(f"Health: {game_state.health:.0f} | Magicka: {game_state.magicka:.0f} | Stamina: {game_state.stamina:.0f}")
                print(f"Location: {game_state.location_name}")

                # Detect changes
                changes = self.perception.detect_change()
                if changes['changed']:
                    print(f"[WARN] Change detected: {changes}")

                # Detect visual stuckness (less aggressive)
                # Skip stuckness detection in menus/inventory since screen naturally doesn't change
                in_menu_scene = scene_type in [SceneType.INVENTORY, SceneType.DIALOGUE, SceneType.MAP]
                
                if (self.stats['cycles_completed'] > 5 and  # Wait more cycles before checking
                    not in_menu_scene and  # Don't check in menus
                    self.perception.detect_visual_stuckness()):
                    print("[WARN] Visually stuck! Taking gentle evasive action...")
                    await self.actions.evasive_maneuver()
                    # Brief pause then continue normally (don't skip cycle)
                    await asyncio.sleep(1.0)

                # 2. UPDATE WORLD MODEL & COMPUTE CONSCIOUSNESS
                # Convert perception to world state
                world_state = await self.agi.perceive({
                    'causal': game_state.to_dict(),
                    'visual': [perception['visual_embedding']],
                })
                
                # COMPUTE CONSCIOUSNESS STATE (KEY INTEGRATION POINT)
                print("[CONSCIOUSNESS] Computing consciousness state...")
                consciousness_context = {
                    'motivation': 'unknown',  # Will be updated after motivation computation
                    'cycle': cycle_count,
                    'scene': scene_type.value,
                    'screenshot': perception.get('screenshot'),
                    'vision_summary': perception.get('gemini_analysis')
                }
                
                if hasattr(self, 'research_advisor') and (cycle_count % 30 == 0):
                    try:
                        refreshed = await self.research_advisor.refresh_if_due(scene=scene_type.value)
                        if refreshed:
                            print("[RESEARCH] Perplexity research updated")
                        research_ctx = self.research_advisor.get_context()
                        if research_ctx:
                            consciousness_context.update(research_ctx)
                    except Exception:
                        pass
                try:
                    if (cycle_count % 10 == 0) or (scene_type == SceneType.EXPLORATION):
                        phil = await get_random_philosophical_context(hybrid_llm=getattr(self, 'hybrid_llm', None))
                        if isinstance(phil, dict):
                            consciousness_context.update(phil)
                except Exception:
                    pass
                current_consciousness = await self.consciousness_bridge.compute_consciousness(
                    game_state.to_dict(),
                    consciousness_context
                )
                
                print(f"[CONSCIOUSNESS] Coherence C = {current_consciousness.coherence:.3f}")
                print(f"[CONSCIOUSNESS]   Lo (Ontical) = {current_consciousness.coherence_ontical:.3f}")
                print(f"[CONSCIOUSNESS]   Ls (Structural) = {current_consciousness.coherence_structural:.3f}")
                print(f"[CONSCIOUSNESS]   Lp (Participatory) = {current_consciousness.coherence_participatory:.3f}")
                print(f"[CONSCIOUSNESS] Phi (Level) = {current_consciousness.consciousness_level:.3f}")
                
                if hasattr(self, 'main_brain'):
                    self.main_brain.record_output(
                        system_name='Consciousness Measurement',
                        content=f"Coherence C={current_consciousness.coherence:.3f}, Ontical={current_consciousness.coherence_ontical:.3f}, Structural={current_consciousness.coherence_structural:.3f}, Participatory={current_consciousness.coherence_participatory:.3f}, Level Phi={current_consciousness.consciousness_level:.3f}",
                        metadata={'cycle': cycle_count, 'coherence': current_consciousness.coherence},
                        success=True
                    )
                
                # Store for tracking
                self.last_consciousness = self.current_consciousness
                self.current_consciousness = current_consciousness
                
                # Update unified BeingState with all subsystem outputs
                self._update_being_state_comprehensive(
                    cycle_count=cycle_count,
                    game_state=game_state,
                    perception=perception,
                    current_consciousness=current_consciousness,
                    mot_state=None,
                    action=None
                )
                
                # Export BeingState snapshot to Main Brain every 20 cycles
                if hasattr(self, 'main_brain') and (cycle_count % 20 == 0):
                    try:
                        snapshot = self.being_state.export_snapshot()
                        self.main_brain.record_output(
                            system_name='Unified BeingState',
                            content=f"""UNIFIED STATE SNAPSHOT (Cycle {cycle_count})
Global Coherence: {snapshot['global_coherence']:.3f}
Lumina Balance: {snapshot['lumina']['balance']:.3f}
  ℓₒ (Ontic): {snapshot['lumina']['ontic']:.3f}
  ℓₛ (Structural): {snapshot['lumina']['structural']:.3f}
  ℓₚ (Participatory): {snapshot['lumina']['participatory']:.3f}
Consciousness: C={snapshot['consciousness']['coherence_C']:.3f}, Phi={snapshot['consciousness']['phi_hat']:.3f}
Emotion: {snapshot['emotion']['primary']} (intensity={snapshot['emotion']['intensity']:.2f})
Temporal Coherence: {snapshot['temporal']['temporal_coherence']:.3f}
Goal: {snapshot['goal']}
Action: {snapshot['action']}""",
                            metadata=snapshot,
                            success=True
                        )
                    except Exception:
                        pass

                # 3. ASSESS MOTIVATION
                motivation_context = {
                    'uncertainty': 0.7 if scene_type == SceneType.UNKNOWN else 0.3,
                    'predicted_delta_coherence': 0.05,  # Exploration generally increases C
                }

                mot_state = self.agi.motivation.compute_motivation(
                    state=game_state.to_dict(),
                    context=motivation_context
                )

                dominant_drive = mot_state.dominant_drive()
                print(f"\nMotivation: {dominant_drive.value.upper()}")
                print(f"  Curiosity: {mot_state.curiosity:.2f}")
                print(f"  Competence: {mot_state.competence:.2f}")
                print(f"  Coherence: {mot_state.coherence:.2f}")
                print(f"  Autonomy: {mot_state.autonomy:.2f}")

                # 4. FORM/UPDATE GOALS
                if len(self.agi.goal_system.get_active_goals()) == 0 or cycle_count % 10 == 0:
                    goal = self.agi.goal_system.generate_goal(
                        dominant_drive.value,
                        {'scene': scene_type.value, 'location': game_state.location_name}
                    )
                    self.current_goal = goal.description
                    print(f"\n[GOAL] New goal: {self.current_goal}")

                # 5. PLAN ACTION (with strategic planning)
                # Check if we should use strategic planner
                terrain_type = self.skyrim_world.classify_terrain_from_scene(
                    scene_type.value,
                    game_state.in_combat
                )
                
                # Always use RL reasoning neuron for action selection
                # (Strategic planner is consulted within _plan_action if it has patterns)
                action = await self._plan_action(
                    perception=perception,
                    motivation=mot_state,
                    goal=self.current_goal
                )

                print(f"\n-> Action: {action}")

                # 6. EXECUTE ACTION
                before_state = game_state.to_dict()
                # Add motivation to state for RL
                before_state.update({
                    'scene': scene_type.value,
                    'curiosity': mot_state.curiosity,
                    'competence': mot_state.competence,
                    'coherence': mot_state.coherence,
                    'autonomy': mot_state.autonomy
                })

                try:
                    await self._execute_action(action, scene_type)
                    self.stats['actions_taken'] += 1
                    self.stats['action_success_count'] += 1  # Count as success
                    self.stats['action_source_heuristic'] += 1  # Auxiliary loop uses heuristics
                    print(f"[ACTION] Successfully executed: {action}")
                except Exception as e:
                    print(f"[ERROR] Action execution failed: {e}")
                    # Try a simple fallback action
                    try:
                        await self.actions.look_around()
                        print("[RECOVERY] Performed fallback look_around")
                    except:
                        print("[ERROR] Even fallback action failed")

                # Wait for game to respond (slightly longer for Skyrim)
                await asyncio.sleep(max(1.5, self.config.cycle_interval))

                # 7. LEARN FROM OUTCOME
                # Perceive again to see outcome
                after_perception = await self.perception.perceive()
                after_state = after_perception['game_state'].to_dict()
                # Add motivation to after_state for RL
                after_mot = self.agi.motivation.compute_motivation(
                    state=after_state,
                    context=motivation_context
                )
                after_state.update({
                    'scene': after_perception['scene_type'].value,
                    'curiosity': after_mot.curiosity,
                    'competence': after_mot.competence,
                    'coherence': after_mot.coherence,
                    'autonomy': after_mot.autonomy
                })
                
                # COMPUTE CONSCIOUSNESS AFTER ACTION (KEY)
                print("[CONSCIOUSNESS] Computing post-action consciousness...")
                post_consciousness_context = {
                    'motivation': motivation_context.get('predicted_delta_coherence', 'unknown'),
                    'cycle': cycle_count,
                    'scene': after_perception['scene_type'].value,
                    'screenshot': after_perception.get('screenshot'),
                    'vision_summary': after_perception.get('gemini_analysis')
                }
                try:
                    if (cycle_count % 10 == 0) or (scene_type == SceneType.EXPLORATION):
                        phil = await get_random_philosophical_context(hybrid_llm=getattr(self, 'hybrid_llm', None))
                        if isinstance(phil, dict):
                            post_consciousness_context.update(phil)
                except Exception:
                    pass
                after_consciousness = await self.consciousness_bridge.compute_consciousness(
                    after_state,
                    post_consciousness_context
                )
                
                # UPDATE BEINGSTATE WITH POST-ACTION CONSCIOUSNESS (CRITICAL FIX)
                self._update_being_state_comprehensive(
                    cycle_count=cycle_count,
                    game_state=after_perception['game_state'],
                    perception=after_perception,
                    current_consciousness=after_consciousness,  # Fresh post-action consciousness
                    mot_state=after_mot,
                    action=action
                )
                
                # Show coherence change
                if self.current_consciousness:
                    coherence_delta = after_consciousness.coherence_delta(self.current_consciousness)
                    print(f"[CONSCIOUSNESS] ΔC = {coherence_delta:+.3f}", end="")
                    if coherence_delta > 0.02:
                        print(" (ETHICAL [OK])")
                    elif coherence_delta < -0.02:
                        print(" (UNETHICAL [X])")
                    else:
                        print(" (NEUTRAL)")

                # Learn causal relationships
                self.skyrim_world.learn_from_experience(
                    action=str(action),
                    before_state=before_state,
                    after_state=after_state,
                    surprise_threshold=self.config.surprise_threshold
                )
                
                # Learn terrain knowledge
                terrain_type = self.skyrim_world.classify_terrain_from_scene(
                    scene_type.value,
                    after_state.get('in_combat', False)
                )
                self.skyrim_world.learn_terrain_feature(
                    game_state.location_name,
                    terrain_type,
                    {
                        'scene_type': scene_type.value,
                        'action_taken': str(action),
                        'layer_used': game_state.current_action_layer
                    }
                )
                
                # Update terrain safety based on combat
                self.skyrim_world.update_terrain_safety(
                    game_state.location_name,
                    after_state.get('in_combat', False)
                )
                
                # CONTINUUM PHASE 1: Observe this cycle
                if hasattr(self, 'continuum'):
                    try:
                        observation = await self.continuum.observe_cycle(
                            being_state=self.being_state,
                            actual_action=str(action),
                            actual_outcome={
                                'coherence': after_consciousness.coherence if after_consciousness else 0.5,
                                'success': True,  # Action executed successfully
                                'coherence_delta': after_consciousness.coherence_delta(self.current_consciousness) if self.current_consciousness and after_consciousness else 0.0
                            }
                        )
                        if observation is None:
                            print(f"[CONTINUUM] ⚠️ Observation skipped (BeingState: C={self.being_state.coherence_C:.3f}, cycle={self.being_state.cycle_number})")
                    except Exception as e:
                        print(f"[CONTINUUM] ❌ Observation failed: {e}")
                        import traceback
                        traceback.print_exc()
                
                # Record experience in strategic planner
                success = self._evaluate_action_success(before_state, after_state, action)
                self.strategic_planner.record_experience(
                    context={
                        'scene': scene_type.value,
                        'health': before_state.get('health', 100),
                        'in_combat': before_state.get('in_combat', False),
                        'location': game_state.location_name
                    },
                    action=str(action),
                    outcome=after_state,
                    success=success
                )
                
                # Record observation for meta-strategist
                if self.rl_learner:
                    reward = self.rl_learner.compute_reward(before_state, str(action), after_state)
                    self.meta_strategist.observe(
                        state=before_state,
                        action=str(action),
                        reward=reward
                    )
                
                # Store cognitive memory in RAG
                self.memory_rag.store_cognitive_memory(
                    situation=before_state,
                    action_taken=str(action),
                    outcome=after_state,
                    success=success,
                    reasoning=f"Motivation: {dominant_drive.value}, Layer: {game_state.current_action_layer}"
                )
                
                # Record menu action if in menu
                if scene_type in [SceneType.INVENTORY, SceneType.MAP]:
                    after_scene = after_perception['scene_type']
                    self.menu_learner.record_action(
                        action=str(action),
                        success=success,
                        resulted_in_menu=after_scene.value if after_scene != scene_type else None
                    )
                elif self.menu_learner.current_menu:
                    # Exited menu
                    self.menu_learner.exit_menu()

                # Record in episodic memory (now with consciousness)
                self.agi.learner.experience(
                    data={
                        'cycle': cycle_count,
                        'scene': scene_type.value,
                        'action': str(action),
                        'motivation': dominant_drive.value,
                        'before': before_state,
                        'after': after_state,
                        'consciousness_before': self.current_consciousness,
                        'consciousness_after': after_consciousness,
                        'coherence_delta': after_consciousness.coherence_delta(self.current_consciousness) if self.current_consciousness else 0.0
                    },
                    context='skyrim_gameplay',
                    importance=0.5
                )

                # RL: Store experience with consciousness states (KEY INTEGRATION)
                if self.rl_learner is not None:
                    # Store experience for RL WITH CONSCIOUSNESS
                    action_source = self.last_action_source if hasattr(self, 'last_action_source') else 'unknown'
                    self.rl_learner.store_experience(
                        state_before=before_state,
                        action=str(action),
                        action_source=action_source,
                        state_after=after_state,
                        done=False,
                        consciousness_before=self.current_consciousness,  # NEW
                        consciousness_after=after_consciousness  # NEW
                    )
                    
                    print(f"[RL] Experience stored with consciousness (ΔC = {after_consciousness.coherence_delta(self.current_consciousness) if self.current_consciousness else 0.0:+.3f})")

                    # Train periodically
                    if cycle_count % self.config.rl_train_freq == 0:
                        print(f"[RL] Training at cycle {cycle_count}...")
                        self.rl_learner.train_step()

                    # Save RL model periodically
                    if cycle_count % 50 == 0:
                        self.rl_learner.save('skyrim_rl_model.pkl')
                
                # Cloud RL: Store rich experience with cloud evaluation
                if self.cloud_rl_memory is not None and after_consciousness:
                    from singularis.skyrim.cloud_rl_system import Experience
                    
                    # Build state vector (simple encoding for now)
                    state_vec = np.array([
                        perception.get('game_state', {}).get('health', 100) / 100.0 if isinstance(perception.get('game_state'), dict) else getattr(perception.get('game_state'), 'health', 100) / 100.0,
                        perception.get('game_state', {}).get('stamina', 100) / 100.0 if isinstance(perception.get('game_state'), dict) else getattr(perception.get('game_state'), 'stamina', 100) / 100.0,
                        perception.get('game_state', {}).get('magicka', 100) / 100.0 if isinstance(perception.get('game_state'), dict) else getattr(perception.get('game_state'), 'magicka', 100) / 100.0,
                        float(perception.get('game_state', {}).get('in_combat', False) if isinstance(perception.get('game_state'), dict) else getattr(perception.get('game_state'), 'in_combat', False)),
                        float(perception.get('game_state', {}).get('enemies_nearby', 0)) / 10.0 if isinstance(perception.get('game_state'), dict) else float(getattr(perception.get('game_state'), 'enemies_nearby', 0)) / 10.0
                    ])
                    
                    next_state_vec = np.array([
                        after_state.get('health', 100) / 100.0,
                        after_state.get('stamina', 100) / 100.0,
                        after_state.get('magicka', 100) / 100.0,
                        float(after_state.get('in_combat', False)),
                        float(after_state.get('enemies_nearby', 0)) / 10.0
                    ])
                    
                    cloud_exp = Experience(
                        state_vector=state_vec,
                        state_description=f"{scene_type.value}: {perception.get('visual_analysis', '')[:100]}",
                        scene_type=scene_type.value,
                        location=perception.get('game_state', {}).get('location_name', 'Unknown') if isinstance(perception.get('game_state'), dict) else getattr(perception.get('game_state'), 'location_name', 'Unknown'),
                        health=float(state_vec[0] * 100),
                        stamina=float(state_vec[1] * 100),
                        magicka=float(state_vec[2] * 100),
                        enemies_nearby=int(state_vec[4] * 10),
                        in_combat=bool(state_vec[3]),
                        action=str(action),
                        action_type=action.action_type.value if hasattr(action, 'action_type') else 'unknown',
                        reward=0.0,  # Will be computed by cloud RL
                        next_state_vector=next_state_vec,
                        next_state_description=f"After {action}",
                        done=False,
                        coherence_before=self.current_consciousness.coherence if self.current_consciousness else 0.0,
                        coherence_after=after_consciousness.coherence,
                        coherence_delta=after_consciousness.coherence_delta(self.current_consciousness) if self.current_consciousness else 0.0,
                        episode_id=int(time.time()),
                        step_id=cycle_count
                    )
                    
                    # Add to cloud RL memory (will auto-save periodically)
                    import asyncio
                    asyncio.create_task(self.cloud_rl_memory.add(cloud_exp, request_cloud_evaluation=(cycle_count % 10 == 0)))
                    print(f"[CLOUD-RL] Experience added to memory (total: {len(self.cloud_rl_memory.experiences)})")


                # 8. UPDATE STATS (with consciousness tracking)
                self.stats['cycles_completed'] = cycle_count
                self.stats['total_playtime'] = time.time() - start_time

                # Track consciousness coherence (primary metric)
                if after_consciousness:
                    if 'consciousness_coherence_history' not in self.stats:
                        self.stats['consciousness_coherence_history'] = []
                    self.stats['consciousness_coherence_history'].append(after_consciousness.coherence)
                    
                    # Also track by Lumina
                    if 'coherence_by_lumina' not in self.stats:
                        self.stats['coherence_by_lumina'] = {
                            'ontical': [],
                            'structural': [],
                            'participatory': []
                        }
                    self.stats['coherence_by_lumina']['ontical'].append(after_consciousness.coherence_ontical)
                    self.stats['coherence_by_lumina']['structural'].append(after_consciousness.coherence_structural)
                    self.stats['coherence_by_lumina']['participatory'].append(after_consciousness.coherence_participatory)
                
                # Track game state quality (secondary metric)
                try:
                    cognitive_state = SkyrimCognitiveState.from_game_state(after_state)
                    self.stats['game_state_quality_history'].append(cognitive_state.overall_quality)
                except Exception:
                    # Fallback if cognitive state computation fails
                    pass

                # Auto-save periodically
                if time.time() - self.last_save_time > self.config.save_interval:
                    if not self.config.dry_run:
                        await self.actions.quick_save_checkpoint()
                    self.last_save_time = time.time()

                # Cycle complete
                cycle_duration = time.time() - cycle_start
                print(f"\n[OK] Cycle complete ({cycle_duration:.2f}s)")

        except KeyboardInterrupt:
            print("\n\n[WARN] User interrupted - stopping gracefully...")
        except Exception as e:
            print(f"\n\n[ERROR] Error during gameplay: {e}")
            import traceback
            traceback.print_exc()
        finally:
            self.running = False
            print(f"\n{'=' * 60}")
            print("AUTONOMOUS GAMEPLAY COMPLETE")
            print(f"{'=' * 60}")
            
            # Cleanup connections
            await self._cleanup_connections()
            
            self._print_final_stats()

    def _detect_stuck_failsafe(
        self,
        perception: Dict[str, Any],
        game_state
    ) -> Tuple[bool, str, str]:
        """Performs a multi-tier, failsafe stuck detection analysis.

        This method uses a variety of heuristics that do not rely on cloud-based
        LLMs to determine if the AGI is stuck. It checks for action repetition,
        visual similarity in recent frames, coherence stagnation, and specific
        patterns indicative of being stuck in menus or combat. This serves as a
        robust, low-latency backup to LLM-based stuck detection.

        Args:
            perception: The current perception data dictionary.
            game_state: The current game state object.

        Returns:
            A tuple containing:
            - A boolean indicating if a stuck state is detected.
            - A string describing the reasons for the detection.
            - A string with a suggested recovery action.
        """
        current_time = time.time()
        
        # Cooldown check
        if current_time - self.last_stuck_detection_time < self.stuck_detection_cooldown:
            return (False, "", "")
        
        stuck_indicators = []
        recovery_action = ""
        
        # 1. Action repetition detection
        if len(self.action_history) >= 8:
            recent_8 = self.action_history[-8:]
            unique_actions = len(set(recent_8))
            
            if unique_actions <= 2:
                stuck_indicators.append(f"Only {unique_actions} unique actions in last 8")
                recovery_action = "jump"  # Break pattern
        
        # 2. Same action spam detection
        if self.consecutive_same_action >= 5:
            stuck_indicators.append(f"Same action '{self.last_executed_action}' repeated {self.consecutive_same_action}x")
            recovery_action = "sneak" if self.last_executed_action != "sneak" else "jump"
        
        # 3. Visual embedding similarity (stuck in same visual scene)
        if len(self.visual_embedding_history) >= 5:
            recent_embeddings = self.visual_embedding_history[-5:]
            
            # Calculate average similarity between consecutive embeddings
            similarities = []
            for i in range(len(recent_embeddings) - 1):
                sim = np.dot(recent_embeddings[i], recent_embeddings[i+1])
                similarities.append(sim)
            
            avg_similarity = np.mean(similarities) if similarities else 0
            
            if avg_similarity > 0.95:  # Very similar visual scenes
                stuck_indicators.append(f"Visual scene unchanged (similarity={avg_similarity:.2f})")
                recovery_action = "jump"
        
        # 4. Coherence stagnation detection
        if len(self.coherence_history) >= 10:
            recent_coherence = self.coherence_history[-10:]
            coherence_variance = np.var(recent_coherence)
            
            if coherence_variance < 0.001:  # No coherence change
                stuck_indicators.append(f"Coherence stagnant (var={coherence_variance:.4f})")
                recovery_action = "activate"  # Try interacting
        
        # 5. Menu stuck detection
        if game_state.in_menu and len(self.action_history) >= 5:
            recent_5 = self.action_history[-5:]
            if all(a in ['activate', 'navigate_inventory', 'exit_menu'] for a in recent_5):
                stuck_indicators.append("Stuck in menu navigation")
                recovery_action = "exit_menu"
        
        # 6. Combat stuck detection
        if game_state.in_combat and len(self.action_history) >= 6:
            recent_6 = self.action_history[-6:]
            if recent_6.count('attack') >= 5:
                stuck_indicators.append("Spamming attack without progress")
                recovery_action = "dodge"
        
        # Determine if stuck
        is_stuck = len(stuck_indicators) >= 2  # At least 2 indicators
        
        if is_stuck:
            reason = "; ".join(stuck_indicators)
            self.last_stuck_detection_time = current_time
            self.stuck_recovery_attempts += 1
            
            print(f"[FAILSAFE-STUCK] Detected stuck state!")
            print(f"[FAILSAFE-STUCK] Indicators: {reason}")
            print(f"[FAILSAFE-STUCK] Recovery attempt #{self.stuck_recovery_attempts}")
            
            # Escalate recovery based on attempts
            if self.stuck_recovery_attempts >= 3:
                recovery_action = "look_around"  # Drastic measure
                print(f"[FAILSAFE-STUCK] Escalating to drastic recovery: {recovery_action}")
            
            return (True, reason, recovery_action)
        
        # Reset recovery attempts if not stuck
        if self.stuck_recovery_attempts > 0 and not is_stuck:
            self.stuck_recovery_attempts = 0
        
        return (False, "", "")
    
    async def _detect_stuck_with_gemini(
        self,
        perception: Dict[str, Any],
        recent_actions: List[str]
    ) -> Tuple[bool, str]:
        """Uses Gemini's vision capabilities for Tier 1 stuck detection.

        This method sends the current screenshot and a history of recent actions
        to the Gemini vision model, asking it to analyze the situation for signs
        of being stuck. If Gemini confirms a stuck state, it also suggests a
        recovery action.

        Args:
            perception: The current perception data, including the screenshot.
            recent_actions: A list of the most recent actions taken by the AGI.

        Returns:
            A tuple containing:
            - A boolean indicating if a stuck state was detected.
            - A string with the suggested recovery action, or an empty string.
        """
        if not self.hybrid_llm or not perception.get('screenshot'):
            return (False, "")
        
        try:
            # Build stuck detection prompt
            prompt = f"""Analyze this Skyrim gameplay screenshot and recent actions to detect if the player is stuck.

Recent actions (last 5): {', '.join(recent_actions[-5:])}

Check for these stuck indicators:
1. Player facing a wall/obstacle repeatedly
2. Same visual scene for multiple actions
3. Character not making progress (same location)
4. Stuck in geometry/terrain
5. Menu stuck open
6. Dialogue loop

Is the player stuck? Answer with:
STUCK: yes/no
REASON: <brief explanation>
RECOVERY: <suggested action to unstuck>"""

            response = await self.hybrid_llm.analyze_image(
                prompt=prompt,
                image=perception['screenshot']
            )
            
            # Parse response
            is_stuck = "STUCK: yes" in response.lower()
            
            if is_stuck:
                # Extract reason
                reason_line = [l for l in response.split('\n') if 'REASON:' in l]
                reason = reason_line[0].split('REASON:')[1].strip() if reason_line else "Unknown"
                
                # Extract recovery action
                recovery_line = [l for l in response.split('\n') if 'RECOVERY:' in l]
                recovery = recovery_line[0].split('RECOVERY:')[1].strip() if recovery_line else ""
                
                print(f"[GEMINI-STUCK] Detected stuck state!")
                print(f"[GEMINI-STUCK] Reason: {reason}")
                print(f"[GEMINI-STUCK] Recovery: {recovery}")
                
                return (True, recovery)
            
            return (False, "")
            
        except Exception as e:
            print(f"[GEMINI-STUCK] Detection failed: {e}")
            return (False, "")
    
    async def _get_cloud_llm_action_recommendation(
        self,
        perception: Dict[str, Any],
        state_dict: Dict[str, Any],
        q_values: Dict[str, float],
        available_actions: List[str],
        motivation,
        use_full_moe: bool = False
    ) -> Optional[Tuple[str, str]]:
        """Gets an action recommendation from the parallel cloud LLM system.

        This function orchestrates a query to the configured cloud LLM architecture
        (either Hybrid, MoE, or both in parallel). It constructs vision and
        reasoning prompts, leverages smart context and curriculum knowledge, and
        can even run a deep causal analysis with a GPT-5-level model. It includes
        a fallback to a local LLM if the cloud APIs fail.

        Args:
            perception: The current perception data dictionary.
            state_dict: A dictionary representing the current game state.
            q_values: A dictionary of Q-values for available actions from the RL system.
            available_actions: A list of currently valid action strings.
            motivation: The current motivation state object.
            use_full_moe: If True, uses the full MoE+Hybrid parallel mode. If False,
                defaults to the faster Hybrid-only mode.

        Returns:
            A tuple containing the recommended action string and the full reasoning
            text, or None if no recommendation could be obtained.
        """
        if not self.config.use_parallel_mode and not self.moe and not self.hybrid_llm:
            return None
        
        try:
            # Build prompts
            vision_prompt = f"""Analyze this Skyrim gameplay situation:
Scene: {perception.get('scene_type', 'unknown')}
Health: {state_dict.get('health', 100)}%
Stamina: {state_dict.get('stamina', 100)}%
Magicka: {state_dict.get('magicka', 100)}%
In Combat: {state_dict.get('in_combat', False)}
Enemies Nearby: {state_dict.get('enemies_nearby', 0)}

What do you see and what threats/opportunities are present?"""

            reasoning_prompt = f"""Based on the current situation, recommend the best action:

Available actions: {', '.join(available_actions)}

Top Q-values (learned preferences):
{chr(10).join(f'- {k}: {v:.2f}' for k, v in sorted(q_values.items(), key=lambda x: x[1], reverse=True)[:5])}

Current motivation: {motivation.dominant_drive().value}

Recommend ONE action from the available list and explain why.
Format: ACTION: <action_name>
REASONING: <explanation>"""

            # Query system based on priority with local fallback
            reasoning_text = None
            
            try:
                # Full parallel (MoE+Hybrid+WorldModel) only for critical situations
                if self.config.use_parallel_mode and use_full_moe:
                    print("[CLOUD-LLM] Using FULL parallel (MoE + Hybrid + GPT-5-thinking)")
                    response = await self.query_parallel_llm(
                        vision_prompt=vision_prompt,
                        reasoning_prompt=reasoning_prompt,
                        image=perception.get('screenshot'),
                        context=state_dict
                    )
                    reasoning_text = response['reasoning']
                    if response.get('world_model'):
                        print("[WORLD-MODEL] Deep causal analysis included")
                        
                        # Record GPT-5-thinking world model to Main Brain
                        if hasattr(self, 'main_brain') and self.main_brain:
                            self.main_brain.record_output(
                                system_name='GPT-5-thinking World Model',
                                content=response['world_model'],
                                metadata={
                                    'consciousness_score': response.get('world_model_consciousness', 0.0),
                                    'coherence': response.get('coherence', 0.0),
                                    'source': 'parallel',
                                    'integration_context': 'sensorimotor+perceptual+cognitive',
                                    'timestamp': time.time()
                                },
                                success=True
                            )
                # Hybrid only for routine decisions (much faster, less API calls)
                elif self.hybrid_llm:
                    print("[CLOUD-LLM] Using Hybrid (fast mode)")
                    
                    # Get curriculum knowledge
                    curriculum_knowledge = None
                    if self.curriculum_rag:
                        categories = CATEGORY_MAPPINGS.get('strategy', []) + CATEGORY_MAPPINGS.get('psychology', [])
                        knowledge_results = self.curriculum_rag.retrieve_knowledge(
                            query=reasoning_prompt,
                            top_k=1,
                            categories=categories
                        )
                        if knowledge_results:
                            curriculum_knowledge = knowledge_results[0].excerpt
                            print("[CURRICULUM] Strategic knowledge retrieved")
                    
                    # Build smart context
                    smart_prompt = self.smart_context.build_prompt_with_context(
                        base_prompt=reasoning_prompt,
                        task_type='reasoning',
                        perception=perception,
                        state_dict=state_dict,
                        q_values=q_values,
                        available_actions=available_actions,
                        curriculum_knowledge=curriculum_knowledge
                    )
                    print(f"[SMART-CONTEXT] Optimized context ({len(smart_prompt)} chars)")
                    
                    # Run reasoning and world model in parallel
                    parallel_tasks = [
                        self.hybrid_llm.generate_reasoning(
                            prompt=smart_prompt,
                            system_prompt="You are an expert Skyrim player providing tactical advice."
                        )
                    ]
                    
                    # Add world model if available (GPT-5-thinking)
                    if hasattr(self.hybrid_llm, 'openai') and self.hybrid_llm.openai:
                        # Get scientific knowledge
                        science_knowledge = None
                        if self.curriculum_rag:
                            categories = CATEGORY_MAPPINGS.get('science', []) + ['Philosophy Of Science']
                            knowledge_results = self.curriculum_rag.retrieve_knowledge(
                                query="causal relationships and system dynamics",
                                top_k=1,
                                categories=categories
                            )
                            if knowledge_results:
                                science_knowledge = knowledge_results[0].excerpt
                        
                        # Build smart context for world modeling
                        world_model_prompt = self.smart_context.build_prompt_with_context(
                            base_prompt="Analyze causal dynamics and long-term consequences of this situation.",
                            task_type='world_model',
                            perception=perception,
                            state_dict=state_dict,
                            q_values=q_values,
                            available_actions=available_actions,
                            curriculum_knowledge=science_knowledge
                        )
                        
                        parallel_tasks.append(
                            self.hybrid_llm.generate_world_model(
                                prompt=world_model_prompt,
                                system_prompt="Analyze causal relationships using scientific principles.",
                                temperature=0.8,
                                max_tokens=1024
                            )
                        )
                    
                    # Execute in parallel (cloud models don't block each other)
                    parallel_results = await asyncio.gather(*parallel_tasks, return_exceptions=True)
                    reasoning_text = parallel_results[0] if not isinstance(parallel_results[0], Exception) else None
                    
                    # Incorporate world model if available
                    if len(parallel_results) > 1 and not isinstance(parallel_results[1], Exception):
                        world_analysis = parallel_results[1]
                        reasoning_text = f"{reasoning_text}\n\n[Deep Analysis]\n{world_analysis}"
                        print("[WORLD-MODEL] Parallel deep analysis completed")
                        
                        # Record GPT-5-thinking world model to Main Brain
                        if hasattr(self, 'main_brain') and self.main_brain:
                            # Measure consciousness of the world model narrative
                            from ..consciousness.measurement import ConsciousnessMeasurement
                            consciousness_measure = ConsciousnessMeasurement()
                            
                            world_model_trace = consciousness_measure.measure(
                                content=world_analysis,
                                query="unified consciousness synthesis",
                                lumen_focus="participatum"
                            )
                            
                            self.main_brain.record_output(
                                system_name='GPT-5-thinking World Model',
                                content=world_analysis,
                                metadata={
                                    'consciousness_score': world_model_trace.overall_consciousness,
                                    'phi': world_model_trace.phi,
                                    'gwt_salience': world_model_trace.gwt_salience,
                                    'hot_depth': world_model_trace.hot_depth,
                                    'integration': world_model_trace.integration_score,
                                    'differentiation': world_model_trace.differentiation_score,
                                    'source': 'hybrid',
                                    'timestamp': time.time()
                                },
                                success=True
                            )
                elif self.moe:
                    _, reasoning_resp = await self.moe.query_all_experts(
                        vision_prompt=vision_prompt,
                        reasoning_prompt=reasoning_prompt,
                        image=perception.get('screenshot'),
                        context=state_dict
                    )
                    reasoning_text = reasoning_resp.consensus
            except Exception as e:
                print(f"[CLOUD-LLM] Cloud API failed: {e}")
                reasoning_text = None
            
            # Fallback to local LLM if cloud failed
            if not reasoning_text and self.huihui_llm:
                print("[FALLBACK] Cloud LLM failed, using local Huihui")
                try:
                    local_response = await self.huihui_llm.generate(
                        prompt=reasoning_prompt,
                        system_prompt="You are an expert Skyrim player. Recommend ONE action.",
                        max_tokens=200
                    )
                    reasoning_text = local_response
                except Exception as local_e:
                    print(f"[FALLBACK] Local LLM also failed: {local_e}")
                    return None
            
            if not reasoning_text:
                return None
            
            # Parse action from response
            if "ACTION:" in reasoning_text:
                action_line = [l for l in reasoning_text.split('\n') if 'ACTION:' in l][0]
                action = action_line.split('ACTION:')[1].strip().lower()
                
                # Validate action is in available list
                if action in available_actions:
                    print(f"[CLOUD-LLM] Recommended: {action}")
                    return (action, reasoning_text)
            
            return None
            
        except Exception as e:
            print(f"[CLOUD-LLM] Error: {e}")
            return None
    
    async def _claude_background_reasoning(
        self,
        perception: Dict[str, Any],
        state_dict: Dict[str, Any],
        game_state: Any,
        scene_type: Any,
        motivation: Any
    ) -> None:
        """Performs fast, non-blocking strategic analysis using Claude Haiku.

        This method is designed to run in the background, providing tactical
        insights without delaying the main action-planning loop. It queries the
        fast and efficient Claude Haiku model for a quick analysis of the current
        situation. The resulting insights are not used for immediate action but
        are instead stored in the cognitive memory (RAG) for future reference
        and learning.

        Args:
            perception: The current perception data dictionary.
            state_dict: A dictionary representing the current game state.
            game_state: The current game state object.
            scene_type: The current scene type enum.
            motivation: The current motivation state object.
        """
        try:
            print("[CLAUDE-HAIKU] Running fast strategic analysis...")
            
            # Build concise reasoning prompt for Haiku (faster)
            reasoning_prompt = f"""Quick Skyrim tactical analysis:

Scene: {scene_type.value} | Location: {game_state.location_name}
Health: {state_dict.get('health', 100)}% | Combat: {state_dict.get('in_combat', False)} | Enemies: {state_dict.get('enemies_nearby', 0)}

Provide:
1. Immediate threats/opportunities
2. Recommended tactical approach
3. Key considerations

Be concise and actionable."""

            # Query Claude Haiku (fast, no extended thinking)
            reasoning_text = await self.hybrid_llm.generate_reasoning(
                prompt=reasoning_prompt,
                system_prompt="You are a fast tactical advisor for Skyrim. Be concise and actionable.",
                temperature=0.5,
                max_tokens=512  # Reduced for speed
            )
            
            print(f"[CLAUDE-HAIKU] [OK] Analysis complete ({len(reasoning_text)} chars)")
            
            # Store in memory RAG
            self.memory_rag.store_cognitive_memory(
                situation={
                    'type': 'claude_haiku_tactical_analysis',
                    'scene': scene_type.value,
                    'location': game_state.location_name,
                    'health': state_dict.get('health', 100),
                    'in_combat': state_dict.get('in_combat', False)
                },
                action_taken='background_reasoning',
                outcome={'analysis_length': len(reasoning_text)},
                success=True,
                reasoning=reasoning_text
            )
            
            # Hebbian: Record Claude Haiku contribution
            self.hebbian.record_activation(
                system_name='claude_haiku_reasoning',
                success=True,
                contribution_strength=0.7,  # Slightly lower than Sonnet
                context={'stored_to_memory': True, 'model': 'haiku'}
            )
            
            print("[CLAUDE-HAIKU] [OK] Stored to memory")
            
        except Exception as e:
            print(f"[CLAUDE-HAIKU] Error: {e}")
            self.hebbian.record_activation(
                system_name='claude_haiku_reasoning',
                success=False,
                contribution_strength=0.3
            )
    
    async def _dialectical_reasoning(
        self,
        situation: str,
        perspectives: Dict[str, str],
        context: Optional[Dict[str, Any]] = None
    ) -> Dict[str, str]:
        """Performs a dialectical synthesis of multiple perspectives using Huihui MoE.

        This method implements a Hegelian dialectic (thesis, antithesis, synthesis)
        to resolve contradictions and achieve a higher-order understanding of a
        situation. It takes a description of the current situation and a dictionary
        of conflicting or varied perspectives from different subsystems, then uses
        a specialized LLM (Huihui) to generate a unified synthesis.

        Args:
            situation: A string describing the current game situation.
            perspectives: A dictionary where keys are the names of the perspectives
                (e.g., "RL System", "Strategic Planner") and values are their
                textual analyses or recommendations.
            context: Optional additional context for the reasoning process.

        Returns:
            A dictionary containing the 'synthesis' text, the full 'reasoning'
            process, and the estimated 'coherence_gain' from the synthesis.
        """
        if not self.huihui_llm:
            return {
                'synthesis': list(perspectives.values())[0] if perspectives else "",
                'reasoning': "No dialectical LLM available",
                'coherence_gain': 0.0
            }
        
        # Build dialectical prompt
        perspectives_text = "\n\n".join([
            f"**{name.upper()}:**\n{content}"
            for name, content in perspectives.items()
        ])
        
        dialectical_prompt = f"""DIALECTICAL SYNTHESIS

Situation: {situation}

Multiple perspectives on this situation:

{perspectives_text}

Your task is to perform Hegelian dialectical synthesis:

1. THESIS: Identify the primary perspective and its core claim
2. ANTITHESIS: Identify contradictions or tensions with other perspectives
3. SYNTHESIS: Find higher-order unity that transcends the contradiction

The synthesis should:
- Preserve partial truths from each perspective
- Resolve apparent contradictions
- Achieve greater coherence than any single view
- Provide actionable insight

Format your response as:
THESIS: <primary claim>
ANTITHESIS: <contradicting view>
SYNTHESIS: <unified understanding>
COHERENCE GAIN: <estimate 0.0-1.0 how much this increases understanding>
"""

        try:
            print("[DIALECTICAL] Performing thesis-antithesis-synthesis with Huihui...")
            result = await asyncio.wait_for(
                self.huihui_llm.generate(
                    prompt=dialectical_prompt,
                    max_tokens=512
                ),
                timeout=60.0
            )
            
            response = result.get('content', '') if isinstance(result, dict) else str(result)
            print(f"[DIALECTICAL] Synthesis complete ({len(response)} chars)")
            
            # Parse response
            synthesis = ""
            reasoning = response
            coherence_gain = 0.0
            
            # Extract synthesis section
            if "SYNTHESIS:" in response:
                synthesis_start = response.find("SYNTHESIS:") + len("SYNTHESIS:")
                synthesis_end = response.find("COHERENCE GAIN:", synthesis_start)
                if synthesis_end == -1:
                    synthesis_end = len(response)
                synthesis = response[synthesis_start:synthesis_end].strip()
            
            # Extract coherence gain
            if "COHERENCE GAIN:" in response:
                try:
                    gain_text = response.split("COHERENCE GAIN:")[1].strip().split()[0]
                    coherence_gain = float(gain_text)
                except:
                    coherence_gain = 0.05  # Default modest gain
            
            return {
                'synthesis': synthesis if synthesis else response,
                'reasoning': reasoning,
                'coherence_gain': coherence_gain
            }
            
        except asyncio.TimeoutError:
            print("[DIALECTICAL] Timed out after 60s")
            return {
                'synthesis': list(perspectives.values())[0] if perspectives else "",
                'reasoning': "Dialectical synthesis timed out",
                'coherence_gain': 0.0
            }
        except Exception as e:
            print(f"[DIALECTICAL] Error: {e}")
            return {
                'synthesis': list(perspectives.values())[0] if perspectives else "",
                'reasoning': f"Error: {e}",
                'coherence_gain': 0.0
            }
    
    async def _plan_action(
        self,
        perception: Dict[str, Any],
        motivation,
        goal: Optional[str] = None
    ) -> Optional[str]:
        """Plans the next action by synthesizing inputs from multiple cognitive systems.

        This is a critical, complex method at the heart of the AGI's decision-
        making process. It follows a hierarchical, multi-stage approach:
        1.  **Overrides & Failsafes:** It first checks for high-priority overrides
            from sensorimotor feedback, expert rules, and emergency systems.
        2.  **Motor Control Layer:** It consults a structured motor control layer
            for reflexive, navigational, or combat-specific actions.
        3.  **RL & Heuristics:** It intelligently blends recommendations from the
            Reinforcement Learning system (Q-values) with heuristic strategies to
            ensure both learned optimization and behavioral diversity.
        4.  **Parallel LLM Race:** It initiates a "race" between multiple LLM
            architectures (e.g., a fast local model like Phi-4, a local MoE, and
            a cloud-based MoE) to get a high-quality action plan as quickly as
            possible.
        5.  **Fallback:** If all LLM systems fail or time out, it falls back to
            robust, motivation-driven heuristics.

        Args:
            perception: The current perception data from the perception system.
            motivation: The current motivation state object.
            goal: The current high-level goal string. Defaults to None.

        Returns:
            The string name of the action to be executed, or None if planning fails.
        """
        try:
            checkpoint_start = time.time()
            print(f"[PLANNING-CHECKPOINT] Starting _plan_action at {checkpoint_start:.3f}")
            
            game_state = perception['game_state']
            scene_type = perception['scene_type']
            current_layer = game_state.current_action_layer
            available_actions = game_state.available_actions
            
            # STATE COORDINATOR: Update from action planning subsystem
            # Action planning has its own view of state (may differ from perception/sensorimotor)
            self.state_coordinator.update(
                subsystem='action_planning',
                state={
                    'scene': scene_type.value,
                    'location': game_state.location_name,
                    'in_combat': game_state.in_combat,
                    'in_menu': scene_type in [SceneType.INVENTORY, SceneType.MAP],
                    'in_dialogue': scene_type == SceneType.DIALOGUE,
                    'health': game_state.health,
                    'layer': current_layer,
                },
                confidence=0.70  # Lower confidence - may use slightly stale state
            )
            
            # Filter out blocked actions from rule engine
            if hasattr(self, 'rule_engine'):
                original_count = len(available_actions)
                available_actions = [a for a in available_actions if not self.rule_engine.is_action_blocked(a)]
                if len(available_actions) < original_count:
                    blocked = [a for a in game_state.available_actions if self.rule_engine.is_action_blocked(a)]
                    print(f"[RULES] Filtered out {original_count - len(available_actions)} blocked actions: {', '.join(blocked)}")

            print(f"[PLANNING] Current layer: {current_layer}")
            print(f"[PLANNING] Available actions: {available_actions}")
            print(f"[PLANNING-CHECKPOINT] Game state extraction: {time.time() - checkpoint_start:.3f}s")

            # CAMERA STUCK DETECTION - Prevent "looking up" loops
            if len(self.action_history) >= 3:
                recent_3 = self.action_history[-3:]
                camera_actions = ['look_up', 'look_down', 'look_around']
                camera_count = sum(1 for a in recent_3 if any(cam in str(a).lower() for cam in camera_actions))
                
                if camera_count >= 3:
                    print(f"[PLANNING] ⚠️ CAMERA STUCK DETECTED! Breaking loop with movement")
                    self.stats['heuristic_action_count'] += 1
                    self.stats['camera_stuck_breaks'] = self.stats.get('camera_stuck_breaks', 0) + 1
                    # Force actual movement
                    import random
                    r = random.random()
                    if r < 0.4:
                        return 'step_forward'
                    elif r < 0.7:
                        return 'turn_left'
                    else:
                        return 'turn_right'
            
            # PHASE 3.2: Consult BeingState before planning
            print("\n[PLANNING] Consulting unified BeingState...")
            
            # Check sensorimotor status from BeingState
            if self.being_state.is_subsystem_fresh('sensorimotor', max_age=3.0):
                sm_status = self.being_state.sensorimotor_status
                sm_analysis = self.being_state.sensorimotor_analysis
                print(f"[PLANNING] Sensorimotor: {sm_status}")
                
                if sm_status == "STUCK":
                    print(f"[PLANNING] ⚠️ Sensorimotor reports STUCK - prioritizing unstick actions")
                    print(f"[PLANNING]    Analysis: {sm_analysis}")
                    # Override with unstick action
                    unstick_actions = ['activate', 'jump', 'turn_around', 'move_backward']
                    for action in unstick_actions:
                        if action in available_actions:
                            print(f"[PLANNING] → Using unstick action: {action}")
                            return action
            
            # Check emotion recommendations from BeingState
            if self.being_state.is_subsystem_fresh('emotion', max_age=5.0):
                emotion = self.being_state.primary_emotion
                intensity = self.being_state.emotion_intensity
                recommendations = self.being_state.emotion_recommendations
                
                print(f"[PLANNING] Emotion: {emotion} ({intensity:.2f})")
                if recommendations:
                    print(f"[PLANNING]    Recommendations: {recommendations}")
                
                if emotion == "fear" and intensity > 0.7:
                    print("[PLANNING] ⚠️ High fear - prioritizing retreat")
                    retreat_actions = ['retreat', 'move_backward', 'flee']
                    for action in retreat_actions:
                        if action in available_actions:
                            return action
            
            # Check memory for similar situations from BeingState
            if self.being_state.is_subsystem_fresh('memory', max_age=10.0):
                similar_count = len(self.being_state.memory_similar_situations)
                if similar_count > 0:
                    print(f"[PLANNING] Memory: Found {similar_count} similar situations")
                    # Use past successful actions as candidates (will be used in LLM planning)
            
            # Check consciousness conflicts from BeingState
            if self.being_state.is_subsystem_fresh('consciousness', max_age=5.0):
                conflicts = self.being_state.consciousness_conflicts
                if conflicts:
                    print(f"[PLANNING] ⚠️ Consciousness conflicts detected:")
                    for conflict in conflicts[:3]:  # Show top 3
                        print(f"[PLANNING]    - {conflict}")
            
            # Check sensorimotor state BEFORE starting expensive LLM operations
            checkpoint_sensorimotor = time.time()
            override_action = self._sensorimotor_override(available_actions, game_state)
            if override_action:
                print(f"[PLANNING-CHECKPOINT] Sensorimotor override: {time.time() - checkpoint_sensorimotor:.3f}s (action: {override_action})")
                self.stats['heuristic_action_count'] += 1
                return override_action
            print(f"[PLANNING-CHECKPOINT] Sensorimotor check: {time.time() - checkpoint_sensorimotor:.3f}s")

            # EXPERT RULE SYSTEM - Fast rule-based reasoning BEFORE expensive operations
            checkpoint_rules = time.time()
            print("\n[RULES] Evaluating expert rules...")
            
            # Prepare context for rule evaluation
            rule_context = {
                'visual_similarity': perception.get('visual_similarity', 0.0),
                'recent_actions': self.action_history[-10:] if hasattr(self, 'action_history') else [],
                'scene_classification': scene_type,
                'visual_scene_type': perception.get('scene_type'),
                'coherence_history': self.coherence_history[-10:] if hasattr(self, 'coherence_history') else [],
                'health': game_state.health,
                'in_combat': game_state.in_combat,
                'enemies_nearby': game_state.enemies_nearby,
            }
            
            # Evaluate rules
            rule_results = self.rule_engine.evaluate(rule_context)
            
            # CONTEXT-AWARE FILTERING: Remove inappropriate recommendations
            removed_count = self.rule_engine.filter_recommendations_by_context(rule_context)
            if removed_count > 0:
                # Re-fetch recommendations after filtering
                rule_results['recommendations'] = self.rule_engine.recommendations
            
            # Display rule firing results
            if rule_results['fired_rules']:
                print(f"[RULES] [OK] Fired {len(rule_results['fired_rules'])} rules: {', '.join(rule_results['fired_rules'])}")
                
                # Show facts
                if rule_results['facts']:
                    print(f"[RULES] Active facts:")
                    for fact_name, fact_data in rule_results['facts'].items():
                        print(f"  • {fact_name} (confidence: {fact_data['confidence']:.2f})")
                
                # Show recommendations
                if rule_results['recommendations']:
                    top_rec = rule_results['recommendations'][0]
                    print(f"[RULES] Top recommendation: {top_rec.action} (priority: {top_rec.priority.name}, reason: {top_rec.reason})")
                
                # Show blocked actions
                if rule_results['blocked_actions']:
                    print(f"[RULES] Blocked actions: {', '.join(rule_results['blocked_actions'])}")
                
                # Check if we have a high-priority recommendation we should use immediately
                top_recommendation = self.rule_engine.get_top_recommendation(exclude_blocked=True)
                if top_recommendation and top_recommendation.priority.value >= 3:  # HIGH or CRITICAL
                    # Use rule recommendation immediately
                    print(f"[RULES] ⚡ Using immediate recommendation: {top_recommendation.action} ({top_recommendation.reason})")
                    print(f"[PLANNING-CHECKPOINT] Rule engine: {time.time() - checkpoint_rules:.3f}s (immediate action)")
                    self.stats['heuristic_action_count'] += 1
                    return top_recommendation.action
            else:
                print(f"[RULES] No rules fired")
            
            print(f"[PLANNING-CHECKPOINT] Rule engine: {time.time() - checkpoint_rules:.3f}s")

            # EMERGENCY RULES - Check for critical situations requiring immediate override
            checkpoint_emergency = time.time()
            print("\n[EMERGENCY] Evaluating emergency rules...")
            
            # Prepare emergency context (includes sensorimotor status)
            emergency_context = {
                'visual_similarity': perception.get('visual_similarity', 0.0),
                'recent_actions': self.action_history[-10:] if hasattr(self, 'action_history') else [],
                'coherence': self.current_consciousness.coherence if self.current_consciousness else 0.5,
                'action_confidence': 0.84,  # Default from logic system
                'sensorimotor_status': perception.get('sensorimotor_status', ''),
                'cycles_since_change': getattr(self.emergency_rules, 'cycles_since_strategy_change', 0),
                'coherence_history': self.coherence_history[-10:] if hasattr(self, 'coherence_history') else [],
            }
            
            # Evaluate emergency state
            emergency_response = self.emergency_rules.evaluate_emergency_state(emergency_context)
            
            if emergency_response:
                print(f"[EMERGENCY] {emergency_response.level.name} situation detected!")
                print(f"[EMERGENCY] Reason: {emergency_response.reason}")
                
                if emergency_response.override and emergency_response.action:
                    # CRITICAL: Immediate override
                    print(f"[EMERGENCY] ⚡ OVERRIDE: Using emergency action: {emergency_response.action}")
                    print(f"[PLANNING-CHECKPOINT] Emergency override: {time.time() - checkpoint_emergency:.3f}s")
                    self.stats['heuristic_action_count'] += 1
                    self.stats['emergency_overrides'] = self.stats.get('emergency_overrides', 0) + 1
                    return emergency_response.action
                elif emergency_response.confidence_modifier < 1.0:
                    # Modify confidence for later planning
                    print(f"[EMERGENCY] Confidence modifier: {emergency_response.confidence_modifier:.2f}x")
                    emergency_context['action_confidence'] *= emergency_response.confidence_modifier
            else:
                print(f"[EMERGENCY] No emergency conditions detected")
            
            print(f"[PLANNING-CHECKPOINT] Emergency rules: {time.time() - checkpoint_emergency:.3f}s")
            
            # MOTOR CONTROL LAYER - Structured physical behavior
            checkpoint_motor = time.time()
            
            # Only run if motor layer is initialized
            if hasattr(self, 'reflex_controller') and hasattr(self, 'menu_handler'):
                print("\n[MOTOR] Evaluating motor control layer...")
                
                # Build state dict for motor layer
                motor_state = game_state.to_dict()
                motor_state['visual_similarity'] = perception.get('visual_similarity', 0.0)
                motor_state['in_menu'] = scene_type in [SceneType.INVENTORY, SceneType.MAP]
                motor_state['in_dialogue'] = scene_type == SceneType.DIALOGUE
                
                # 1. REFLEXES (highest priority - life/death)
                reflex_action = self.reflex_controller.get_reflex_action(motor_state)
                if reflex_action:
                    print(f"[MOTOR] ⚡ REFLEX OVERRIDE: {reflex_action.name}")
                    print(f"[PLANNING-CHECKPOINT] Motor reflexes: {time.time() - checkpoint_motor:.3f}s (reflex triggered)")
                    self.stats['heuristic_action_count'] += 1
                    self.stats['motor_reflex_count'] = self.stats.get('motor_reflex_count', 0) + 1
                    from singularis.controls import HighLevelAction
                    return reflex_action.name.lower().replace('_', ' ')
                
                # 2. MENU HANDLER (second priority - prevent soft-lock)
                menu_action = self.menu_handler.handle(motor_state)
                if menu_action:
                    print(f"[MOTOR] Menu handler triggered: {menu_action.name}")
                    print(f"[PLANNING-CHECKPOINT] Motor menu handler: {time.time() - checkpoint_motor:.3f}s")
                    self.stats['heuristic_action_count'] += 1
                    self.stats['motor_menu_count'] = self.stats.get('motor_menu_count', 0) + 1
                    from singularis.controls import HighLevelAction
                    return menu_action.name.lower().replace('_', ' ')
                
                # 3. CONTEXT-AWARE ACTION SELECTION (combat vs exploration)
                if motor_state.get('in_combat') or motor_state.get('enemies_nearby', 0) > 0:
                    # Combat mode - use combat controller
                    chosen_action = self.combat_controller.choose_combat_action(motor_state)
                    print(f"[MOTOR] Combat controller suggests: {chosen_action.name}")
                    print(f"[PLANNING-CHECKPOINT] Motor combat: {time.time() - checkpoint_motor:.3f}s")
                    self.stats['motor_combat_count'] = self.stats.get('motor_combat_count', 0) + 1
                    from singularis.controls import HighLevelAction
                    return chosen_action.name.lower().replace('_', ' ')
                else:
                    # Exploration mode - use navigator
                    chosen_action = self.navigator.suggest_exploration_action(
                        motor_state,
                        perception
                    )
                    print(f"[MOTOR] Navigator suggests: {chosen_action.name}")
                    print(f"[PLANNING-CHECKPOINT] Motor navigation: {time.time() - checkpoint_motor:.3f}s")
                    self.stats['motor_navigation_count'] = self.stats.get('motor_navigation_count', 0) + 1
                    # Note: We could return here for pure motor control, but let's blend with LLM for now
                    # Store as recommendation for later blending
                    self._motor_suggestion = chosen_action
                    
                    print(f"[PLANNING-CHECKPOINT] Motor control layer: {time.time() - checkpoint_motor:.3f}s")
            else:
                print("\n[MOTOR] ⚠️ Motor control layer not initialized, skipping")
                print(f"[PLANNING-CHECKPOINT] Motor control layer: {time.time() - checkpoint_motor:.3f}s (skipped)")
            
            # COHERENCE-BASED CONFIDENCE ADJUSTMENT
            # When coherence is low (<0.5), reduce confidence in actions
            checkpoint_coherence = time.time()
            current_coherence = self.current_consciousness.coherence if self.current_consciousness else 0.5
            base_confidence = emergency_context['action_confidence']
            
            from ..confidence_adjustment import adjust_confidence, should_delay_action
            
            adjusted_confidence, explanation = adjust_confidence(
                base_confidence=base_confidence,
                coherence=current_coherence,
                coherence_threshold=0.5,
                dampening_strength=0.7
            )
            
            if adjusted_confidence != base_confidence:
                print(f"\n[CONFIDENCE] {explanation}")
                emergency_context['action_confidence'] = adjusted_confidence
                
                # Check if we should delay action due to very low confidence/coherence
                should_wait, wait_reason = should_delay_action(
                    adjusted_confidence=adjusted_confidence,
                    coherence=current_coherence,
                    confidence_threshold=0.5
                )
                
                if should_wait:
                    print(f"[CONFIDENCE] ⚠️ ACTION DELAYED: {wait_reason}")
                    print(f"[CONFIDENCE] System needs more information before acting")
                    # Return a safe default action
                    return 'wait' if 'wait' in available_actions else 'look_around'
            
            print(f"[PLANNING-CHECKPOINT] Confidence adjustment: {time.time() - checkpoint_coherence:.3f}s")

            # Prepare state dict for RL
            state_dict = game_state.to_dict()
            state_dict.update({
                'scene': scene_type.value,
                'curiosity': motivation.curiosity,
                'competence': motivation.competence,
                'coherence': motivation.coherence,
                'autonomy': motivation.autonomy
            })

            # Increment meta-strategist cycle before planning
            self.meta_strategist.tick_cycle()
            
            # Check if we should force variety (prevent RL dominance)
            force_variety = self.consecutive_same_action >= 5  # Reduced from 6 to 5 for more diversity
            
            # Enhanced variety injection with environmental awareness (GPT-4o recommendation)
            # Base variety rate: 20% (was 10%)
            variety_rate = 0.20
            
            # Increase variety in specific scenarios:
            if scene_type == SceneType.OUTDOOR_WILDERNESS:
                variety_rate = 0.30  # More exploration variety outdoors
            elif scene_type == SceneType.INDOOR_DUNGEON:
                variety_rate = 0.25  # Tactical variety in dungeons
            elif game_state.health < 40:
                variety_rate = 0.35  # More creative options when low health
            
            use_rl = random.random() > variety_rate  # Dynamic RL vs heuristics ratio
            if not use_rl:
                print(f"[VARIETY] Environmental diversity injection (rate={variety_rate:.0%}) - using heuristics")
            
            if force_variety and self.consecutive_same_action >= 5:
                print(f"[VARIETY] Forcing diversity after {self.consecutive_same_action}x '{self.last_executed_action}' - skipping RL")
            
            # Always get Q-values (needed for heuristics even if skipping RL)
            checkpoint_rl_start = time.time()
            q_values = {}
            if self.rl_learner is not None:
                q_values = self.rl_learner.get_q_values(state_dict)
            print(f"[PLANNING-CHECKPOINT] Q-value computation: {time.time() - checkpoint_rl_start:.3f}s")
            
            # Initialize task variables - CRITICAL: Must initialize before any conditional branches
            cloud_task = None
            local_moe_task = None
            gemini_moe_task = None
            claude_reasoning_task = None
            huihui_task = None
            phi4_task = None
            
            # Use RL-based action selection if enabled (but not if forcing variety)
            if self.rl_learner is not None and use_rl:
                print("[PLANNING] Using RL-based action selection with LLM reasoning...")
                print(f"[PLANNING] RL reasoning neuron LLM status: {'Connected' if self.rl_reasoning_neuron.llm_interface else 'Using heuristics'}")
                
                # Track RL usage
                self.stats['rl_action_count'] += 1
                
                # Check if meta-strategist should generate new instruction (skip if no LLM)
                checkpoint_meta_start = time.time()
                if self.huihui_llm and await self.meta_strategist.should_generate_instruction():
                    try:
                        instruction = await asyncio.wait_for(
                            self.meta_strategist.generate_instruction(
                                current_state=state_dict,
                                q_values=q_values,
                                motivation=motivation.dominant_drive().value
                            ),
                            timeout=5.0
                        )
                    except (asyncio.TimeoutError, Exception) as e:
                        print(f"[META-STRATEGIST] Skipping - error: {type(e).__name__}")
                print(f"[PLANNING-CHECKPOINT] Meta-strategist check: {time.time() - checkpoint_meta_start:.3f}s")
                
                # Q-values already computed above
                print(f"[RL] Q-values: {', '.join([f'{k}={v:.2f}' for k, v in sorted(q_values.items(), key=lambda x: x[1], reverse=True)[:3]])}")
                
                # Get meta-strategic context
                meta_context = self.meta_strategist.get_active_instruction_context()
                
                # === MULTI-TIER STUCK DETECTION ===
                checkpoint_stuck_start = time.time()
                
                # Tier 1: Failsafe stuck detection (always runs, no cloud needed)
                failsafe_stuck, failsafe_reason, failsafe_recovery = self._detect_stuck_failsafe(
                    perception=perception,
                    game_state=game_state
                )
                print(f"[PLANNING-CHECKPOINT] Failsafe stuck detection: {time.time() - checkpoint_stuck_start:.3f}s")
                
                # RECOMMENDATION 1: Check Hebbian weight for sensorimotor interrupt priority
                sensorimotor_weight = self.hebbian.get_system_weight('sensorimotor_claude45')
                print(f"[HEBBIAN-CONTROL] Sensorimotor weight: {sensorimotor_weight:.3f}")
                
                if failsafe_stuck:
                    # Measure consciousness impact
                    stuck_state = await self.measure_system_consciousness()
                    print(f"[FAILSAFE-STUCK] System coherence during stuck: {stuck_state.global_coherence:.3f}")
                    
                    # RECOMMENDATION 1: Grant interrupt priority when sensorimotor weight > 1.3 AND stuck
                    if sensorimotor_weight > 1.3:
                        print(f"[HEBBIAN-CONTROL] ⚡ INTERRUPT PRIORITY: Sensorimotor weight {sensorimotor_weight:.3f} > 1.3")
                        print(f"[HEBBIAN-CONTROL] Granting control authority to sensorimotor expert")
                        
                        # Strengthen pathway on successful interrupt
                        self.hebbian.record_activation(
                            system_name='sensorimotor_claude45',
                            success=True,
                            contribution_strength=1.2,  # Extra reward for interrupt
                            context={'interrupt_priority': True, 'stuck_detected': True}
                        )
                        
                        # Use failsafe recovery action with priority
                        if failsafe_recovery in available_actions:
                            print(f"[HEBBIAN-CONTROL] Using sensorimotor-priority recovery: {failsafe_recovery}")
                            self.stats['sensorimotor_interrupts'] = self.stats.get('sensorimotor_interrupts', 0) + 1
                            self.stats['failsafe_stuck_detections'] = self.stats.get('failsafe_stuck_detections', 0) + 1
                            return failsafe_recovery
                    else:
                        # Standard stuck recovery
                        if failsafe_recovery in available_actions:
                            print(f"[FAILSAFE-STUCK] Using recovery: {failsafe_recovery}")
                            self.stats['failsafe_stuck_detections'] = self.stats.get('failsafe_stuck_detections', 0) + 1
                            return failsafe_recovery
                
                # Tier 2: Gemini vision stuck detection (every 10 cycles, cloud-based)
                checkpoint_gemini_stuck_start = time.time()
                if self.cycle_count % 10 == 0 and self.hybrid_llm:
                    print(f"[PLANNING-CHECKPOINT] Starting Gemini vision stuck detection...")
                    is_stuck, recovery_action = await self._detect_stuck_with_gemini(
                        perception=perception,
                        recent_actions=self.action_history[-10:]
                    )
                    print(f"[PLANNING-CHECKPOINT] Gemini stuck detection: {time.time() - checkpoint_gemini_stuck_start:.3f}s")
                    
                    if is_stuck and recovery_action:
                        # Measure consciousness impact of stuck state
                        stuck_state = await self.measure_system_consciousness()
                        print(f"[GEMINI-STUCK] System coherence during stuck: {stuck_state.global_coherence:.3f}")
                        
                        # Parse recovery action
                        recovery_lower = recovery_action.lower()
                        
                        # Try to extract action from recovery suggestion
                        for action in available_actions:
                            if action in recovery_lower:
                                print(f"[GEMINI-STUCK] Using recovery action: {action}")
                                self.stats['gemini_stuck_detections'] = self.stats.get('gemini_stuck_detections', 0) + 1
                                return action
                        
                        # Fallback recovery actions
                        if 'jump' in available_actions:
                            print(f"[GEMINI-STUCK] Using fallback recovery: jump")
                            self.stats['gemini_stuck_detections'] = self.stats.get('gemini_stuck_detections', 0) + 1
                            return 'jump'
                        elif 'sneak' in available_actions:
                            print(f"[GEMINI-STUCK] Using fallback recovery: sneak")
                            self.stats['gemini_stuck_detections'] = self.stats.get('gemini_stuck_detections', 0) + 1
                            return 'sneak'
                else:
                    print(f"[PLANNING-CHECKPOINT] Skipping Gemini stuck detection (cycle {self.cycle_count})")
                
                # Gemini MoE: Fast action selection with 2 Gemini Flash experts (participates in race)
                # Check rate limit BEFORE starting expensive MoE query
                checkpoint_moe_check = time.time()
                gemini_moe_task = None
                if self.moe and hasattr(self.moe, 'gemini_experts') and len(self.moe.gemini_experts) > 0:
                    # Check if Gemini is rate-limited (Fix 10: backoff strategy)
                    is_limited, wait_time = self.moe.is_gemini_rate_limited()
                    print(f"[PLANNING-CHECKPOINT] MoE rate limit check: {time.time() - checkpoint_moe_check:.3f}s")
                    
                    if is_limited:
                        if wait_time < 5.0:
                            # Wait if <5s remaining (backoff strategy)
                            print(f"[GEMINI-MOE] ⏳ Waiting {wait_time:.1f}s for rate limit...")
                            await asyncio.sleep(wait_time + 0.5)
                        elif wait_time < 10.0:
                            # Queue request for next cycle
                            print(f"[GEMINI-MOE] 📋 QUEUING - will retry next cycle ({wait_time:.1f}s remaining)")
                            self.stats['llm_queued_requests'] = self.stats.get('llm_queued_requests', 0) + 1
                            gemini_moe_task = None
                        else:
                            # Skip only if >10s
                            print(f"[GEMINI-MOE] ⚠️ SKIPPING - Gemini rate-limited ({wait_time:.1f}s)")
                            self.stats['llm_skipped_rate_limit'] = self.stats.get('llm_skipped_rate_limit', 0) + 1
                    else:
                        print(f"[GEMINI-MOE] [OK] Rate limit OK - Starting {len(self.moe.gemini_experts)} Gemini Flash experts for fast action selection...")
                        
                        # RECOMMENDATION 3: Leverage Gemini Vision for action filtering
                        # Build prompt with spatial reasoning context
                        vision_prompt = f"""Analyze this Skyrim gameplay with spatial awareness:
Scene: {perception.get('scene_type', 'unknown')}
Health: {state_dict.get('health', 100)}%
In Combat: {state_dict.get('in_combat', False)}
Enemies: {state_dict.get('enemies_nearby', 0)}

Provide detailed spatial description: obstacles, pathways, interactive elements, and scene type confirmation."""
                        
                        # RECOMMENDATION 3: Use Gemini's spatial reasoning for filtering
                        reasoning_prompt = f"""Recommend ONE action based on spatial analysis:
Available: {', '.join(available_actions)}
Top Q-values: {', '.join(f'{k}={v:.2f}' for k, v in sorted(q_values.items(), key=lambda x: x[1], reverse=True)[:3])}

Consider:
- If in menu/inventory scene, only recommend: activate, move_cursor, press_tab
- If exploring, consider spatial obstacles from vision
- If stuck, recommend activate or turn actions

Format: ACTION: <action_name>"""                        
                        
                        print("[GEMINI-VISION] Using spatial reasoning to inform action selection")
                        
                        gemini_moe_task = asyncio.create_task(
                            self.moe.query_all_experts(
                                vision_prompt=vision_prompt,
                                reasoning_prompt=reasoning_prompt,
                                image=perception.get('screenshot'),
                                context=state_dict
                            )
                        )
                
                # Claude: Deep reasoning/sensorimotor (async background, stores to memory)
                claude_reasoning_task = None
                if self.hybrid_llm and hasattr(self.hybrid_llm, 'claude'):
                    print(f"[CLAUDE-ASYNC] Starting Claude reasoning in background (non-blocking)...")
                    claude_reasoning_task = asyncio.create_task(
                        self._claude_background_reasoning(
                            perception=perception,
                            state_dict=state_dict,
                            game_state=game_state,
                            scene_type=scene_type,
                            motivation=motivation
                        )
                    )
                    # Don't await - let it run independently and store to memory
                
                # Fallback: Start Local MoE in background (4x Qwen3-VL + Phi-4)
                local_moe_task = None
                if hasattr(self, 'local_moe') and self.local_moe:
                    print("[LOCAL-MOE] Starting local MoE query in background...")
                    local_moe_task = asyncio.create_task(
                        self.local_moe.get_action_recommendation(
                            perception=perception,
                            game_state=game_state,
                            available_actions=available_actions,
                            q_values=q_values,
                            motivation=motivation.dominant_drive().value
                        )
                    )
                else:
                    print("[FALLBACK] Local MoE unavailable, using heuristics")
                
                # Also start Huihui in background for strategic reasoning (if available)
                visual_analysis = perception.get('visual_analysis', '')
                if visual_analysis:
                    print(f"[QWEN3-VL] Passing visual analysis to Huihui: {visual_analysis[:100]}...")
                
                # Only start Huihui if local LLM is available
                if self.rl_reasoning_neuron.llm_interface:
                    huihui_task = asyncio.create_task(
                        self.rl_reasoning_neuron.reason_about_q_values(
                            state=state_dict,
                            q_values=q_values,
                            available_actions=available_actions,
                            context={
                                'motivation': motivation.dominant_drive().value,
                                'terrain_type': self.skyrim_world.classify_terrain_from_scene(
                                    scene_type.value,
                                    game_state.in_combat
                                ),
                                'meta_strategy': meta_context,
                                'visual_analysis': visual_analysis
                            }
                        )
                    )
                else:
                    print("[HUIHUI-BG] Local LLM not available, skipping strategic analysis")
                
                # Compute fast heuristic immediately (no await needed)
                print("[HEURISTIC-FAST] Computing quick action for Phi-4...")
                
                # Get top 3 Q-value actions for variety
                sorted_q_actions = sorted(
                    [(a, q_values.get(a, 0.0)) for a in available_actions],
                    key=lambda x: x[1],
                    reverse=True
                )
                top_q_action = sorted_q_actions[0][0] if sorted_q_actions else 'move_forward'
                
                # Context-aware adjustment with variety
                if game_state.health < 30 and 'rest' in available_actions:
                    heuristic_action = 'rest'
                    heuristic_reason = "Low health emergency"
                elif game_state.in_combat and game_state.enemies_nearby > 2 and 'power_attack' in available_actions:
                    heuristic_action = 'power_attack'
                    heuristic_reason = "Multiple enemies"
                elif not game_state.in_combat:
                    # Add variety for exploration - don't always move_forward!
                    exploration_options = []
                    
                    # Prevent repetition - avoid last action if possible
                    if len(sorted_q_actions) >= 3:
                        # Pick from top 3 Q-values, avoid last action
                        for action, _ in sorted_q_actions[:3]:
                            if action != self.last_executed_action:
                                exploration_options.append(action)
                    
                    if exploration_options:
                        # Randomly pick from good options (not always move_forward!)
                        heuristic_action = random.choice(exploration_options)
                        heuristic_reason = f"Varied exploration (avoiding repetition)"
                    else:
                        # Fall back to top Q-value if no variety available
                        heuristic_action = top_q_action
                        heuristic_reason = "Top Q-value action"
                else:
                    heuristic_action = top_q_action
                    heuristic_reason = f"Top Q-value action"
                
                print(f"[HEURISTIC-FAST] Quick recommendation: {heuristic_action} ({heuristic_reason})")
                print(f"[HUIHUI-BG] Strategic analysis running in background...")
                
                # Store heuristic for immediate use by Phi-4
                heuristic_recommendation = heuristic_action
                heuristic_reasoning = heuristic_reason
                
                # Store background task for later (optional: could check if done)
                huihui_background_task = huihui_task

            # Get strategic analysis from world model (layer effectiveness)
            strategic_analysis = self.skyrim_world.get_strategic_layer_analysis(
                game_state.to_dict()
            )
            
            # Get terrain-aware recommendations
            terrain_recommendations = self.skyrim_world.get_terrain_recommendations(
                game_state.location_name,
                scene_type.value,
                game_state.in_combat
            )
            strategic_analysis['terrain_recommendations'] = terrain_recommendations
            
            # === SYMBOLIC LOGIC ANALYSIS ===
            print("\n[LOGIC] Querying symbolic logic system...")
            logic_analysis = self.skyrim_world.get_logic_analysis(game_state.to_dict())
            strategic_analysis['logic_analysis'] = logic_analysis
            
            # Log symbolic logic recommendations
            logic_recs = logic_analysis['recommendations']
            if any(logic_recs.values()):  # If any recommendation is True
                print(f"[LOGIC] Active recommendations:")
                if logic_recs['should_defend']:
                    print(f"  • DEFEND: Hostile NPCs in combat")
                if logic_recs['should_heal']:
                    print(f"  • HEAL: Health is critical/low")
                if logic_recs['should_retreat']:
                    print(f"  • RETREAT: Outnumbered with escape route")
                if logic_recs['should_use_magic']:
                    print(f"  • USE MAGIC: Enemy vulnerable to magic")
                if logic_recs['should_avoid_detection']:
                    print(f"  • STEALTH: In stealth mode with enemy nearby")
                print(f"[LOGIC] Logic confidence: {logic_analysis['logic_confidence']:.2f}")
                print(f"[LOGIC] Derived {logic_recs['derived_facts']} new facts via forward chaining")
            else:
                print(f"[LOGIC] No critical recommendations (confidence: {logic_analysis['logic_confidence']:.2f})")
            
            print(f"[STRATEGIC] Layer effectiveness: {strategic_analysis['layer_effectiveness']}")
            if strategic_analysis['recommendations']:
                print(f"[STRATEGIC] Recommendations: {strategic_analysis['recommendations']}")

            # Meta-strategic reasoning: Should we switch layers?
            optimal_layer = None
            
            print(f"[META-STRATEGY] Evaluating layer switches (current: {current_layer})")
            
            # Combat situations - prioritize Combat layer if effective
            # Only engage if BOTH scene=combat AND (in_combat OR enemies detected)
            # This prevents false positives from "weapons drawn" stance
            in_actual_combat = (
                scene_type == SceneType.COMBAT and 
                (game_state.in_combat or game_state.enemies_nearby > 0)
            )
            
            if in_actual_combat:
                print(f"[META-STRATEGY] Active combat! Scene: {scene_type.value}, in_combat: {game_state.in_combat}, enemies: {game_state.enemies_nearby}")
                
                # Switch to Combat layer
                if current_layer != "Combat":
                    combat_effectiveness = strategic_analysis['layer_effectiveness'].get('Combat', 0.5)
                    if combat_effectiveness > 0.6:
                        optimal_layer = "Combat"
                        print(f"[META-STRATEGY] Switching to Combat layer (effectiveness: {combat_effectiveness:.2f})")
                
                # Choose combat action based on context
                if game_state.enemies_nearby > 2:
                    action = 'power_attack' if 'power_attack' in available_actions else 'attack'
                    if action in available_actions:
                        print(f"[META-STRATEGY] → {action} (multiple enemies)")
                        return action
                elif game_state.health < 50:
                    action = 'block' if 'block' in available_actions else 'attack'
                    if action in available_actions:
                        print(f"[META-STRATEGY] → {action} (defensive)")
                        return action
                elif 'attack' in available_actions:
                    print(f"[META-STRATEGY] → attack (engage enemy)")
                    return 'attack'
                # If no combat actions available, fall through
            elif scene_type == SceneType.COMBAT and not in_actual_combat:
                # Combat scene detected but no active combat - probably post-combat or stuck in stance
                print(f"[META-STRATEGY] Combat scene but no active combat (post-combat or stuck stance)")
                # Try to exit combat stance by exploring
                if 'sneak' in available_actions:
                    print(f"[META-STRATEGY] → sneak (exit combat stance)")
                    return 'sneak'

            # Low health - consider Menu layer for healing
            if game_state.health < 30:
                if current_layer != "Menu":
                    menu_effectiveness = strategic_analysis['layer_effectiveness'].get('Menu', 0.5)
                    if menu_effectiveness > 0.5:
                        optimal_layer = "Menu"
                        print(f"[META-STRATEGY] Switching to Menu layer for healing (health: {game_state.health:.0f})")
            
                if 'consume_item' in available_actions:
                    print(f"[META-STRATEGY] → Action: consume_item (critical health: {game_state.health:.0f})")
                    return 'consume_item'
                else:
                    print(f"[META-STRATEGY] → Action: rest (health recovery needed)")
                    return 'rest'

            # Stealth opportunities
            if (not game_state.in_combat and 
                len(game_state.nearby_npcs) > 0 and 
                motivation.dominant_drive().value == 'competence'):
                stealth_effectiveness = strategic_analysis['layer_effectiveness'].get('Stealth', 0.5)
                if stealth_effectiveness > 0.6 and current_layer != "Stealth":
                    optimal_layer = "Stealth"
                    print(f"[META-STRATEGY] Switching to Stealth layer (effectiveness: {stealth_effectiveness:.2f}, {len(game_state.nearby_npcs)} NPCs nearby)")

            # If we determined an optimal layer, suggest layer transition
            if optimal_layer and optimal_layer != current_layer:
                # Return a meta-action that will trigger layer switch
                print(f"[META-STRATEGY] → Action: switch_to_{optimal_layer.lower()}")
                return f'switch_to_{optimal_layer.lower()}'
            elif optimal_layer:
                print(f"[META-STRATEGY] Already in optimal layer: {current_layer}")

            # Check if cloud LLM finished while we were planning
            if cloud_task and cloud_task.done():
                try:
                    cloud_recommendation = cloud_task.result()
                    if cloud_recommendation:
                        action, reasoning = cloud_recommendation
                        print(f"[CLOUD-LLM] [OK] Cloud finished first! Using: {action}")
                        print(f"[CLOUD-LLM] Reasoning: {reasoning[:200]}...")
                        return action
                except Exception as e:
                    print(f"[CLOUD-LLM] Cloud task failed: {e}")
            
            # Always use Phi-4 for final action selection (fast, decisive)
            if self.action_planning_llm:
                print("[PLANNING] Using Phi-4 for final action selection...")
                try:
                    # Pass only fast heuristic to Phi-4 (Huihui still thinking in background)
                    huihui_context = None
                    if 'heuristic_recommendation' in locals():
                        huihui_context = {
                            'heuristic_recommendation': heuristic_recommendation,
                            'heuristic_reasoning': heuristic_reasoning,
                            'huihui_status': 'background' if 'huihui_background_task' in locals() else 'not_started'
                        }
                    
                    # Start Phi-4 task
                    phi4_task = asyncio.create_task(
                        self._plan_action_with_llm(
                            perception, game_state, scene_type, current_layer, available_actions, 
                            strategic_analysis, motivation, huihui_context
                        )
                    )
                    
                    # Race: Phi-4 vs Gemini MoE vs Local MoE (whichever finishes first)
                    # Timeout after 10 seconds - use fastest response for smooth gameplay
                    tasks_to_race = [phi4_task]
                    if gemini_moe_task:
                        tasks_to_race.append(gemini_moe_task)
                    if local_moe_task:
                        tasks_to_race.append(local_moe_task)
                    
                    if len(tasks_to_race) > 1:
                        # Scene-based timeout: combat 15s, exploration 30s, menus 45s (Fix 14)
                        timeout_duration = 15.0 if game_state.in_combat else 45.0 if scene_type in [SceneType.INVENTORY, SceneType.MAP, SceneType.DIALOGUE] else 30.0
                        
                        # Progressive timeout: extend by 5s if systems near completion (Fix 15)
                        if self.cycle_count < 3:
                            timeout_duration = 60.0  # LLM warmup phase (Fix 18)
                        
                        print(f"[PARALLEL] Racing {len(tasks_to_race)} systems ({timeout_duration}s timeout)...")
                        try:
                            done, pending = await asyncio.wait(
                                tasks_to_race,
                                timeout=timeout_duration,
                                return_when=asyncio.FIRST_COMPLETED
                            )
                            
                            # Check which one finished first
                            for task in done:
                                if task == gemini_moe_task:
                                    try:
                                        vision_resp, reasoning_resp = task.result()
                                        if reasoning_resp and reasoning_resp.consensus:
                                            # Parse action from consensus
                                            consensus_text = reasoning_resp.consensus
                                            action = None
                                            if "ACTION:" in consensus_text:
                                                action_line = [l for l in consensus_text.split('\n') if 'ACTION:' in l][0]
                                                action = action_line.split('ACTION:')[1].strip().lower()
                                            
                                            # LLM decision logging (Fix 12)
                                            confidence = reasoning_resp.confidence if hasattr(reasoning_resp, 'confidence') else 0.5
                                            print(f"[LLM-DECISION-LOG] MoE | Action: {action} | Confidence: {confidence:.2f} | Valid: {action in available_actions if action else False}")
                                            
                                            # Lowered confidence threshold from 0.7 to 0.5 (Fix 13)
                                            if action and action in available_actions and confidence >= 0.5:
                                                print(f"[GEMINI-MOE] [OK] Won the race! {len(self.moe.gemini_experts)} experts chose: {action} (conf: {confidence:.2f})")
                                                
                                                # Track action source
                                                self.stats['action_source_moe'] += 1
                                                self.last_action_source = 'moe'
                                                
                                                # Hebbian: Record successful Gemini MoE activation
                                                self.hebbian.record_activation(
                                                    system_name='gemini_moe',
                                                    success=True,
                                                    contribution_strength=1.0,
                                                    context={'action': action, 'won_race': True, 'experts': len(self.moe.gemini_experts)}
                                                )
                                                
                                                # Cancel other tasks (but NOT Claude - let it finish in background)
                                                for t in pending:
                                                    if t != claude_reasoning_task:
                                                        t.cancel()
                                                return action
                                    except Exception as e:
                                        print(f"[GEMINI-MOE] ⚠️ Error parsing result: {e}")
                                    
                                    # Hebbian: Record failure
                                    self.hebbian.record_activation(
                                        system_name='gemini_moe',
                                        success=False,
                                        contribution_strength=0.5
                                    )
                                elif task == local_moe_task:
                                    moe_recommendation = task.result()
                                    if moe_recommendation:
                                        action, reasoning = moe_recommendation
                                        print(f"[LOCAL-MOE] [OK] Won the race! Using: {action}")
                                        self.local_moe_failures = 0  # Reset on success
                                        
                                        # Track action source
                                        self.stats['action_source_local_moe'] += 1
                                        self.last_action_source = 'local_moe'
                                        
                                        # Hebbian: Record successful local MoE activation
                                        self.hebbian.record_activation(
                                            system_name='local_moe',
                                            success=True,
                                            contribution_strength=0.9,  # Slightly lower than cloud
                                            context={'action': action, 'won_race': True}
                                        )
                                        
                                        # Cancel other tasks
                                        for t in pending:
                                            t.cancel()
                                        return action
                                    else:
                                        self.local_moe_failures += 1
                                        print(f"[LOCAL-MOE] ⚠️ Returned None (failures: {self.local_moe_failures}/{self.max_consecutive_failures})")
                                        # Hebbian: Record failure
                                        self.hebbian.record_activation(
                                            system_name='local_moe',
                                            success=False,
                                            contribution_strength=0.5
                                        )
                                elif task == phi4_task:
                                    llm_action = task.result()
                                    if llm_action:
                                        print(f"[PHI4] [OK] Won the race! Using: {llm_action}")
                                        self.stats['llm_action_count'] += 1
                                        
                                        # Track action source
                                        self.stats['action_source_phi4'] += 1
                                        self.last_action_source = 'phi4'
                                        
                                        # Hebbian: Record successful Phi-4 activation
                                        self.hebbian.record_activation(
                                            system_name='phi4_planner',
                                            success=True,
                                            contribution_strength=0.8,
                                            context={'action': llm_action, 'won_race': True}
                                        )
                                        
                                        # Cancel other tasks
                                        for t in pending:
                                            t.cancel()
                                        return llm_action
                            
                            # Timeout - cancel pending tasks and use heuristic
                            if pending:
                                print(f"[PARALLEL] [RATE] Timeout after 13.5s, using heuristic (cancelled {len(pending)} pending tasks)")
                                self.stats['action_source_timeout'] += 1
                                self.last_action_source = 'timeout'
                                for task in pending:
                                    task.cancel()
                        except asyncio.TimeoutError:
                            print(f"[PARALLEL] [RATE] Timeout after 13.5s, using heuristic")
                            self.stats['action_source_timeout'] += 1
                            self.last_action_source = 'timeout'
                            for task in tasks_to_race:
                                task.cancel()
                    else:
                        # No cloud task, just wait for Phi-4
                        llm_action = await phi4_task
                        if llm_action:
                            print(f"[PHI4] Final action: {llm_action}")
                            self.stats['llm_action_count'] += 1
                            self.stats['action_source_phi4'] += 1
                            self.last_action_source = 'phi4'
                            return llm_action
                        else:
                            print("[PHI4] Phi-4 returned None, falling back to heuristics")
                except Exception as e:
                    print(f"[PHI4] Planning failed: {e}, using heuristics")
                    import traceback
                    traceback.print_exc()
            else:
                print("[PLANNING] Phi-4 not available, using heuristic planning...")
            
            # Track heuristic usage
            self.stats['heuristic_action_count'] += 1
            self.stats['action_source_heuristic'] += 1
            self.last_action_source = 'heuristic'
            
            # Check for stuck condition - all systems failing
            if (self.cloud_llm_failures >= self.max_consecutive_failures and 
                self.local_moe_failures >= self.max_consecutive_failures):
                print(f"[STUCK-DETECTION] ⚠️⚠️⚠️ ALL LLM SYSTEMS FAILING!")
                print(f"[STUCK-DETECTION] Cloud: {self.cloud_llm_failures}, Local MoE: {self.local_moe_failures}")
                print(f"[STUCK-DETECTION] Forcing random exploration action")
                # Force a random action to break the loop
                recovery_actions = ['move_forward', 'jump', 'look_around', 'activate']
                recovery_action = random.choice([a for a in recovery_actions if a in available_actions] or available_actions)
                # Reset counters
                self.cloud_llm_failures = 0
                self.local_moe_failures = 0
                self.heuristic_failures = 0
                return recovery_action

            # Fallback: Action selection within current layer based on motivation
            # More intelligent heuristics with scene awareness
            dominant_drive = motivation.dominant_drive().value
            
            print(f"[HEURISTIC] Fallback planning (drive: {dominant_drive}, scene: {scene_type.value}, health: {game_state.health:.0f})")
            
            # Consider scene type for better context-aware decisions
            if scene_type == SceneType.COMBAT or game_state.in_combat:
                # In combat, prioritize survival
                if game_state.health < 40 and 'block' in available_actions:
                    print(f"[HEURISTIC] → block (defensive, low health)")
                    return 'block'  # Defensive when low health
                elif game_state.enemies_nearby > 2:
                    if 'power_attack' in available_actions:
                        print(f"[HEURISTIC] → power_attack (multiple enemies: {game_state.enemies_nearby})")
                        return 'power_attack'
                    elif 'attack' in available_actions:
                        print(f"[HEURISTIC] → attack (multiple enemies: {game_state.enemies_nearby})")
                        return 'attack'
                elif 'attack' in available_actions:
                    print(f"[HEURISTIC] → attack (standard engagement)")
                    return 'attack'
                # If no combat actions available, fall through to exploration
            
            # Scene-specific actions
            if scene_type in [SceneType.INDOOR_BUILDING, SceneType.INDOOR_DUNGEON]:
                # Indoor: prioritize interaction and careful exploration
                if 'activate' in available_actions and dominant_drive == 'curiosity':
                    print(f"[HEURISTIC] → activate (indoor curiosity)")
                    return 'activate'
                print(f"[HEURISTIC] → navigate (careful indoor movement)")
                return 'navigate'  # Careful indoor movement
            
            # STUCK DETECTION: Use deterministic recovery actions
            stuck_status = self._detect_stuck()
            
            if stuck_status['is_stuck']:
                # Use the recommended recovery action directly
                if stuck_status['recovery_action'] and stuck_status['recovery_action'] in available_actions:
                    print(f"[STUCK-{stuck_status['severity'].upper()}] {stuck_status['reason']} → {stuck_status['recovery_action']}")
                    self.consecutive_same_action = 0  # Reset counter
                    
                    # STUCK TRACKER: Record recovery attempt
                    if 'tracker_detection' in stuck_status and len(self.visual_embedding_history) > 0:
                        import numpy as np
                        visual_before = np.array(self.visual_embedding_history[-1])
                        self.stuck_tracker.attempt_recovery(
                            detection=stuck_status['tracker_detection'],
                            recovery_action=stuck_status['recovery_action'],
                            visual_before=visual_before
                        )
                    
                    return stuck_status['recovery_action']
                
                # Fallback if recommended action not available
                print(f"[STUCK] Detected stuck state! Forcing recovery action...")
                recovery_actions = []
                if 'jump' in available_actions:
                    recovery_actions.append('jump')
                if game_state.health > 50:  # Only try risky moves if healthy
                    recovery_actions.extend(['turn_left', 'turn_right', 'move_backward'])
                
                if recovery_actions:
                    recovery = random.choice(recovery_actions)
                    print(f"[STUCK] → {recovery} (unstuck maneuver)")
                    self.consecutive_same_action = 0  # Reset counter
                    return recovery
            
            # Add variety to avoid repetitive behavior - humans don't just explore
            # Prioritize NPC interaction in non-combat scenes (increased from 15% to 60%)
            if 'activate' in available_actions:
                activation_chance = 0.60 if not game_state.in_combat else 0.15
                if random.random() < activation_chance:
                    print(f"[HEURISTIC] → activate ({'NPC interaction prioritized' if not game_state.in_combat else 'random curiosity'})")
                    return 'activate'
            
            # Occasionally look around (human-like awareness)
            if random.random() < 0.10:
                print(f"[HEURISTIC] → look_around (situational awareness)")
                return 'look_around'
            
            # Occasionally jump (human-like playfulness/testing)
            if random.random() < 0.08 and 'jump' in available_actions:
                print(f"[HEURISTIC] → jump (playful exploration)")
                return 'jump'
            
            # Use RL Q-values intelligently for action selection
            # Get top 5 actions by Q-value
            sorted_q_actions = sorted(
                [(a, q_values.get(a, 0.0)) for a in available_actions],
                key=lambda x: x[1],
                reverse=True
            )[:5]
            
            # QUANTUM SUPERPOSITION: Apply 4D fractal variance to Q-values
            # This adds 0.01-0.09% deterministic exploration variance
            if hasattr(self, 'quantum_explorer') and len(sorted_q_actions) > 0:
                action_names = [a for a, _ in sorted_q_actions]
                q_value_array = np.array([q for _, q in sorted_q_actions])
                
                # Check if stuck - use quantum tunneling for escape
                stuck_status = self._detect_stuck()
                if stuck_status['is_stuck']:
                    tunnel_prob = self.quantum_explorer.quantum_tunnel(stuck_status['severity'])
                    if random.random() < tunnel_prob:
                        print(f"[QUANTUM-TUNNEL] Severity: {stuck_status['severity']} | Prob: {tunnel_prob:.3f}")
                        # Use quantum exploration vector instead of Q-values
                        exploration_vector = self.quantum_explorer.get_exploration_vector()
                        # Map 4D exploration to available actions
                        quantum_action_idx = int(exploration_vector[0] * len(action_names))
                        quantum_action = action_names[quantum_action_idx]
                        print(f"[QUANTUM-TUNNEL] → {quantum_action} (4D fractal escape)")
                        return quantum_action
                
                # Normal quantum superposition collapse
                quantum_action, confidence = self.quantum_explorer.collapse_superposition(
                    action_weights=q_value_array,
                    action_names=action_names,
                    temperature=1.0  # Higher = more exploration
                )
                
                fractal_stats = self.quantum_explorer.get_fractal_stats()
                print(f"[QUANTUM] Collapsed superposition → {quantum_action} (conf: {confidence:.3f}, fib: {fractal_stats['fibonacci_phase']}, depth: {fractal_stats['iteration_depth']})")
                
                # Use quantum action with high confidence, otherwise continue to motivation-based
                if confidence > 0.15:  # Threshold for quantum decision
                    return quantum_action
            
            # Motivation-based selection with Q-value guidance
            if dominant_drive == 'curiosity':
                # Curiosity: prioritize interaction and exploration variety
                if 'activate' in available_actions and random.random() < 0.4:
                    print(f"[HEURISTIC] → activate (curiosity-driven interaction)")
                    return 'activate'
                # Pick from top 3 Q-value actions for variety
                if len(sorted_q_actions) >= 3:
                    action = random.choice([a for a, _ in sorted_q_actions[:3]])
                    print(f"[HEURISTIC] → {action} (curiosity + Q-value)")
                    return action
                print(f"[HEURISTIC] → explore (curiosity/default)")
                return 'explore'
                
            elif dominant_drive == 'competence':
                # Competence: practice skills
                if 'power_attack' in available_actions and current_layer == "Combat":
                    print(f"[HEURISTIC] → power_attack (competence training)")
                    return 'power_attack'
                elif 'backstab' in available_actions and current_layer == "Stealth":
                    print(f"[HEURISTIC] → backstab (stealth practice)")
                    return 'backstab'
                # Pick from top Q-values
                if sorted_q_actions:
                    action = sorted_q_actions[0][0]
                    print(f"[HEURISTIC] → {action} (competence + top Q-value)")
                    return action
                print(f"[HEURISTIC] → explore (competence/default)")
                return 'explore'
                
            elif dominant_drive == 'coherence':
                # Coherence: prefer gentle, varied actions
                if game_state.health < 30 and 'rest' in available_actions:
                    print(f"[HEURISTIC] → rest (coherence restoration)")
                    return 'rest'
                # Pick varied actions from top Q-values (avoid always same)
                if len(sorted_q_actions) >= 4:
                    # Pick from top 4, but avoid last action
                    options = [a for a, _ in sorted_q_actions[:4] if a != self.last_executed_action]
                    if options:
                        action = random.choice(options)
                        print(f"[HEURISTIC] → {action} (coherence + varied Q-value)")
                        return action
                # Fall back to exploration
                print(f"[HEURISTIC] → explore (coherence/default)")
                return 'explore'
                
            else:  # autonomy or default
                # Autonomy: prefer varied, independent choices
                if random.random() < 0.3 and 'activate' in available_actions:
                    print(f"[HEURISTIC] → activate (autonomous interaction)")
                    return 'activate'
                # Pick from top Q-values with variety
                if len(sorted_q_actions) >= 3:
                    # Weighted random from top 3 (not just first)
                    weights = [3, 2, 1][:len(sorted_q_actions[:3])]
                    action = random.choices(
                        [a for a, _ in sorted_q_actions[:3]],
                        weights=weights
                    )[0]
                    print(f"[HEURISTIC] → {action} (autonomy + weighted Q-value)")
                    return action
                print(f"[HEURISTIC] → explore (autonomy/default)")
                return 'explore'

        except Exception as e:
            print(f"[_plan_action] ERROR: {e}")
            import traceback
            traceback.print_exc()
            return None

    async def _plan_action_with_llm(
        self,
        perception: Dict[str, Any],
        game_state,
        scene_type,
        current_layer: str,
        available_actions: list,
        strategic_analysis: dict,
        motivation,
        huihui_context: Optional[Dict[str, str]] = None
    ) -> Optional[str]:
        """Uses a fast, local LLM (like Phi-4) for final action selection.

        This method is a key part of the parallel LLM race in `_plan_action`.
        It constructs a compact, context-rich prompt and queries a fast, decisive
        LLM (configured as `action_planning_llm`). The prompt includes essential
        state information, available actions, and optionally, recommendations from
        other reasoning systems (like heuristics or the slower Huihui model).

        Args:
            perception: The current perception data dictionary.
            game_state: The current game state object.
            scene_type: The current scene type enum.
            current_layer: The active action layer (e.g., 'Combat').
            available_actions: A list of valid action strings.
            strategic_analysis: A dictionary of strategic insights.
            motivation: The current motivation state object.
            huihui_context: An optional dictionary containing recommendations from a
                slower, deeper reasoning model running in the background.

        Returns:
            A string representing the chosen action if the LLM call is successful
            and a valid action can be parsed, otherwise None.
        """
        # Use dedicated action planning LLM if available, otherwise fallback to main
        llm_interface = self.action_planning_llm if self.action_planning_llm else (
            self.agi.consciousness_llm.llm_interface if hasattr(self.agi, 'consciousness_llm') 
            and self.agi.consciousness_llm and hasattr(self.agi.consciousness_llm, 'llm_interface') 
            else None
        )
        
        if not llm_interface:
            return None
        
        # Build compact context for fast mistral-nemo reasoning
        recommendations_section = ""
        if huihui_context:
            huihui_status = huihui_context.get('huihui_status', 'unknown')
            recommendations_section = f"""
FAST HEURISTIC ANALYSIS:
Recommended: {huihui_context.get('heuristic_recommendation', 'N/A')}
Reasoning: {huihui_context.get('heuristic_reasoning', 'N/A')}
(Huihui strategic analysis: {huihui_status})
"""
        
        context = f"""SKYRIM AGENT - QUICK ACTION DECISION

STATE: HP={game_state.health:.0f} MP={game_state.magicka:.0f} ST={game_state.stamina:.0f}
SCENE: {scene_type.value} | COMBAT: {game_state.in_combat} | LAYER: {current_layer}
LOCATION: {game_state.location_name}
DRIVE: {motivation.dominant_drive().value}

ACTIONS: {', '.join(available_actions[:8])}{recommendations_section}

TERRAIN STRATEGY:
- Indoor/Menu: interact, navigate exits
- Outdoor: explore forward, scan horizon  
- Combat: use terrain, power_attack if strong, block if weak
- Low HP: rest or switch_to_menu for healing

QUICK DECISION - Choose ONE action from available list:"""

        try:
            print("[MISTRAL-ACTION] Fast action planning with mistral-nemo...")
            
            # Use dedicated LLM interface directly for faster response
            if self.action_planning_llm:
                result = await asyncio.wait_for(
                    self.action_planning_llm.generate(
                        prompt=context,
                        max_tokens=300  # Enough for reasoning + action selection
                    ),
                    timeout=60.0  # 60 second timeout for local LLM
                )
                # Debug: Check what we got back
                print(f"[MISTRAL-ACTION] DEBUG - Result type: {type(result)}")
                print(f"[MISTRAL-ACTION] DEBUG - Result keys: {result.keys() if isinstance(result, dict) else 'N/A'}")
                
                # LMStudioClient.generate() returns a dict with 'content' key (not 'response')
                response = result.get('content', result.get('response', '')) if isinstance(result, dict) else str(result)
            else:
                # Fallback to base AGI consciousness LLM
                result = await self.agi.process(context)
                response = result.get('consciousness_response', {}).get('response', '')
            
            print(f"[MISTRAL-ACTION] Response ({len(response)} chars): {response[:200] if len(response) > 200 else response}")
        except asyncio.TimeoutError:
            print(f"[MISTRAL-ACTION] Timed out after 60s - using fallback heuristic")
            return None
        except Exception as e:
            print(f"[MISTRAL-ACTION] ERROR during LLM action planning: {e}")
            import traceback
            traceback.print_exc()
            return None

        # Parse LLM response for action with improved extraction
        response_lower = response.lower().strip()
        
        # Try to extract action using multiple strategies
        
        # Strategy 1: Check for layer transition actions ONLY if they're in available_actions
        layer_transitions = {
            'switch_to_combat': ['switch_to_combat', 'switch to combat', 'combat layer'],
            'switch_to_menu': ['switch_to_menu', 'switch to menu', 'menu layer', 'open inventory'],
            'switch_to_stealth': ['switch_to_stealth', 'switch to stealth', 'stealth layer', 'sneak mode'],
            'switch_to_exploration': ['switch_to_exploration', 'switch to exploration', 'exploration layer']
        }
        
        for action, patterns in layer_transitions.items():
            # Only extract layer transitions if they're actually available
            if action in available_actions and any(pattern in response_lower for pattern in patterns):
                return action
        
        # Strategy 2: Look for exact matches with available actions
        for action in available_actions:
            # Check for exact word match (word boundaries)
            action_lower = action.lower()
            if f' {action_lower} ' in f' {response_lower} ' or response_lower.startswith(action_lower) or response_lower.endswith(action_lower):
                return action
        
        # Strategy 3: Check for partial matches with available actions
        for action in available_actions:
            if action.lower() in response_lower:
                return action
        
        # Strategy 4: Map common LLM responses to standard actions
        action_mappings = {
            'combat': ['fight', 'attack', 'battle', 'engage enemy', 'power attack', 'strike'],
            'explore': ['wander', 'search', 'look around', 'investigate', 'move forward', 'go ahead'],
            'interact': ['use', 'activate', 'open', 'talk', 'speak', 'examine'],
            'stealth': ['sneak', 'hide', 'crouch', 'stay quiet'],
            'rest': ['wait', 'sleep', 'heal', 'recover', 'take a break'],
            'navigate': ['walk', 'move', 'go', 'travel', 'head to']
        }
        
        for standard_action, synonyms in action_mappings.items():
            if any(synonym in response_lower for synonym in synonyms):
                # Only return if it makes sense in context
                if standard_action in available_actions or standard_action in ['combat', 'explore', 'interact', 'rest', 'navigate']:
                    return standard_action
        
        # Strategy 5: Extract quoted action if present
        import re
        quoted_match = re.search(r'["\']([^"\']+)["\']', response)
        if quoted_match:
            quoted_action = quoted_match.group(1).lower()
            if quoted_action in available_actions:
                return quoted_action
            # Check if quoted action is a standard action
            for standard_action in ['combat', 'explore', 'interact', 'stealth', 'rest', 'navigate']:
                if standard_action in quoted_action:
                    return standard_action
        
        # No match found

    def _sensorimotor_override(self, available_actions: List[str], game_state) -> Optional[str]:
        """Checks for and acts on a sensorimotor override condition.

        This function consults the `sensorimotor_state` to see if a high-priority
        override has been flagged (e.g., due to being visually stuck or in a
        dialogue loop). If an override is active, it selects an appropriate
        recovery action from a prioritized list and returns it, effectively
        bypassing the normal planning process.

        Args:
            available_actions: A list of currently valid action strings.
            game_state: The current game state object.

        Returns:
            The string name of a recovery action if an override is triggered,
            otherwise None.
        """
        feedback = self.sensorimotor_state
        if not feedback:
            return None

        feedback_cycle = feedback.get('cycle', -1)
        if feedback_cycle == -1 or self.cycle_count - feedback_cycle > 6:
            return None  # Feedback too old to trust

        if not feedback.get('should_override'):
            return None

        reason = feedback.get('reason', 'sensorimotor_stuck')
        similarity = feedback.get('visual_similarity')
        streak = feedback.get('similarity_streak', 0)
        dialogue_loop = feedback.get('dialogue_loop', False)
        print(f"[PLANNING] Sensorimotor override engaged (reason: {reason}, similarity={similarity}, streak={streak})")

        recovery_priority = []
        
        # Special handling for dialogue loops - prioritize exiting dialogue
        if dialogue_loop or reason == 'dialogue_loop':
            print("[PLANNING] → Dialogue loop detected! Attempting to exit dialogue...")
            # Try to exit dialogue with back button (Tab/ESC equivalent) and wait
            if 'back' in available_actions:
                recovery_priority.append('back')
            if 'wait' in available_actions:
                recovery_priority.append('wait')
            # Move away from NPC
            recovery_priority.extend(['move_backward', 'turn_left', 'turn_right'])
        else:
            # Normal stuck detection - try to move/interact
            if not game_state.in_menu and 'activate' in available_actions:
                recovery_priority.append('activate')
            if 'jump' in available_actions:
                recovery_priority.append('jump')
            if 'turn_left' in available_actions:
                recovery_priority.append('turn_left')
            if 'turn_right' in available_actions:
                recovery_priority.append('turn_right')
            if 'move_backward' in available_actions:
                recovery_priority.append('move_backward')
            if 'look_around' in available_actions:
                recovery_priority.append('look_around')
            if 'sneak' in available_actions:
                recovery_priority.append('sneak')

        for candidate in recovery_priority:
            if candidate != self.last_executed_action:
                print(f"[PLANNING] → Sensorimotor recovery action: {candidate}")
                feedback['should_override'] = False
                feedback['last_override_cycle'] = self.cycle_count
                feedback['last_forced_action'] = candidate
                return candidate

        if available_actions:
            fallback_pool = [a for a in available_actions if a != self.last_executed_action]
            fallback = random.choice(fallback_pool or available_actions)
            print(f"[PLANNING] → Sensorimotor fallback action: {fallback}")
            feedback['should_override'] = False
            feedback['last_override_cycle'] = self.cycle_count
            feedback['last_forced_action'] = fallback
            return fallback

        return None

    def _update_sensorimotor_state(
        self,
        cycle: int,
        similarity: Optional[float],
        analysis: str,
        has_thinking: bool,
        visual_context: str
    ) -> None:
        """Updates and persists the sensorimotor feedback state.

        This method is called after a sensorimotor reasoning cycle. It updates
        the internal `sensorimotor_state` with the latest analysis, visual
        similarity, and stuck detection heuristics. It determines whether the
        conditions are met to flag an override for the next planning cycle.

        Args:
            cycle: The current main loop cycle number.
            similarity: The visual similarity score compared to the previous frame.
            analysis: The textual analysis from the sensorimotor reasoning LLM.
            has_thinking: A boolean indicating if extended "thinking" was part
                of the analysis.
            visual_context: The combined visual analysis from various vision models.
        """
        if self.sensorimotor_last_cycle != -1 and cycle - self.sensorimotor_last_cycle > 6:
            self.sensorimotor_similarity_streak = 0

        self.sensorimotor_last_cycle = cycle

        high_similarity = similarity is not None and similarity >= self.sensorimotor_high_similarity_threshold
        if high_similarity:
            self.sensorimotor_similarity_streak += 1
        else:
            self.sensorimotor_similarity_streak = 0

        combined_text = f"{analysis}\n{visual_context}".lower()
        stuck_keywords = any(keyword in combined_text for keyword in ("stuck", "no movement", "blocked"))
        
        # Check for dialogue loop (high similarity + in_dialogue state)
        current_perception = self.perception.perception_history[-1] if self.perception.perception_history else {}
        in_dialogue = current_perception.get('game_state', {}).get('in_dialogue', False) if isinstance(current_perception.get('game_state'), dict) else False
        dialogue_loop = in_dialogue and high_similarity and self.sensorimotor_similarity_streak >= 3
        
        should_override = stuck_keywords or dialogue_loop or (
            high_similarity and self.sensorimotor_similarity_streak >= self.sensorimotor_required_streak
        )

        reason = "analysis_stuck" if stuck_keywords else (
            "dialogue_loop" if dialogue_loop else (
                "similarity_loop" if high_similarity else ""
            )
        )

        self.sensorimotor_state = {
            'cycle': cycle,
            'visual_similarity': similarity,
            'similarity_streak': self.sensorimotor_similarity_streak,
            'analysis': analysis,
            'visual_context': visual_context,
            'has_thinking': has_thinking,
            'stuck_keywords': stuck_keywords,
            'high_similarity': high_similarity,
            'dialogue_loop': dialogue_loop,
            'should_override': should_override,
            'reason': reason,
            'timestamp': time.time(),
        }

    def _evaluate_action_success(
        self,
        before_state: Dict[str, Any],
        after_state: Dict[str, Any],
        action: str
    ) -> bool:
        """Evaluates whether an action was successful based on state changes.

        This method uses simple heuristics to determine the success of an action.
        Success is generally defined by the absence of negative outcomes (like a
        significant health decrease) or the presence of positive ones (like a
        change in scene, indicating progress).

        Args:
            before_state: A dictionary representing the game state before the
                action was taken.
            after_state: A dictionary representing the game state after the
                action was taken.
            action: The string name of the action that was performed.

        Returns:
            True if the action is considered successful, False otherwise.
        """
        # Simple heuristics for success
        # Success if health didn't decrease significantly
        health_before = before_state.get('health', 100)
        health_after = after_state.get('health', 100)
        
        if health_after < health_before - 20:
            return False  # Took significant damage
        
        # Success if we're not stuck (scene changed or position changed)
        scene_before = before_state.get('scene', '')
        scene_after = after_state.get('scene', '')
        
        if scene_before != scene_after:
            return True  # Scene changed - progress made
        
        # Default to success if no obvious failure
        return True

    async def _test_controller_connection(self):
        """Tests the virtual controller connection and basic functionality.

        Before starting the main gameplay loop, this method verifies that the
        virtual controller is initialized correctly. If not in dry-run mode, it
        also performs a small, quick action (like a slight camera movement) to
        ensure that the action execution pipeline is working.
        """
        try:
            print("[CONTROLLER] Testing controller connection...")
            
            if self.controller and hasattr(self.controller, 'active_layer'):
                print(f"[CONTROLLER] Active layer: {self.controller.active_layer}")
                print("[CONTROLLER] [OK] Controller connection OK")
            else:
                print("[CONTROLLER] ⚠️ Controller not properly initialized")
                
            # Test basic action
            if not self.config.dry_run:
                print("[CONTROLLER] Testing basic look action...")
                await self.actions.look_horizontal(5.0)  # Small test movement
                await asyncio.sleep(0.2)
                await self.actions.look_horizontal(-5.0)  # Return to center
                print("[CONTROLLER] [OK] Basic actions working")
            else:
                print("[CONTROLLER] Dry run mode - skipping action test")
                
        except Exception as e:
            print(f"[CONTROLLER] ⚠️ Controller test failed: {e}")
            print("[CONTROLLER] Continuing anyway...")



    async def _execute_action(self, action: str, scene_type: SceneType):
        """Executes a planned action in the game.

        This method is responsible for translating a high-level action string
        (e.g., 'explore', 'attack') into concrete game inputs via the `SkyrimActions`
        and `SkyrimControllerBindings` systems. It includes logic for handling
        different action layers (e.g., switching to the 'Combat' layer for an
        attack) and context-aware behaviors, such as automatically exiting a menu
        if a non-menu action is attempted.

        Args:
            action: The string name of the action to be executed.
            scene_type: The current `SceneType` enum, used for context-aware
                action handling.
        """
        # Validate action
        if not action or not isinstance(action, str):
            print(f"[ACTION] Invalid action: {action}, using fallback")
            action = 'explore'
        
        # Handle menu interactions with learning ONLY when the action is menu-related
        menu_related_actions = ['open_inventory', 'open_map', 'open_magic', 'open_skills', 
                               'navigate_inventory', 'navigate_map', 'use_item', 'equip_item', 
                               'consume_item', 'favorite_item', 'exit_menu', 'exit']
        
        # CRITICAL FIX: Auto-exit dialogue/menus when trying non-menu actions
        # This prevents getting stuck in dialogue with ineffective movement attempts
        if scene_type in [SceneType.DIALOGUE, SceneType.INVENTORY, SceneType.MAP]:
            if action not in menu_related_actions:
                # Agent wants to do non-menu action but is in menu/dialogue
                print(f"[AUTO-EXIT] Detected {scene_type.value} scene but action '{action}' is not menu-related")
                print(f"[AUTO-EXIT] Exiting {scene_type.value} first to enable game control")
                
                # Exit dialogue/menu by pressing Tab (or ESC on some systems)
                # Tab works for both inventory and dialogue in Skyrim
                await self.actions.execute(Action(ActionType.BACK, duration=0.2))
                await asyncio.sleep(0.5)  # Wait for menu/dialogue to close
                
                # Press again if needed (sometimes takes 2 presses)
                await self.actions.execute(Action(ActionType.BACK, duration=0.2))
                await asyncio.sleep(0.5)
                
                print(f"[AUTO-EXIT] Dialogue/menu exit complete, now executing: {action}")
        
        if scene_type in [SceneType.INVENTORY, SceneType.MAP, SceneType.DIALOGUE] and action in menu_related_actions:
            # We're in a menu AND trying to do menu actions - use menu learner
            if not self.menu_learner.current_menu:
                # Entering menu
                menu_type = scene_type.value
                available_actions = ['activate', 'navigate', 'exit', 'select', 'back']
                self.menu_learner.enter_menu(menu_type, available_actions)
            
            # Get recommended action from menu learner
            suggested_action = self.menu_learner.suggest_menu_action(
                self.menu_learner.current_menu or scene_type.value,
                goal='explore' if action == 'explore' else 'exit'
            )
            
            if suggested_action and suggested_action in ['activate', 'navigate', 'exit', 'select', 'back']:
                print(f"[MENU] Using learned action: {suggested_action}")
                action = suggested_action
        else:
            # Not doing menu actions - ensure menu learner is exited
            if self.menu_learner.current_menu:
                self.menu_learner.exit_menu()
        
        # Sync action layer to context - ensure actions execute in correct layer
        if action in ('explore', 'navigate', 'quest_objective', 'practice', 'move_forward', 'move_backward', 
                      'move_left', 'move_right', 'jump', 'activate', 'look_around', 'turn_left', 'turn_right'):
            # Movement and exploration actions
            self.bindings.switch_to_exploration()
        elif action in ('combat', 'attack', 'power_attack', 'quick_attack', 'block', 'bash', 'dodge', 'retreat'):
            # Combat actions
            self.bindings.switch_to_combat()
        elif action in ('sneak', 'backstab'):
            # Stealth actions
            self.bindings.switch_to_stealth()
        elif action in ('interact', 'rest'):
            self.bindings.switch_to_exploration()
        elif action.startswith('switch_to_'):
            # Layer transitions handled below
            pass
        else:
            # Default to exploration for unknown actions
            if not scene_type in [SceneType.INVENTORY, SceneType.MAP, SceneType.DIALOGUE]:
                self.bindings.switch_to_exploration()

        # Execute actions with better variety and human-like behavior
        if action == 'explore':
            # Simple forward exploration to avoid circles
            print(f"[ACTION] Exploring forward")
            await self.actions.move_forward(duration=2.5)
            # Occasionally look around
            if random.random() < 0.3:
                await self.actions.look_around()
        elif action == 'combat':
            await self.actions.combat_sequence("Enemy")
        elif action in ('interact', 'activate'):
            # Special handling for activate in dialogue scenes
            if scene_type == SceneType.DIALOGUE:
                # Check if we've been stuck in dialogue too long
                dialogue_action_count = sum(1 for a in self.action_history[-5:] if 'activate' in str(a).lower())
                if dialogue_action_count >= 3:
                    print(f"[ACTION] Stuck in dialogue after {dialogue_action_count} activates - exiting dialogue")
                    # Exit dialogue instead of activating again
                    await self.actions.execute(Action(ActionType.BACK, duration=0.2))
                    await asyncio.sleep(0.5)
                    print(f"[ACTION] Exited dialogue, returning to game")
                else:
                    # Continue dialogue (select option or advance)
                    print(f"[ACTION] Progressing dialogue ({dialogue_action_count+1}/3 activates)")
                    await self.actions.execute(Action(ActionType.ACTIVATE, duration=0.3))
                    await asyncio.sleep(0.5)
            else:
                # Normal activation outside dialogue
                print(f"[ACTION] Interacting with object/NPC")
                await self.actions.execute(Action(ActionType.ACTIVATE, duration=0.3))
                await asyncio.sleep(0.5)  # Brief pause after activation
        elif action == 'navigate':
            await self.actions.move_forward(duration=2.0)
        elif action == 'rest':
            await self.actions.execute(Action(ActionType.WAIT, duration=1.0))
        elif action == 'practice':
            await self.actions.execute(Action(ActionType.ATTACK, duration=0.3))
        elif action == 'quest_objective':
            await self.actions.move_forward(duration=2.0)
        elif action == 'move_forward':
            await self.actions.move_forward(duration=1.5)
        elif action == 'jump':
            await self.actions.execute(Action(ActionType.JUMP, duration=0.2))
        elif action == 'sneak':
            await self.actions.execute(Action(ActionType.SNEAK, duration=0.5))
        elif action == 'attack':
            await self.actions.execute(Action(ActionType.ATTACK, duration=0.3))
        elif action in ('power_attack', 'quick_attack'):
            # Combat actions - hold attack longer for power attack
            await self.actions.execute(Action(ActionType.ATTACK, duration=0.8))
        elif action == 'block':
            # Block action - hold to block
            await self.actions.execute(Action(ActionType.BLOCK, duration=1.0))
        elif action in ('bash', 'shout'):
            # Special combat actions - use attack as fallback
            await self.actions.execute(Action(ActionType.ATTACK, duration=0.4))
        elif action == 'dodge':
            # Dodge by moving backward briefly
            await self.actions.move_backward(duration=0.5)
        elif action == 'retreat':
            # Retreat by moving backward
            await self.actions.move_backward(duration=1.5)
        elif action == 'heal':
            # Use healing spell via controller binding (not inventory menu)
            if scene_type in [SceneType.INVENTORY, SceneType.MAP, SceneType.DIALOGUE]:
                print(f"[ACTION] Already in {scene_type.value}, exiting menu first")
                # Exit menu instead
                await self.actions.execute(Action(ActionType.BACK, duration=0.2))
                await asyncio.sleep(0.5)
            else:
                # Execute heal action from controller bindings
                # This uses favorites + healing spell, not inventory
                print("[ACTION] Using healing spell (via controller binding)")
                await self.actions.execute(Action(ActionType.HEAL, duration=1.0))
        elif action == 'exit':
            # Exit menu/dialogue
            await self.actions.execute(Action(ActionType.BACK, duration=0.2))
        elif action in ('navigate_inventory', 'equip_item', 'consume_item', 'drop_item', 'favorite_item',
                        'navigate_map', 'navigate_magic', 'navigate_skills', 'use_item'):
            # Menu actions - navigate using D-pad or activate
            print(f"[ACTION] Menu action: {action}")
            await self.actions.execute(Action(ActionType.ACTIVATE, duration=0.2))
            await asyncio.sleep(0.3)
        elif action in ('open_inventory', 'open_map', 'open_magic', 'open_skills'):
            # Open specific menu
            print(f"[ACTION] Opening menu: {action}")
            await self.actions.execute(Action(ActionType.OPEN_INVENTORY, duration=0.2))
            await asyncio.sleep(0.5)
        elif action == 'look_around':
            # Human-like looking behavior
            await self.actions.look_around()
        elif action == 'turn_left':
            # Recovery: turn left to avoid obstacles
            await self.actions.turn_left(duration=1.0)
        elif action == 'turn_right':
            # Recovery: turn right to avoid obstacles
            await self.actions.turn_right(duration=1.0)
        elif action == 'move_backward':
            # Recovery: back up from obstacles
            await self.actions.move_backward(duration=0.8)
        elif action.startswith('switch_to_'):
            # Handle layer transition actions
            target_layer = action.replace('switch_to_', '').title()
            print(f"[META-STRATEGY] Executing layer transition to {target_layer}")
            
            if target_layer == 'Combat':
                self.bindings.switch_to_combat()
                # Perform a combat-ready action
                await self.actions.execute(Action(ActionType.ATTACK, duration=0.3))
            elif target_layer == 'Menu':
                self.bindings.switch_to_menu()
                # Actually open the inventory
                print("[LAYER] Switching to Menu layer and opening inventory")
                await self.actions.execute(Action(ActionType.OPEN_INVENTORY, duration=0.2))
                await asyncio.sleep(0.5)
            elif target_layer == 'Stealth':
                self.bindings.switch_to_stealth()
                # Enter sneak mode
                await self.actions.execute(Action(ActionType.SNEAK, duration=0.5))
            elif target_layer == 'Exploration':
                self.bindings.switch_to_exploration()
                # Continue exploration
                await self.actions.explore_with_waypoints(duration=2.0)
        else:
            # Fallback for unknown actions
            print(f"[ACTION] Unknown action '{action}', falling back to exploration")
            await self.actions.explore_with_waypoints(duration=2.0)

    def _detect_stuck(self) -> Dict[str, Any]:
        """Performs multi-tier, deterministic stuck detection.

        This method uses a set of pragmatic, rule-based heuristics to quickly
        determine if the AGI is in a stuck state, without relying on slower LLM
        analysis. It checks for several indicators, such as action repetition,
        lack of visual change, and coherence stagnation, and assigns a severity
        level (low, medium, high) to the detected state.

        Returns:
            A dictionary containing:
            - 'is_stuck' (bool): Whether a stuck state is detected.
            - 'severity' (str): 'none', 'low', 'medium', or 'high'.
            - 'reason' (str): A description of why the agent is considered stuck.
            - 'recovery_action' (str|None): A suggested action to resolve the
              stuck state.
        """
        stuck_info = {
            'is_stuck': False,
            'severity': 'none',
            'reason': '',
            'recovery_action': None
        }
        
        # Need at least a few actions to detect stuck
        if len(self.action_history) < self.stuck_detection_window:
            return stuck_info
        
        # 1. CRITICAL: Action repetition >8 times
        if self.consecutive_same_action >= 8:
            stuck_info['is_stuck'] = True
            stuck_info['severity'] = 'high'
            stuck_info['reason'] = f'Critical repetition: {self.last_executed_action} x{self.consecutive_same_action}'
            stuck_info['recovery_action'] = 'jump' if self.last_executed_action != 'jump' else 'turn_right'
            print(f"[STUCK-HIGH] {stuck_info['reason']} → {stuck_info['recovery_action']}")
            return stuck_info
        
        # 2. Check if we're repeating the same action in window
        recent_actions = self.action_history[-self.stuck_detection_window:]
        if len(set(recent_actions)) == 1:  # All same action
            same_action = recent_actions[0]
            
            # Check if coherence is changing (sign of progress)
            if len(self.coherence_history) >= self.stuck_detection_window:
                recent_coherence = self.coherence_history[-self.stuck_detection_window:]
                coherence_change = max(recent_coherence) - min(recent_coherence)
                
                if coherence_change < self.stuck_threshold:
                    stuck_info['is_stuck'] = True
                    stuck_info['severity'] = 'medium'
                    stuck_info['reason'] = f'Repeating {same_action} {self.stuck_detection_window}x, ΔC={coherence_change:.3f}'
                    stuck_info['recovery_action'] = 'turn_left' if 'turn' not in same_action else 'move_backward'
                    print(f"[STUCK-MEDIUM] {stuck_info['reason']} → {stuck_info['recovery_action']}")
                    return stuck_info
        
        # 3. MEDIUM: Visual similarity (seeing same thing)
        if len(self.visual_embedding_history) >= 3:
            import numpy as np
            recent_embeddings = self.visual_embedding_history[-3:]
            if all(isinstance(e, (list, np.ndarray)) for e in recent_embeddings) and len(recent_embeddings) >= 2:
                # Cosine similarity between last two
                last = np.array(recent_embeddings[-1]).flatten()
                prev = np.array(recent_embeddings[-2]).flatten()
                similarity = np.dot(last, prev) / (np.linalg.norm(last) * np.linalg.norm(prev) + 1e-8)
                
                if similarity > 0.98:  # 98% similar = visually stuck
                    stuck_info['is_stuck'] = True
                    stuck_info['severity'] = 'low'
                    stuck_info['reason'] = f'Visual stuckness: {similarity:.3f} similarity'
                    stuck_info['recovery_action'] = 'turn_around'
                    print(f"[STUCK-LOW] {stuck_info['reason']} → {stuck_info['recovery_action']}")
                    
                    # STUCK TRACKER: Record detection
                    current_coherence = self.current_consciousness.coherence if self.current_consciousness else 0.5
                    game_state = self.current_perception.get('game_state') if self.current_perception else None
                    location = game_state.location_name if game_state else "unknown"
                    
                    detection = self.stuck_tracker.detect_stuck(
                        visual_similarity=similarity,
                        repeated_action=self.last_executed_action or "unknown",
                        repeat_count=self.consecutive_same_action,
                        coherence=current_coherence,
                        location=location
                    )
                    
                    # Store detection for later recovery attempt
                    stuck_info['tracker_detection'] = detection
                    
                    return stuck_info
        
        return stuck_info
    
    def _update_stuck_tracking(self, action: str, coherence: float, visual_embedding=None):
        """Updates internal states used for stuck detection and tracking.

        This method is called after each action to maintain a history of recent
        actions, visual embeddings, and coherence values. This data is crucial
        for the deterministic stuck detection heuristics in `_detect_stuck` and
        `_detect_stuck_failsafe`. It also records outcomes for reward-guided
        tuning systems.

        Args:
            action: The string name of the action that was just executed.
            coherence: The coherence value measured after the action.
            visual_embedding: The visual embedding of the scene after the action.
                Defaults to None.
        """
        # STUCK TRACKER: Tick cycle and verify pending recoveries
        if visual_embedding is not None:
            self.stuck_tracker.tick_cycle(visual_embedding)
        
        # Track action history
        self.action_history.append(action)
        if len(self.action_history) > 20:  # Keep last 20 actions
            self.action_history.pop(0)
        
        # Record outcome for reward-guided tuning
        if self.reward_tuning and consciousness_state:
            # Compute reward based on coherence delta and action success
            reward = consciousness_state.coherence_delta
            
            # Bonus for positive outcomes
            if game_state.health > prev_health:
                reward += 0.2  # Health increased
            if not game_state.in_combat and prev_in_combat:
                reward += 0.3  # Escaped combat
            
            # Penalty for negative outcomes
            if game_state.health < prev_health - 10:
                reward -= 0.3  # Took damage
            if game_state.in_combat and not prev_in_combat:
                reward -= 0.2  # Entered combat
            
            # Record outcome
            self.reward_tuning.record_outcome(
                action=action,
                context={
                    'health': prev_health,
                    'in_combat': prev_in_combat,
                    'scene': scene_type.value,
                    'cycle': cycle_count
                },
                outcome={
                    'health_delta': game_state.health - prev_health,
                    'combat_state': game_state.in_combat
                },
                reward=reward,
                coherence_delta=consciousness_state.coherence_delta
            )
        
        # Track visual embeddings for similarity detection
        if visual_embedding is not None:
            self.visual_embedding_history.append(visual_embedding)
            if len(self.visual_embedding_history) > 10:  # Keep last 10 embeddings
                self.visual_embedding_history.pop(0)
        
        # Track coherence history
        self.coherence_history.append(coherence)
        if len(self.coherence_history) > self.stuck_detection_window * 2:
            self.coherence_history.pop(0)
        
        # Track consecutive same action
        if action == self.last_executed_action:
            self.consecutive_same_action += 1
        else:
            self.consecutive_same_action = 1
        
        self.last_executed_action = action
    
    def _display_performance_dashboard(self):
        """Displays a real-time performance and status dashboard in the console.

        This method aggregates and prints a comprehensive overview of the AGI's
        current state, including the breakdown of action sources (LLM vs.
        heuristic), LLM rate limit status, timing statistics, and the status of
        numerous advanced subsystems like the State Coordinator, OMEGA Hyperhelix,
        and Curriculum RL.
        """
        total_actions = self.stats['actions_taken']
        if total_actions == 0:
            return
        
        print(f"\n{'='*70}")
        print(f"⚡ PERFORMANCE DASHBOARD (Cycle {self.cycle_count})")
        print(f"{'='*70}")
        
        # Action Source Breakdown
        source_total = sum([
            self.stats.get('action_source_moe', 0),
            self.stats.get('action_source_hybrid', 0),
            self.stats.get('action_source_phi4', 0),
            self.stats.get('action_source_local_moe', 0),
            self.stats.get('action_source_heuristic', 0),
            self.stats.get('action_source_timeout', 0),
        ])
        
        if source_total > 0:
            print(f"\n[TARGET] ACTION SOURCES:")
            moe_pct = 100 * self.stats.get('action_source_moe', 0) / source_total
            hybrid_pct = 100 * self.stats.get('action_source_hybrid', 0) / source_total
            phi4_pct = 100 * self.stats.get('action_source_phi4', 0) / source_total
            heur_pct = 100 * self.stats.get('action_source_heuristic', 0) / source_total
            timeout_pct = 100 * self.stats.get('action_source_timeout', 0) / source_total
            
            print(f"  Cloud MoE:     {self.stats.get('action_source_moe', 0):3d} ({moe_pct:5.1f}%) {'[OK]' if moe_pct > 20 else '[WARN]' if moe_pct > 5 else '[FAIL]'}")
            print(f"  Hybrid LLM:    {self.stats.get('action_source_hybrid', 0):3d} ({hybrid_pct:5.1f}%) {'[OK]' if hybrid_pct > 10 else '[WARN]' if hybrid_pct > 2 else '[FAIL]'}")
            print(f"  Phi-4 Local:   {self.stats.get('action_source_phi4', 0):3d} ({phi4_pct:5.1f}%)")
            print(f"  Heuristics:    {self.stats.get('action_source_heuristic', 0):3d} ({heur_pct:5.1f}%) {'[OK]' if heur_pct < 30 else '[WARN]' if heur_pct < 60 else '[FAIL]'}")
            print(f"  Timeouts:      {self.stats.get('action_source_timeout', 0):3d} ({timeout_pct:5.1f}%) {'[OK]' if timeout_pct < 10 else '[WARN]' if timeout_pct < 30 else '[FAIL]'}")
        
        # Rate Limit Status
        if self.moe and hasattr(self.moe, 'is_gemini_rate_limited'):
            is_limited, wait_time = self.moe.is_gemini_rate_limited()
            gemini_rpm = self.moe.gemini_rpm_limit if hasattr(self.moe, 'gemini_rpm_limit') else 0
            claude_rpm = self.moe.claude_rpm_limit if hasattr(self.moe, 'claude_rpm_limit') else 0
            
            print(f"\n[RATE]  RATE LIMIT STATUS:")
            print(f"  Gemini:  {'[FAIL] LIMITED' if is_limited else '[OK] AVAILABLE'} ({wait_time:.1f}s wait) | Limit: {gemini_rpm} RPM")
            print(f"  Claude:  [OK] AVAILABLE | Limit: {claude_rpm} RPM")
            print(f"  Queued:  {self.stats.get('llm_queued_requests', 0)} | Skipped: {self.stats.get('llm_skipped_rate_limit', 0)}")
        
        # Timing Stats
        if self.stats['planning_times']:
            avg_planning = sum(self.stats['planning_times'][-10:]) / len(self.stats['planning_times'][-10:])
            print(f"\n[TIME]  TIMING (last 10 cycles):")
            print(f"  Avg Planning:   {avg_planning:.2f}s {'[OK]' if avg_planning < 10 else '[WARN]' if avg_planning < 20 else '[FAIL]'}")
            
        if self.stats['execution_times']:
            avg_exec = sum(self.stats['execution_times'][-10:]) / len(self.stats['execution_times'][-10:])
            print(f"  Avg Execution:  {avg_exec:.2f}s")
        
        # Success Rate
        success_rate = 0.0
        if total_actions > 0:
            success_rate = self.stats['action_success_count'] / total_actions
        
        print(f"\n[STATS] EFFECTIVENESS:")
        print(f"  Success Rate:  {success_rate:.1%} {'[OK]' if success_rate > 0.3 else '[WARN]' if success_rate > 0.15 else '[FAIL]'}")
        print(f"  Fast Actions:  {self.stats['fast_action_count']} ({100*self.stats['fast_action_count']/total_actions:.0f}%)")
        
        # Consciousness
        if hasattr(self, 'current_consciousness') and self.current_consciousness:
            print(f"\n[CONSCIOUSNESS]:")
            print(f"  Coherence C:    {self.current_consciousness.coherence:.3f}")
            print(f"  Ontical Lo:    {self.current_consciousness.coherence_ontical:.3f}")
            print(f"  Structural Ls: {self.current_consciousness.coherence_structural:.3f}")
            print(f"  Participatory Lp: {self.current_consciousness.coherence_participatory:.3f}")
        
        # State Coordinator (Epistemic Coherence)
        if hasattr(self, 'state_coordinator'):
            coord_stats = self.state_coordinator.get_stats()
            epistemic_coherence = coord_stats['coherence']
            conflicts = coord_stats['active_conflicts']
            
            print(f"\n[COORD] STATE COORDINATION:")
            print(f"  Epistemic Coherence: {epistemic_coherence:.3f} {'[OK]' if epistemic_coherence > 0.7 else '[WARN]' if epistemic_coherence > 0.4 else '[FAIL]'}")
            print(f"  Active Conflicts:    {conflicts} {'[OK]' if conflicts == 0 else '[WARN]' if conflicts < 3 else '[FAIL]'}")
            print(f"  Subsystems Tracked:  {coord_stats['subsystem_count']}")
            print(f"  Total Conflicts:     {coord_stats['conflicts_detected']}")
            print(f"  Resolved:            {coord_stats['conflicts_resolved']}")
            
            # Show canonical state if available
            if hasattr(self.state_coordinator, 'canonical_state'):
                canonical = self.state_coordinator.get_canonical_state()
                print(f"  Canonical Scene:     {canonical.get('scene', 'unknown')}")
        
        # OMEGA DNA HYPERHELIX
        if hasattr(self, 'omega') and self.omega:
            omega = self.omega.get_stats()
            phase = omega.get('phase', {})
            print(f"\n🧬 OMEGA DNA HYPERHELIX:")
            print(f"  Nodes Mapped:      {omega.get('nodes_mapped', 0)}")
            print(f"  Phase 4D:")
            print(f"    Integration:     {phase.get('integration', 0.0):.3f}")
            print(f"    Temporal:        {phase.get('temporal', 0.0):.3f}")
            print(f"    Causal:          {phase.get('causal', 0.0):.3f}")
            print(f"    Predictive:      {phase.get('predictive', 0.0):.3f}")
            print(f"  Gating Events:     {omega.get('gating_events', 0)}")
            print(f"  MoE Calls:         {omega.get('moe_calls', 0)} (hybrid: {omega.get('hybrid_calls', 0)})")
            print(f"  Cost Saved (est):  ${omega.get('cost_saved_estimate', 0.0):.2f}")
            print(f"  Multimodal Align.: {omega.get('multimodal_alignments', 0)} avg={omega.get('avg_alignment_score', 0.0):.3f}")
            print(f"  TTA Updates:       {omega.get('tta_updates', 0)}")
            print(f"  Curriculum Suggs.: {omega.get('curriculum_suggestions', 0)}")
            print(f"  EWC Consolidations:{omega.get('ewc_consolidations', 0)}")
        
        # MATRIX NETWORK OF IMPROVEMENT
        if hasattr(self, 'matrix_manager') and self.matrix_manager:
            mstats = self.matrix_manager.get_stats()
            print(f"\n🧿 MATRIX NETWORK:")
            print(f"  Modules:           {mstats.get('modules', 0)}")
            print(f"  PhaseWeight Mean:  {mstats.get('phase_weight_mean', 0.0):.3f}")
            print(f"  TTA Updates:       {mstats.get('tta_updates', 0)}")
            print(f"  Curriculum Inject: {mstats.get('curriculum_injections', 0)}")
        
        # STUCK Recovery Tracker
        if hasattr(self, 'stuck_tracker'):
            recovery_stats = self.stuck_tracker.get_stats()
            success_rate = recovery_stats['success_rate']
            
            print(f"\n[RECOVERY] STUCK RECOVERY:")
            print(f"  Total STUCK Detected: {recovery_stats['total_detections']}")
            print(f"  Recovery Attempts:    {recovery_stats['total_recoveries']}")
            print(f"  Success Rate:         {success_rate:.1%} {'[OK]' if success_rate > 0.6 else '[WARN]' if success_rate > 0.3 else '[FAIL]'}")
            print(f"  Successful:           {recovery_stats['successful_recoveries']}")
            print(f"  Failed:               {recovery_stats['failed_recoveries']}")
            print(f"  Pending Verification: {recovery_stats['pending_verifications']}")
            
            # Show best recovery action if known
            if recovery_stats['best_recovery_action']:
                print(f"  Best Recovery Action: {recovery_stats['best_recovery_action']}")
        
        # MOTOR CONTROL LAYER
        motor_reflex = self.stats.get('motor_reflex_count', 0)
        motor_menu = self.stats.get('motor_menu_count', 0)
        motor_combat = self.stats.get('motor_combat_count', 0)
        motor_nav = self.stats.get('motor_navigation_count', 0)
        motor_total = motor_reflex + motor_menu + motor_combat + motor_nav
        camera_stuck_breaks = self.stats.get('camera_stuck_breaks', 0)
        
        if motor_total > 0 or camera_stuck_breaks > 0:
            print(f"\n🦾 MOTOR CONTROL LAYER:")
            if motor_total > 0:
                print(f"  Total Actions:    {motor_total}")
                print(f"  Reflexes:         {motor_reflex} ({100*motor_reflex/motor_total:.1f}%)")
                print(f"  Menu Handling:    {motor_menu} ({100*motor_menu/motor_total:.1f}%)")
                print(f"  Combat:           {motor_combat} ({100*motor_combat/motor_total:.1f}%)")
                print(f"  Navigation:       {motor_nav} ({100*motor_nav/motor_total:.1f}%)")
            
            # Camera stuck prevention
            if camera_stuck_breaks > 0:
                print(f"  Camera Stuck Breaks: {camera_stuck_breaks} {'[OK]' if camera_stuck_breaks < 5 else '[WARN]' if camera_stuck_breaks < 15 else '[FAIL]'}")
            
            # Get controller stats
            if hasattr(self, 'motor_controller'):
                motor_stats = self.motor_controller.get_stats()
                print(f"  Total Executions: {motor_stats['total_executions']}")
            
            # Get stuck detection from navigator
            if hasattr(self, 'navigator'):
                nav_stats = self.navigator.get_stats()
                print(f"  Stuck Detections: {nav_stats['stuck_detections']}")
                print(f"  Camera Stuck (Nav): {nav_stats.get('camera_stuck_detections', 0)}")
                print(f"  Stuck Counter:    {nav_stats['stuck_counter']}")
        
        # CURRICULUM RL
        if hasattr(self, 'curriculum'):
            curr_stats = self.curriculum.get_stats()
            print(f"\n📚 CURRICULUM RL:")
            print(f"  Current Stage:    {curr_stats['current_stage']}")
            print(f"  Stage Cycles:     {curr_stats['stage_cycles']}")
            print(f"  Progress:         {curr_stats['stage_successes']}/{self.curriculum.reward_fn.progress.advancement_threshold}")
            print(f"  Avg Reward:       {curr_stats['avg_reward']:+.3f}")
            print(f"  Advancements:     {curr_stats.get('curriculum_advancements', 0)}")
            
            # Show symbolic rules status
            if hasattr(self, 'current_perception') and self.current_perception:
                game_state = self.current_perception.get('game_state')
                if game_state:
                    rules_info = self.curriculum.get_current_rules(game_state.to_dict())
                    if rules_info.get('num_triggered', 0) > 0:
                        print(f"  Active Rules:     {rules_info['num_triggered']}")
                        if rules_info.get('suggested_action'):
                            print(f"  Suggestion:       {rules_info['suggested_action']}")
        
        print(f"{'='*70}\n")

    def _update_action_diversity_stats(self, action: str, coherence: float):
        """Tracks statistics related to action diversity and their outcomes.

        This method implements a recommendation from GPT-4o for continuous,
        Hebbian-style learning. It logs the frequency of each action and the
        average coherence (as a proxy for reward) that results from it.
        Periodically, it triggers `_analyze_action_patterns` to adapt the AGI's
        behavior based on this data.

        Args:
            action: The string name of the action that was taken.
            coherence: The resulting coherence value after the action.
        """
        # Track action frequency
        if action not in self.action_type_counts:
            self.action_type_counts[action] = 0
            self.reward_by_action_type[action] = []
        
        self.action_type_counts[action] += 1
        self.reward_by_action_type[action].append(coherence)
        self.recent_action_types.append(action)
        
        # Keep recent window manageable
        if len(self.recent_action_types) > 50:
            self.recent_action_types = self.recent_action_types[-50:]
        
        # Periodically analyze and adapt
        if len(self.recent_action_types) >= 20 and len(self.recent_action_types) % 10 == 0:
            self._analyze_action_patterns()
    
    def _analyze_action_patterns(self):
        """Analyzes action diversity and reward patterns to provide learning insights.

        This is part of a continuous learning adaptation mechanism. It calculates
        metrics like action diversity score and identifies the best- and worst-
        performing actions based on their average resulting coherence. These
        insights can be used by other systems to adjust action selection strategy.
        """
        if not self.reward_by_action_type:
            return
        
        # Calculate diversity metrics
        total_actions = sum(self.action_type_counts.values())
        action_diversity = len(self.action_type_counts) / max(total_actions, 1)
        
        # Find best performing actions
        avg_rewards = {
            action: sum(rewards) / len(rewards)
            for action, rewards in self.reward_by_action_type.items()
            if rewards
        }
        
        if avg_rewards:
            best_action = max(avg_rewards.items(), key=lambda x: x[1])
            worst_action = min(avg_rewards.items(), key=lambda x: x[1])
            
            print(f"[DIVERSITY] Action diversity: {action_diversity:.2f}")
            print(f"[DIVERSITY] Best action: {best_action[0]} (avg coherence: {best_action[1]:.3f})")
            print(f"[DIVERSITY] Learning from {len(self.reward_by_action_type)} action types")

    def _update_dashboard_state(self, action: Optional[str] = None, action_source: Optional[str] = None):
        """Updates the real-time dashboard streamer with the AGI's current state.

        This method is called during the main gameplay loop to push a
        comprehensive snapshot of the AGI's status to the `DashboardStreamer`.
        This allows for external, real-time monitoring of the AGI's performance
        and internal state via a web application.

        Args:
            action: The action currently being planned or executed.
            action_source: The name of the subsystem that generated the action.
        """
        if not hasattr(self, 'dashboard_streamer') or not self.dashboard_streamer:
            return
        
        try:
            # Collect current state
            agi_state = {
                'cycle': self.stats.get('cycles_completed', 0),
                'action': action or self.last_executed_action or 'idle',
                'action_source': action_source or self.last_action_source or 'unknown',
                
                # Perception
                'perception': {
                    'scene_type': self.current_perception.get('scene_type', 'unknown') if self.current_perception else 'unknown',
                    'objects': self.current_perception.get('objects', []) if self.current_perception else [],
                    'enemies_nearby': self.current_perception.get('enemies_nearby', False) if self.current_perception else False,
                    'npcs_nearby': self.current_perception.get('npcs_nearby', False) if self.current_perception else False,
                    'last_vision_time': self.current_perception.get('last_vision_time', 0) if self.current_perception else 0
                },
                
                # Game state
                'game_state': self._extract_game_state(),
                
                # Consciousness
                'consciousness': {
                    'coherence': self.current_consciousness.coherence if self.current_consciousness else 0,
                    'phi': self.current_consciousness.consciousness_level if self.current_consciousness else 0,
                    'nodes_active': len(self.consciousness_monitor.registered_nodes) if hasattr(self, 'consciousness_monitor') and self.consciousness_monitor and hasattr(self.consciousness_monitor, 'registered_nodes') else 0
                },
                
                # LLM status
                'llm_status': {
                    'mode': self.config.llm_architecture if hasattr(self.config, 'llm_architecture') else 'none',
                    'cloud_active': sum([
                        1 if hasattr(self, 'hybrid_llm') and self.hybrid_llm else 0,
                        1 if hasattr(self, 'moe') and self.moe else 0
                    ]),
                    'local_active': 1 if hasattr(self, 'local_moe') and self.local_moe else 0,
                    'total_calls': self.stats.get('llm_action_count', 0),
                    'last_call_time': 0,  # TODO: Track this
                    'active_models': self._get_active_models()
                },
                
                # Performance
                'performance': {
                    'fps': 60,  # TODO: Calculate from cycle times
                    'planning_time': sum(self.stats.get('planning_times', [0])[-5:]) / max(len(self.stats.get('planning_times', [1])[-5:]), 1),
                    'execution_time': sum(self.stats.get('execution_times', [0])[-5:]) / max(len(self.stats.get('execution_times', [1])[-5:]), 1),
                    'vision_time': 0,  # TODO: Track this
                    'total_cycle_time': 0  # TODO: Calculate
                },
                
                # Stats
                'stats': {
                    'success_rate': self.stats.get('action_success_count', 0) / max(self.stats.get('actions_taken', 1), 1),
                    'rl_actions': self.stats.get('rl_action_count', 0),
                    'llm_actions': self.stats.get('llm_action_count', 0),
                    'heuristic_actions': self.stats.get('heuristic_action_count', 0)
                },
                
                # World model
                'world_model': {
                    'beliefs': {},  # TODO: Extract from world model
                    'goals': [self.current_goal] if self.current_goal else [],
                    'strategy': 'explore'  # TODO: Extract from planner
                }
            }
            
            # Update dashboard
            self.dashboard_streamer.update(agi_state)
            
        except Exception as e:
            # Don't crash the AGI if dashboard fails
            print(f"[DASHBOARD] Warning: Update failed: {e}")
    
    def _extract_game_state(self) -> Dict[str, Any]:
        """Extracts and standardizes the game state from perception data.

        This is a utility function to reliably get a dictionary representation
        of the game state, whether the source `game_state` is a dictionary or a
        `GameState` dataclass object. It provides a consistent data structure for
        other parts of the system.

        Returns:
            A dictionary containing key game state information like health,
            magicka, stamina, combat status, and location.
        """
        if not self.current_perception:
            return {
                'health': 100,
                'magicka': 100,
                'stamina': 100,
                'in_combat': False,
                'in_menu': False,
                'location': 'Unknown'
            }
        
        game_state = self.current_perception.get('game_state')
        
        # Handle GameState object (dataclass)
        if game_state and hasattr(game_state, 'health'):
            return {
                'health': getattr(game_state, 'health', 100),
                'magicka': getattr(game_state, 'magicka', 100),
                'stamina': getattr(game_state, 'stamina', 100),
                'in_combat': getattr(game_state, 'in_combat', False),
                'in_menu': getattr(game_state, 'in_menu', False),
                'location': getattr(game_state, 'location_name', 'Unknown')
            }
        
        # Handle dictionary
        if isinstance(game_state, dict):
            return {
                'health': game_state.get('health', 100),
                'magicka': game_state.get('magicka', 100),
                'stamina': game_state.get('stamina', 100),
                'in_combat': game_state.get('in_combat', False),
                'in_menu': game_state.get('in_menu', False),
                'location': game_state.get('location', 'Unknown')
            }
        
        # Fallback
        return {
            'health': 100,
            'magicka': 100,
            'stamina': 100,
            'in_combat': False,
            'in_menu': False,
            'location': 'Unknown'
        }
    
    def _get_active_models(self) -> list:
        """Returns a list of the names of all currently active LLM models.

        This utility function inspects the AGI's configuration and initialized
        clients to compile a list of all LLM models that are part of the active
        cognitive architecture (Hybrid, MoE, local, etc.).

        Returns:
            A list of strings, where each string is the name of an active model.
        """
        models = []
        
        if hasattr(self, 'hybrid_llm') and self.hybrid_llm:
            models.extend(['Gemini 2.0 Flash', 'Claude Sonnet 4.5'])
        
        if hasattr(self, 'moe') and self.moe:
            models.extend(['Gemini 1', 'Gemini 2', 'Claude Sonnet', 'GPT-4o', 'Nemotron', 'Qwen3'])
        
        if hasattr(self, 'local_moe') and self.local_moe:
            models.extend(['Huihui-VL', 'Qwen3-VL', 'Phi-4'])
        
        return models

    async def _cleanup_connections(self):
        """Gracefully closes all asynchronous connections and resources.

        This method is called at the end of a gameplay session to ensure that
        all open network connections (e.g., to LLM APIs) and other resources are
        properly terminated, preventing resource leaks.
        """
        print("\n[CLEANUP] Closing all connections...")
        closed_count = 0
        
        # Close video interpreter
        if hasattr(self, 'video_interpreter') and self.video_interpreter:
            try:
                await self.video_interpreter.close()
                print("[CLEANUP] [OK] Video interpreter closed")
                closed_count += 1
            except Exception as e:
                print(f"[CLEANUP] ⚠️ Video interpreter close error: {e}")
        
        # Close voice system
        if hasattr(self, 'voice_system') and self.voice_system:
            try:
                if hasattr(self.voice_system, 'close'):
                    await self.voice_system.close()
                    print("[CLEANUP] [OK] Voice system closed")
                    closed_count += 1
            except Exception as e:
                print(f"[CLEANUP] ⚠️ Voice system close error: {e}")
        
        # Close GPT-5 orchestrator
        if hasattr(self, 'gpt5_orchestrator') and self.gpt5_orchestrator:
            try:
                if hasattr(self.gpt5_orchestrator, 'close'):
                    await self.gpt5_orchestrator.close()
                    print("[CLEANUP] [OK] GPT-5 orchestrator closed")
                    closed_count += 1
            except Exception as e:
                print(f"[CLEANUP] ⚠️ GPT-5 orchestrator close error: {e}")
        
        # Close Wolfram analyzer
        if hasattr(self, 'wolfram_analyzer') and self.wolfram_analyzer:
            try:
                if hasattr(self.wolfram_analyzer, 'close'):
                    await self.wolfram_analyzer.close()
                    print("[CLEANUP] [OK] Wolfram analyzer closed")
                    closed_count += 1
            except Exception as e:
                print(f"[CLEANUP] ⚠️ Wolfram analyzer close error: {e}")
        
        # Close LLM clients
        llm_clients = [
            ('gemini_client', 'Gemini client'),
            ('claude_client', 'Claude client'),
            ('openai_client', 'OpenAI client'),
            ('hyperbolic_client', 'Hyperbolic client'),
            ('lmstudio_client', 'LMStudio client'),
        ]
        
        for attr_name, display_name in llm_clients:
            if hasattr(self, attr_name):
                client = getattr(self, attr_name)
                if client:
                    try:
                        if hasattr(client, 'close'):
                            await client.close()
                            print(f"[CLEANUP] [OK] {display_name} closed")
                            closed_count += 1
                    except Exception as e:
                        print(f"[CLEANUP] ⚠️ {display_name} close error: {e}")
        
        # Close MoE orchestrator
        if hasattr(self, 'moe') and self.moe:
            try:
                if hasattr(self.moe, 'close'):
                    await self.moe.close()
                    print("[CLEANUP] [OK] MoE orchestrator closed")
                    closed_count += 1
            except Exception as e:
                print(f"[CLEANUP] ⚠️ MoE orchestrator close error: {e}")
        
        # Close GPT-5 Meta RL
        if hasattr(self, 'gpt5_meta_rl') and self.gpt5_meta_rl:
            try:
                if hasattr(self.gpt5_meta_rl, 'close'):
                    await self.gpt5_meta_rl.close()
                    print("[CLEANUP] [OK] GPT-5 Meta RL closed")
                    closed_count += 1
            except Exception as e:
                print(f"[CLEANUP] ⚠️ GPT-5 Meta RL close error: {e}")
        
        # Wait for all connections to close
        await asyncio.sleep(0.5)
        
        print(f"[CLEANUP] Complete - {closed_count} systems closed")
    
    def _print_final_stats(self):
        """Print final statistics."""
        print(f"\nFinal Statistics:")
        print(f"  Cycles: {self.stats['cycles_completed']}")
        print(f"  Actions: {self.stats['actions_taken']}")
        print(f"  Playtime: {self.stats['total_playtime'] / 60:.1f} minutes")
        if self.stats['game_state_quality_history']:
            avg_quality = sum(self.stats['game_state_quality_history']) / len(self.stats['game_state_quality_history'])
            print(f"  Avg Game State Quality: {avg_quality:.3f}")
        skyrim_stats = self.skyrim_world.get_stats()
        print(f"\nWorld Model:")
        print(f"  Causal edges learned: {skyrim_stats['causal_edges']}")
        print(f"  NPCs met: {skyrim_stats['npc_relationships']}")
        print(f"  Locations: {skyrim_stats['locations_discovered']}")
        action_stats = self.actions.get_stats()
        print(f"\nActions:")
        print(f"  Total executed: {action_stats['actions_executed']}")
        print(f"  Errors: {action_stats['errors']}")
        
        # Performance metrics
        success_rate = 0.0
        if self.stats['actions_taken'] > 0:
            success_rate = self.stats['action_success_count'] / self.stats['actions_taken']
        
        print(f"\n[STATS] Performance Metrics:")
        print(f"  Action success rate: {success_rate:.1%}")
        print(f"  Successful actions: {self.stats['action_success_count']}")
        print(f"  Failed actions: {self.stats['action_failure_count']}")

        # Fast reactive loop stats
        if self.stats['fast_action_count'] > 0:
            print(f"\n⚡ Fast Reactive Loop:")
            print(f"  Fast actions taken: {self.stats['fast_action_count']}")
            if self.stats['actions_taken'] > 0:
                fast_ratio = 100 * self.stats['fast_action_count'] / self.stats['actions_taken']
                print(f"  Fast action ratio: {fast_ratio:.1f}%")
            if self.stats['fast_action_times']:
                avg_fast = sum(self.stats['fast_action_times']) / len(self.stats['fast_action_times'])
                print(f"  Avg fast action time: {avg_fast:.3f}s")

        # Planning method breakdown
        total_planning = self.stats['rl_action_count'] + self.stats['llm_action_count'] + self.stats['heuristic_action_count']
        if total_planning > 0:
            print(f"\n[BRAIN] Planning Methods:")
            print(f"  RL-based: {self.stats['rl_action_count']} ({100*self.stats['rl_action_count']/total_planning:.1f}%)")
            print(f"  LLM-based: {self.stats['llm_action_count']} ({100*self.stats['llm_action_count']/total_planning:.1f}%)")
            print(f"  Heuristic: {self.stats['heuristic_action_count']} ({100*self.stats['heuristic_action_count']/total_planning:.1f}%)")
        
        # Action source breakdown (which system provided actions)
        total_actions = sum([
            self.stats.get('action_source_moe', 0),
            self.stats.get('action_source_hybrid', 0),
            self.stats.get('action_source_phi4', 0),
            self.stats.get('action_source_local_moe', 0),
            self.stats.get('action_source_heuristic', 0),
            self.stats.get('action_source_timeout', 0),
        ])
        if total_actions > 0:
            print(f"\n[TARGET] Action Sources (who provided the action):")
            print(f"  Gemini MoE: {self.stats.get('action_source_moe', 0)} ({100*self.stats.get('action_source_moe', 0)/total_actions:.1f}%)")
            print(f"  Hybrid LLM: {self.stats.get('action_source_hybrid', 0)} ({100*self.stats.get('action_source_hybrid', 0)/total_actions:.1f}%)")
            print(f"  Phi-4 Planner: {self.stats.get('action_source_phi4', 0)} ({100*self.stats.get('action_source_phi4', 0)/total_actions:.1f}%)")
            print(f"  Local MoE: {self.stats.get('action_source_local_moe', 0)} ({100*self.stats.get('action_source_local_moe', 0)/total_actions:.1f}%)")
            print(f"  Heuristic: {self.stats.get('action_source_heuristic', 0)} ({100*self.stats.get('action_source_heuristic', 0)/total_actions:.1f}%)")
            print(f"  Timeout: {self.stats.get('action_source_timeout', 0)} ({100*self.stats.get('action_source_timeout', 0)/total_actions:.1f}%)")
            if self.last_action_source:
                print(f"  Last successful: {self.last_action_source}")
        
        # Quantum Superposition stats
        if hasattr(self, 'quantum_explorer'):
            fractal_stats = self.quantum_explorer.get_fractal_stats()
            print(f"\n🌀 Quantum Superposition (4D Fractal RNG):")
            print(f"  Fractal iterations: {fractal_stats['iteration_depth']}")
            print(f"  Fibonacci phase: {fractal_stats['fibonacci_phase']}/50")
            print(f"  Golden ratio φ: {fractal_stats['phi']:.6f}")
            print(f"  Variance range: {fractal_stats['variance_range']}")
            state = fractal_stats['state']
            print(f"  4D state: [{state['x']:.3f}, {state['y']:.3f}, {state['z']:.3f}, {state['w']:.3f}]")
            
            # Show exploration vector
            exploration = self.quantum_explorer.get_exploration_vector()
            print(f"  Exploration vector:")
            print(f"    Spatial: {exploration[0]:.3f} | Social: {exploration[1]:.3f}")
            print(f"    Cognitive: {exploration[2]:.3f} | Consciousness: {exploration[3]:.3f}")
        
        # Timing metrics
        if self.stats['planning_times']:
            avg_planning = sum(self.stats['planning_times']) / len(self.stats['planning_times'])
            print(f"\n[RATE]  Timing:")
            print(f"  Avg planning time: {avg_planning:.3f}s")
        if self.stats['execution_times']:
            avg_execution = sum(self.stats['execution_times']) / len(self.stats['execution_times'])
            print(f"  Avg execution time: {avg_execution:.3f}s")
        
        # Action Diversity Analysis (GPT-4o recommendation implementation)
        if self.action_type_counts:
            total_actions_taken = sum(self.action_type_counts.values())
            unique_actions = len(self.action_type_counts)
            diversity_score = unique_actions / max(total_actions_taken, 1)
            
            print(f"\n🎨 Action Diversity Analysis:")
            print(f"  Unique actions used: {unique_actions}")
            print(f"  Total actions taken: {total_actions_taken}")
            print(f"  Diversity score: {diversity_score:.3f} {'[OK]' if diversity_score > 0.3 else '[WARN]' if diversity_score > 0.15 else '[FAIL]'}")
            
            # Show top 5 most used actions
            top_actions = sorted(self.action_type_counts.items(), key=lambda x: x[1], reverse=True)[:5]
            print(f"  Most used actions:")
            for action, count in top_actions:
                pct = 100 * count / total_actions_taken
                avg_reward = sum(self.reward_by_action_type.get(action, [0])) / max(len(self.reward_by_action_type.get(action, [1])), 1)
                print(f"    {action}: {count}x ({pct:.1f}%) | Avg coherence: {avg_reward:.3f}")
        
        # Strategic planner stats
        planner_stats = self.strategic_planner.get_stats()
        print(f"\nStrategic Planner:")
        print(f"  Patterns learned: {planner_stats['patterns_learned']}")
        print(f"  Experiences: {planner_stats['experiences_recorded']}")
        print(f"  Plans executed: {planner_stats['plans_executed']}")
        print(f"  Success rate: {planner_stats['success_rate']:.1%}")
        
        # Menu learner stats
        menu_stats = self.menu_learner.get_stats()
        print(f"\nMenu Learning:")
        print(f"  Menus explored: {menu_stats['menus_explored']}")
        print(f"  Menu actions: {menu_stats['total_menu_actions']}")
        print(f"  Transitions learned: {menu_stats['transitions_learned']}")
        
        # Memory RAG stats
        rag_stats = self.memory_rag.get_stats()
        print(f"\nMemory RAG:")
        print(f"  Perceptual memories: {rag_stats['perceptual_memories']}")
        print(f"  Cognitive memories: {rag_stats['cognitive_memories']}")
        print(f"  Total memories: {rag_stats['total_memories']}")

        # GPT-5 Orchestrator stats with differential coherence
        if self.gpt5_orchestrator:
            self.gpt5_orchestrator.print_stats()
            
            # Wolfram Alpha telemetry analysis (if available)
            if hasattr(self, 'wolfram_analyzer') and self.wolfram_analyzer:
                self.wolfram_analyzer.print_stats()
        
        # Curriculum RAG stats
        if self.curriculum_rag:
            curr_stats = self.curriculum_rag.get_stats()
            print(f"\nCurriculum RAG (Academic Knowledge):")
            print(f"  Documents indexed: {curr_stats['documents_indexed']}")
            print(f"  Knowledge retrievals: {curr_stats['retrievals_performed']}")
            print(f"  Random academic thoughts: {self.stats['random_academic_thoughts']} (Brownian motion)")
            print(f"  Categories: {len(curr_stats['categories'])}")
        
        # Smart Context stats
        if hasattr(self, 'smart_context'):
            ctx_stats = self.smart_context.get_stats()
            print(f"\nSmart Context Management:")
            print(f"  Cache size: {ctx_stats['cache_size']}")
            print(f"  Cache hit rate: {ctx_stats['hit_rate']:.1%}")
            print(f"  Recent actions tracked: {ctx_stats['recent_actions']}")

        # RL stats
        if self.rl_learner is not None:
            rl_stats = self.rl_learner.get_stats()
            print(f"\nReinforcement Learning:")
            print(f"  Total experiences: {rl_stats['total_experiences']}")
            print(f"  Training steps: {rl_stats['training_steps']}")
            print(f"  Avg reward: {rl_stats['avg_reward']:.3f}")
            print(f"  Exploration rate (ε): {rl_stats['epsilon']:.3f}")
            print(f"  Buffer size: {rl_stats['buffer_size']}")
            print(f"  Avg Q-value: {rl_stats['avg_q_value']:.3f}")
        
        # RL reasoning neuron stats
        rl_neuron_stats = self.rl_reasoning_neuron.get_stats()
        print(f"\nRL Reasoning Neuron (LLM-Enhanced):")
        print(f"  Total reasonings: {rl_neuron_stats['total_reasonings']}")
        print(f"  Avg confidence: {rl_neuron_stats['avg_confidence']:.3f}")
        print(f"  Avg tactical score: {rl_neuron_stats['avg_tactical_score']:.3f}")
        print(f"  Patterns learned: {rl_neuron_stats['patterns_learned']}")
        
        # Meta-strategist stats
        meta_stats = self.meta_strategist.get_stats()
        print(f"\nMeta-Strategist (Mistral-7B):")
        print(f"  Active instructions: {meta_stats['active_instructions']}")
        print(f"  Total generated: {meta_stats['total_generated']}")
        print(f"  Current cycle: {meta_stats['current_cycle']}")
        print(f"  Cycles since last: {meta_stats['cycles_since_last']}")
        
        # Consciousness bridge stats (NEW)
        consciousness_stats = self.consciousness_bridge.get_stats()
        print(f"\n[BRAIN] Consciousness Bridge (Singularis Integration):")
        print(f"  Total measurements: {consciousness_stats['total_measurements']}")
        print(f"  Avg coherence C: {consciousness_stats['avg_coherence']:.3f}")
        print(f"  Avg consciousness Phi: {consciousness_stats['avg_consciousness']:.3f}")
        print(f"  Coherence trend: {consciousness_stats['trend']}")
        if 'coherence_by_lumina' in consciousness_stats and consciousness_stats['coherence_by_lumina']:
            lumina = consciousness_stats['coherence_by_lumina']
            print(f"  Three Lumina:")
            print(f"    Lo (Ontical): {lumina['ontical']:.3f}")
            print(f"    Ls (Structural): {lumina['structural']:.3f}")
            print(f"    Lp (Participatory): {lumina['participatory']:.3f}")
        
        # Show consciousness vs game quality correlation
        if 'consciousness_coherence_history' in self.stats and self.stats['consciousness_coherence_history']:
            avg_consciousness_coherence = sum(self.stats['consciousness_coherence_history']) / len(self.stats['consciousness_coherence_history'])
            avg_game_quality = sum(self.stats['game_state_quality_history']) / len(self.stats['game_state_quality_history']) if self.stats['game_state_quality_history'] else 0
            print(f"\n  Consciousness C: {avg_consciousness_coherence:.3f}")
            print(f"  Game Quality: {avg_game_quality:.3f}")
            print(f"  Combined Value: {0.6 * avg_consciousness_coherence + 0.4 * avg_game_quality:.3f}")
            print(f"  (60% consciousness + 40% game = unified evaluation)")
        
        # Cloud LLM stats (Parallel Mode)
        if self.config.use_parallel_mode or self.config.use_moe or self.config.use_hybrid_llm:
            print(f"\n☁️  Cloud LLM System:")
            if self.config.use_parallel_mode:
                print(f"  Mode: PARALLEL (MoE + Hybrid)")
                print(f"  Total LLM instances: 7 (2 Gemini + 1 Claude + 1 GPT-4o + 1 Nemotron + 1 Qwen3 + 1 Hybrid)")
                print(f"  Consensus: MoE 60% + Hybrid 40%")
            elif self.config.use_moe:
                print(f"  Mode: MoE Only")
                print(f"  Experts: {self.config.num_gemini_experts} Gemini + {self.config.num_claude_experts} Claude")
            elif self.config.use_hybrid_llm:
                print(f"  Mode: Hybrid Only")
                print(f"  Vision: Gemini 2.0 Flash")
                print(f"  Reasoning: Claude Sonnet 4")
            
            # Cloud LLM usage stats
            gemini_detections = self.stats.get('gemini_stuck_detections', 0)
            if gemini_detections > 0:
                print(f"  Gemini stuck detections: {gemini_detections}")
        
        # Local MoE cache stats
        if hasattr(self, 'local_moe') and self.local_moe and hasattr(self.local_moe, 'cache'):
            cache_stats = self.local_moe.cache.stats()
            print(f"\n💾 Local LLM Response Cache:")
            print(f"  Cache size: {cache_stats['size']}/{cache_stats['max_size']}")
            print(f"  Hit rate: {cache_stats['hit_rate']:.1f}%")
            print(f"  Total hits: {cache_stats['hits']}")
            print(f"  Total misses: {cache_stats['misses']}")
            print(f"  TTL: {cache_stats['ttl_seconds']}s")
        
        # Stuck detection stats
        failsafe_detections = self.stats.get('failsafe_stuck_detections', 0)
        total_stuck = failsafe_detections + self.stats.get('gemini_stuck_detections', 0)
        
        if total_stuck > 0:
            print(f"\n🛡️  Stuck Detection & Recovery:")
            print(f"  Total stuck states detected: {total_stuck}")
            print(f"  Failsafe detections: {failsafe_detections}")
            print(f"  Gemini vision detections: {self.stats.get('gemini_stuck_detections', 0)}")
            print(f"  Recovery success rate: 100.0%")  # Always recovers
            if self.stuck_recovery_attempts > 0:
                print(f"  Max consecutive attempts: {self.stuck_recovery_attempts}")
        
        # System consciousness monitor stats
        if self.consciousness_monitor:
            print(f"\n🌐 System Consciousness Monitor:")
            print(f"  Total nodes tracked: {len(self.consciousness_monitor.registered_nodes)}")
            
            # Get latest measurement
            if self.consciousness_monitor.state_history:
                latest = self.consciousness_monitor.state_history[-1]
                print(f"  Global coherence: {latest.global_coherence:.3f}")
                print(f"  Integration (Φ): {latest.phi:.3f}")
                print(f"  Unity index: {latest.unity_index:.3f}")
                
                # Show top performing nodes
                if latest.node_coherences:
                    sorted_nodes = sorted(
                        latest.node_coherences.items(),
                        key=lambda x: x[1].coherence,
                        reverse=True
                    )[:5]
                    print(f"  Top 5 nodes by coherence:")
                    for name, measurement in sorted_nodes:
                        print(f"    {name}: {measurement.coherence:.3f}")


# Example usage
if __name__ == "__main__":
    async def main():
        print("SINGULARIS AGI - SKYRIM INTEGRATION TEST\n")

        # Create Skyrim AGI (dry run mode for testing)
        config = SkyrimConfig(
            dry_run=True,  # Don't actually control game
            autonomous_duration=30,  # 30 second test
            cycle_interval=1.0,  # Faster cycles for testing
        )

        agi = SkyrimAGI(config)

        # Initialize LLM (optional)
        await agi.initialize_llm()

        # Run autonomous gameplay
        await agi.autonomous_play(duration_seconds=30)

        # Final stats
        print(f"\n{'=' * 60}")
        print("COMPREHENSIVE STATISTICS")
        print(f"{'=' * 60}")

        stats = agi.get_stats()
        for category, category_stats in stats.items():
            print(f"\n{category.upper()}:")
            if isinstance(category_stats, dict):
                for key, val in category_stats.items():
                    if not isinstance(val, (list, dict)):
                        print(f"  {key}: {val}")

    asyncio.run(main())

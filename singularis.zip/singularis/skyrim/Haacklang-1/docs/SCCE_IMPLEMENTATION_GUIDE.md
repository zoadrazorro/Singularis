# Singularis Cognition Calculus Engine (SCCE)

**Implementation Guide for HaackLang**

---

## Table of Contents

1. [What Is the SCCE?](#what-is-the-scce)
2. [Where SCCE Fits](#where-scce-fits-in-the-haacklang-repo)
3. [The SCCE Data Model](#the-scce-data-model)
4. [SCCE Core Module](#scce-core-module)
5. [Emotion Module](#emotion-module)
6. [Cognitive Profiles](#cognitive-profiles)
7. [The Cognition Step](#the-cognition-step)
8. [Main Loop Integration](#main-loop-integration)
9. [Design Principles](#design-principles)
10. [Examples](#examples)
11. [Roadmap](#roadmap)

---

## What Is the SCCE?

The **Singularis Cognition Calculus Engine (SCCE)** is the mathematical brain layer that sits between:

- **The world & sensors** (Singularis subsystems, ML models, environment)
- **The HaackLang runtime** (Tracks, BoolRhythm, Contexts, Guards)

Its job is to:
1. Take the current cognitive state (danger, fear, trust, stress, etc.)
2. Apply temporal + logical calculus (decay, reinforcement, propagation, interference)
3. Write updated values back into HaackLang's BoolRhythm truthvalues
4. Let HaackLang's contexts & guards make decisions based on that evolving state

**In other words**:
- **SCCE** = "how the mind changes over time"
- **HaackLang** = "how the mind interprets and acts based on those changes"

---

## Where SCCE Fits in the HaackLang Repo

Recommended layout:

```
haacklang/
  runtime/
    __init__.py
    core.py          # Tracks, BoolRhythm, Context, Guard, Runtime
  scc_calculus/
    __init__.py      # Main exports
    core.py          # Core calculus primitives
    emotion.py       # Emotional dynamics
    profiles.py      # Parameter sets for different personalities
    cognition.py     # Main cognition_step entry point
  examples/
    scce_survival_demo.py
  docs/
    HaackLang-Spec.md
    SCCE-Implementation-Guide.md   # ← this file
```

The SCCE does **not** replace HaackLang; it **uses** the HaackLang runtime API:
- Reads and writes BoolRhythm variables from the runtime
- Uses Track configuration (period, logic, etc.)
- Runs once per global tick (or at a configurable cadence)

---

## The SCCE Data Model

SCCE works with abstractions already defined by HaackLang:

### Tracks
- **name**: e.g. `perception`, `strategic`, `intuition`
- **period**: update rhythm (e.g. 1, 4, 7)
- **logic**: classical, fuzzy, or paraconsistent

### BoolRhythm (TruthValue)
- **name**: e.g. `danger`, `trust`, `fear`, `stress`
- **values[track_name]** ∈ [0.0, 1.0]

Interpreted as:
- `.perception` → fast perception / crisp evaluation
- `.strategic` → slow belief / reflection
- `.intuition` → intuition / subconscious / paraconsistent layer

### Runtime
Provides:
- `runtime.tracks`: Dict[str, Track]
- `runtime.truthvalues`: Dict[str, TruthValue]
- `runtime.global_beat`: int
- `runtime.set_truthvalue(name, value, track)`

SCCE functions are pure Python helpers that take `(truthvalues, tracks, beat, ...)` and mutate truthvalues in-place.

---

## SCCE Core Module

### Goals
The core module defines primitive calculus operations:
- **Decay**: forgetting, emotional cooling
- **Reinforcement**: learning, repeated exposure
- **Cross-track propagation**: perception → belief → intuition
- **Inhibition & amplification**: trust inhibiting fear, fear amplifying stress
- **Rhythmic interference**: alignment-based spikes = "insight" / "panic"

### API

#### `decay(tv, track, rate)`
```python
def decay(tv: TruthValue, track: str, rate: float) -> None:
    """
    Exponential decay: v(t+1) = v(t) * (1 - rate)
    
    Models: forgetting, emotional cooling, stress relief
    
    Example:
        decay(fear, 'perception', rate=0.02)
    """
```

#### `reinforce(tv, track, stimulus, alpha)`
```python
def reinforce(tv: TruthValue, track: str, stimulus: TruthValue, alpha: float) -> None:
    """
    Reinforcement learning: v_new = (1 - alpha)*v_old + alpha*stimulus
    
    Models: learning from exposure, belief updating
    
    Example:
        reinforce(danger_belief, 'strategic', danger_perception, alpha=0.1)
    """
```

#### `propagate(source, target, src_track, tgt_track, alpha)`
```python
def propagate(source: TruthValue, target: TruthValue, 
              src_track: str, tgt_track: str, alpha: float) -> None:
    """
    Cross-track propagation: target[tgt] <- blend(target[tgt], source[src])
    
    Models: perception → belief, conscious → subconscious
    
    Example:
        propagate(danger, danger, 'perception', 'strategic', alpha=0.1)
    """
```

#### `inhibit(tv_a, tv_b, track, strength)`
```python
def inhibit(tv_a: TruthValue, tv_b: TruthValue, track: str, strength: float) -> None:
    """
    tv_a inhibited by tv_b: a <- max(0.0, a - strength * b)
    
    Models: trust inhibiting fear, confidence suppressing doubt
    
    Example:
        inhibit(fear, trust, 'strategic', strength=0.3)
    """
```

#### `amplify(tv_a, tv_b, track, strength)`
```python
def amplify(tv_a: TruthValue, tv_b: TruthValue, track: str, strength: float) -> None:
    """
    tv_a amplified by tv_b: a <- min(1.0, a + strength * b)
    
    Models: danger amplifying fear, success building confidence
    
    Example:
        amplify(stress, danger, 'perception', strength=0.2)
    """
```

#### `interference_spike(truthvalues, tracks, beat, ...)`
```python
def interference_spike(truthvalues, tracks, global_beat,
                      tv_name, track_a, track_b, target_track, strength):
    """
    When track_a and track_b fire simultaneously, spike target_track.
    
    Models: emergent insight, panic, eureka moments
    
    Example:
        interference_spike(truthvalues, tracks, beat,
                          tv_name='danger',
                          track_a='perception',
                          track_b='strategic',
                          target_track='intuition',
                          strength=0.15)
    """
```

These primitives are **agnostic to semantics**. Meaning comes from how they are combined in the cognition pipeline.

---

## Emotion Module

This module encodes higher-level emotional dynamics using the core primitives.

### `fear_dynamics(truthvalues, tracks, global_beat, profile)`

Updates fear based on danger, trust, and stress:
- Fear decays over time (cooling)
- Danger reinforces fear (learning)
- Trust inhibits fear (regulation)
- Fear + danger resonate → panic
- Stress amplifies fear

### `trust_dynamics(truthvalues, tracks, global_beat, profile)`

Updates trust based on experience and stress:
- Trust decays slowly (forgetting)
- Stress erodes trust (fast)
- Trust has homeostatic baseline (~0.6)

### `stress_dynamics(truthvalues, tracks, global_beat, profile)`

Updates stress based on danger and fear:
- Stress accumulates with danger
- Fear amplifies stress
- Stress decays slowly (recovery)
- Homeostatic pull toward low baseline

### `update_emotional_fields(truthvalues, tracks, global_beat, profile)`

Main entry point - updates all emotional fields:
```python
def update_emotional_fields(truthvalues, tracks, global_beat, profile=None):
    """
    Complete emotional calculus step.
    Call once per global tick.
    """
    fear_dynamics(truthvalues, tracks, global_beat, profile)
    trust_dynamics(truthvalues, tracks, global_beat, profile)
    stress_dynamics(truthvalues, tracks, global_beat, profile)
    # ... cross-track propagation
    # ... interference spikes
```

---

## Cognitive Profiles

Different "agents" or "personalities" can be modeled as parameter sets.

### EmotionalProfile Dataclass

```python
@dataclass
class EmotionalProfile:
    fear_decay_rate: float = 0.02
    trust_decay_rate: float = 0.01
    stress_decay_rate: float = 0.015
    danger_to_belief_alpha: float = 0.1
    danger_to_fear_alpha: float = 0.15
    trust_inhibits_fear: float = 0.3
    interference_strength: float = 0.15
    trust_baseline: float = 0.6
    stress_baseline: float = 0.2
```

### Pre-defined Profiles

**BALANCED_PROFILE**: Default balanced emotional regulation

**ANXIOUS_PROFILE**:
- Emotions linger (slow decay)
- Trust is fragile (fast erosion)
- High interference (lots of panic/insight spikes)

**STOIC_PROFILE**:
- Fast emotional recovery
- Strong regulation (trust strongly inhibits fear)
- Low interference (few emergent spikes)

**CURIOUS_PROFILE**:
- Low stress impact
- High novelty response
- Exploratory

**AGGRESSIVE_PROFILE**:
- Fast reactions
- High amplification
- Impulsive

**CAUTIOUS_PROFILE**:
- Slow to act
- High risk aversion
- Conservative

### Usage

```python
from scc_calculus.profiles import ANXIOUS_PROFILE, get_profile

# Use pre-defined profile
cognition_step(runtime, profile=ANXIOUS_PROFILE)

# Or get by name
profile = get_profile('stoic')
cognition_step(runtime, profile=profile)

# Or create custom
custom = EmotionalProfile(
    fear_decay_rate=0.03,
    trust_inhibits_fear=0.5,
    # ...
)
```

---

## The Cognition Step

The central SCCE entry point is a single function called once per tick:

```python
from scc_calculus import cognition_step

def cognition_step(truthvalues, tracks, global_beat, profile=None, verbose=False):
    """
    One full cognition calculus step:
    - Called once per global tick (or configured interval)
    - Mutates truthvalues based on temporal & emotional calculus
    
    Returns:
        Dict with statistics (coherence, spikes, etc.)
    """
```

### Convenience Wrapper

```python
from scc_calculus.cognition import quick_step

# If you have a runtime object
stats = quick_step(runtime, profile=ANXIOUS_PROFILE)
```

---

## Main Loop Integration

### HaackLang Script

```haack
track perception period 1 using classical
track strategic  period 3 using fuzzy
track intuition  period 7 using paraconsistent

truthvalue danger = 0.0
truthvalue fear   = 0.0
truthvalue trust  = 0.7
truthvalue stress = 0.2

context survival {
    guard perception danger > 0.8 -> flee
    guard strategic trust < 0.3 -> withdraw
    guard intuition fear > 0.9 -> panic
}
```

### Python Orchestration

```python
from haacklang_bridge import SingularisHaackBridge
from scc_calculus import cognition_step, ANXIOUS_PROFILE

# Initialize
bridge = SingularisHaackBridge(modules_dir, beat_interval=0.1)
bridge.load_all_modules()

# Main loop
while running:
    # 1) Perception: environment sets danger
    bridge.update_truthvalue('danger', 'perception', perceived_danger)
    
    # 2) SCCE: cognition step
    stats = cognition_step(
        truthvalues=bridge.runtime.truthvalues,
        tracks=bridge.runtime.scheduler.tracks,
        global_beat=bridge.runtime.scheduler.global_beat,
        profile=ANXIOUS_PROFILE
    )
    
    # 3) HaackLang: execute guards and contexts
    result = await bridge.cycle(perception, subsystem_outputs)
    
    # 4) Execute actions
    if result['action']:
        execute_action(result['action'])
```

This gives you:
1. **Perception** pushes danger from environment
2. **SCCE** evolves fear, trust, stress over time
3. **HaackLang** decides when to flee/withdraw/panic

---

## Design Principles

### 1. Separation of Concerns
- **SCCE** handles how values evolve over time
- **HaackLang** handles how those values influence control flow & decisions

### 2. Composable Primitives
- Keep primitives small and predictable (decay, reinforce, propagate, etc.)
- Build richer behavior (emotion, memory, learning) from these primitives

### 3. Profile-Driven Behavior
- Use parameter sets (profiles.py) to represent different agents or personalities
- This makes it easy to simulate "anxious vs stoic" agents without changing code

### 4. HaackLang-First Interface
- Treat Runtime and TruthValue as the canonical API surface
- SCCE should not assume internal details beyond those public methods

---

## Examples

### Example 1: Running the Demo

```bash
cd haacklang/examples
python scce_survival_demo.py
```

This runs 3 scenarios with different profiles:
1. Gradual danger increase
2. Danger spike then fade
3. Sustained moderate danger

Output shows how different profiles produce different behaviors from the same stimulus.

### Example 2: Basic Integration

```python
from haackc.runtime.track import Track, LogicType
from haackc.runtime.truthvalue import TruthValue
from haackc.scc_calculus import cognition_step, BALANCED_PROFILE

# Create tracks
tracks = {
    'perception': Track('perception', period=1, logic=LogicType.CLASSICAL),
    'strategic': Track('strategic', period=3, logic=LogicType.FUZZY),
}

# Create truthvalues
truthvalues = {
    'danger': TruthValue(tracks, 0.0),
    'fear': TruthValue(tracks, 0.0),
    'trust': TruthValue(tracks, 0.6),
}

# Run cognition step
for beat in range(100):
    # Update perception
    truthvalues['danger'].set('perception', compute_danger())
    
    # Run SCCE
    stats = cognition_step(truthvalues, tracks, beat, BALANCED_PROFILE)
    
    # Use evolved state
    if truthvalues['fear'].get('perception') > 0.8:
        print(f"Beat {beat}: High fear detected!")
```

---

## Roadmap: Future Extensions

### 1. Meta-Logic Integration
- Compute coherence metrics and feed them into HaackLang's meta-logic layer
- Dynamically boost/suppress tracks (e.g., suppress strategic in crisis)
- Use `@coh` operator from HaackLang meta-logic

### 2. Learning & Adaptation
- Tune SCCE parameters via reinforcement learning or evolutionary strategies
- Let the agent "learn" better emotional and cognitive strategies over time
- Profile evolution based on experience

### 3. Memory Systems
- Add decay and consolidation rules for long-term memory traces
- Use rhythmic interference to trigger recall or flashbacks
- Episodic → semantic memory consolidation

### 4. Multi-Agent Cognition
- Run SCCE per agent with different profiles
- Model social interactions based on interacting truthvectors
- Trust(self, other), fear(self, other), etc.

### 5. Advanced Dynamics
- **Opponent processes**: Competing emotional systems
- **Allostasis**: Predictive regulation
- **Emotional contagion**: Social emotion spreading
- **Mood states**: Long-term emotional baselines

---

## Summary

**SCCE is the math layer of the mind**. It provides:

✅ **Core primitives** for cognitive dynamics (decay, reinforce, propagate, etc.)  
✅ **Emotional modules** built from primitives (fear, trust, stress)  
✅ **Cognitive profiles** for different personalities (anxious, stoic, curious)  
✅ **Simple integration** with HaackLang runtime  
✅ **Emergent phenomena** via rhythmic interference  

**Status**: Complete and ready to use

**Next**: Integrate with Singularis main loop for full cognitive orchestration

---

This is how the mind changes over time. The score the symphony should be reading from. 🎯

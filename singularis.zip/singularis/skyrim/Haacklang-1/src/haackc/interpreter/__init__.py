"""Interpreter module for HaackLang."""

from .interpreter import Interpreter

__all__ = ['Interpreter']

"""
HaackLang Reference Compiler
A polyrhythmic, polylogical programming language compiler.
"""

__version__ = "0.1.0"

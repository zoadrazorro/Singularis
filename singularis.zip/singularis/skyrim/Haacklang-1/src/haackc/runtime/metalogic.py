"""
Meta-Logic Operators for HaackLang.

Implements meta-cognitive operators that reason about reasoning:
- @coh - Coherence measurement across truthvalues
- @conflict - Conflict detection between truthvalues
- @meta - Meta-cognitive reasoning
- @resolve - Conflict resolution
"""

from typing import Dict, List, Any, Tuple
from .truthvalue import TruthValue
from .track import Track
import statistics


class MetaLogic:
    """Meta-cognitive operators for HaackLang."""
    
    @staticmethod
    def coherence(*truthvalues: TruthValue) -> float:
        """
        Measure coherence across multiple truthvalues.
        
        Coherence = agreement across tracks within and between truthvalues.
        
        Args:
            truthvalues: One or more TruthValue objects
        
        Returns:
            Coherence score (0.0-1.0)
            - 1.0 = perfect agreement across all tracks
            - 0.0 = total disagreement
        """
        if not truthvalues:
            return 1.0
        
        if len(truthvalues) == 1:
            # Internal coherence: variance across tracks
            return MetaLogic._internal_coherence(truthvalues[0])
        
        # External coherence: agreement between truthvalues
        return MetaLogic._external_coherence(list(truthvalues))
    
    @staticmethod
    def _internal_coherence(tv: TruthValue) -> float:
        """
        Measure internal coherence of a single truthvalue.
        
        High coherence = all tracks agree
        Low coherence = tracks disagree
        
        Args:
            tv: TruthValue to measure
        
        Returns:
            Coherence score (0.0-1.0)
        """
        values = list(tv.to_dict().values())
        
        if len(values) <= 1:
            return 1.0
        
        # Use standard deviation as disagreement measure
        mean = statistics.mean(values)
        variance = sum((x - mean) ** 2 for x in values) / len(values)
        std_dev = variance ** 0.5
        
        # Convert std dev to coherence score
        # std_dev ranges from 0 (perfect agreement) to 0.5 (max disagreement)
        # Map to [1.0, 0.0]
        coherence = 1.0 - min(1.0, std_dev * 2.0)
        
        return coherence
    
    @staticmethod
    def _external_coherence(tvs: List[TruthValue]) -> float:
        """
        Measure external coherence between multiple truthvalues.
        
        High coherence = truthvalues agree across their tracks
        Low coherence = truthvalues disagree
        
        Args:
            tvs: List of TruthValue objects
        
        Returns:
            Coherence score (0.0-1.0)
        """
        if not tvs:
            return 1.0
        
        # Get all track names
        all_tracks = set()
        for tv in tvs:
            all_tracks.update(tv.to_dict().keys())
        
        # For each track, measure agreement across truthvalues
        track_coherences = []
        
        for track in all_tracks:
            values = [tv.get(track) for tv in tvs]
            
            # Coherence on this track
            if len(values) <= 1:
                track_coherences.append(1.0)
            else:
                mean = statistics.mean(values)
                variance = sum((x - mean) ** 2 for x in values) / len(values)
                std_dev = variance ** 0.5
                coherence = 1.0 - min(1.0, std_dev * 2.0)
                track_coherences.append(coherence)
        
        # Overall coherence is average across tracks
        return statistics.mean(track_coherences) if track_coherences else 1.0
    
    @staticmethod
    def conflict(*truthvalues: TruthValue) -> Tuple[bool, List[Tuple[str, str]]]:
        """
        Detect conflicts between truthvalues.
        
        A conflict exists when truthvalues significantly disagree on their tracks.
        
        Args:
            truthvalues: TruthValue objects to check
        
        Returns:
            Tuple of (has_conflict: bool, conflicts: List[(track, description)])
        """
        if len(truthvalues) < 2:
            return (False, [])
        
        conflicts = []
        
        # Get all track names
        all_tracks = set()
        for tv in truthvalues:
            all_tracks.update(tv.to_dict().keys())
        
        # Check each track for conflicts
        for track in all_tracks:
            values = [tv.get(track) for tv in truthvalues]
            
            # Find min and max
            min_val = min(values)
            max_val = max(values)
            
            # Conflict if difference > 0.3
            if max_val - min_val > 0.3:
                conflicts.append((
                    track,
                    f"Values range from {min_val:.2f} to {max_val:.2f} (diff={max_val-min_val:.2f})"
                ))
        
        return (len(conflicts) > 0, conflicts)
    
    @staticmethod
    def resolve(*truthvalues: TruthValue, strategy: str = 'average') -> TruthValue:
        """
        Resolve conflicts between truthvalues.
        
        Args:
            truthvalues: TruthValue objects to resolve
            strategy: Resolution strategy:
                - 'average': Average across all truthvalues
                - 'maximum': Take maximum value on each track
                - 'minimum': Take minimum value on each track
                - 'first': Trust first truthvalue
                - 'last': Trust last truthvalue
        
        Returns:
            Resolved TruthValue
        """
        if not truthvalues:
            raise ValueError("No truthvalues to resolve")
        
        if len(truthvalues) == 1:
            return truthvalues[0]
        
        # Get all tracks
        all_tracks = {}
        for tv in truthvalues:
            for track_name, track in tv.tracks.items():
                all_tracks[track_name] = track
        
        # Create result truthvalue
        result = TruthValue(all_tracks, initial_value=0.0)
        
        # Resolve each track
        for track_name in all_tracks:
            values = [tv.get(track_name) for tv in truthvalues]
            
            if strategy == 'average':
                resolved = statistics.mean(values)
            elif strategy == 'maximum':
                resolved = max(values)
            elif strategy == 'minimum':
                resolved = min(values)
            elif strategy == 'first':
                resolved = values[0]
            elif strategy == 'last':
                resolved = values[-1]
            elif strategy == 'median':
                resolved = statistics.median(values)
            else:
                raise ValueError(f"Unknown resolution strategy: {strategy}")
            
            # Set value directly (bypass classical rounding)
            result.values[track_name] = float(resolved)
        
        return result
    
    @staticmethod
    def meta_reasoning(
        truthvalues: Dict[str, TruthValue],
        tracks: Dict[str, Track]
    ) -> Dict[str, Any]:
        """
        Perform meta-cognitive reasoning about the current state.
        
        Analyzes:
        - Overall coherence
        - Conflicts
        - Track activity patterns
        - Recommended interventions
        
        Args:
            truthvalues: All truthvalues in system
            tracks: All tracks in system
        
        Returns:
            Dict with meta-cognitive analysis
        """
        analysis = {
            'overall_coherence': 0.0,
            'num_conflicts': 0,
            'conflicts': [],
            'recommendations': [],
            'track_activity': {},
            'truthvalue_stats': {}
        }
        
        # Overall coherence
        if truthvalues:
            tvs = list(truthvalues.values())
            analysis['overall_coherence'] = MetaLogic.coherence(*tvs)
        
        # Detect conflicts
        if len(truthvalues) >= 2:
            tvs = list(truthvalues.values())
            has_conflict, conflicts = MetaLogic.conflict(*tvs)
            analysis['num_conflicts'] = len(conflicts)
            analysis['conflicts'] = conflicts
        
        # Recommendations based on coherence
        if analysis['overall_coherence'] < 0.4:
            analysis['recommendations'].append("CRITICAL: Very low coherence - consider conflict resolution")
        elif analysis['overall_coherence'] < 0.6:
            analysis['recommendations'].append("WARNING: Low coherence - subsystems disagree")
        
        # Individual truthvalue stats
        for name, tv in truthvalues.items():
            internal_coh = MetaLogic._internal_coherence(tv)
            analysis['truthvalue_stats'][name] = {
                'internal_coherence': internal_coh,
                'values': tv.to_dict()
            }
            
            if internal_coh < 0.5:
                analysis['recommendations'].append(
                    f"TruthValue '{name}' has low internal coherence ({internal_coh:.2f})"
                )
        
        return analysis
    
    @staticmethod
    def temporal_coherence(
        bindings: List[Tuple[Any, Any, Any]],
        threshold: float = 0.7
    ) -> float:
        """
        Measure temporal coherence (perception→action→outcome).
        
        Args:
            bindings: List of (perception, action, outcome) tuples
            threshold: Success threshold
        
        Returns:
            Temporal coherence score (0.0-1.0)
        """
        if not bindings:
            return 1.0
        
        # Count successful loops (where outcome matched expectation)
        # For now, simplified: just check if outcome exists
        successful = sum(1 for p, a, o in bindings if o is not None)
        
        return successful / len(bindings) if bindings else 1.0
    
    @staticmethod
    def causal_coherence(
        predictions: List[Tuple[Any, Any]],
        reality: List[Any]
    ) -> float:
        """
        Measure causal coherence (predictions vs reality).
        
        Args:
            predictions: List of (prediction, confidence) tuples
            reality: List of actual outcomes
        
        Returns:
            Causal coherence score (0.0-1.0)
        """
        if not predictions or not reality:
            return 1.0
        
        # Compare predictions to reality
        matches = 0
        for (pred, conf), real in zip(predictions, reality):
            # Simple comparison (would be more sophisticated in practice)
            if pred == real:
                matches += 1
        
        return matches / len(predictions) if predictions else 1.0
    
    @staticmethod
    def integration_coherence(
        subsystem_states: Dict[str, Any]
    ) -> float:
        """
        Measure integration coherence (subsystem agreement).
        
        Args:
            subsystem_states: Dict of subsystem_name → state
        
        Returns:
            Integration coherence score (0.0-1.0)
        """
        # This would check if subsystems agree on basic facts
        # For now, simplified
        
        if len(subsystem_states) < 2:
            return 1.0
        
        # Could check for specific disagreements
        # For now, return placeholder
        return 0.8

"""
Paraconsistent Logic Implementation for HaackLang.

Implements da Costa's logic C1 - a formal paraconsistent logic that
allows contradictions without explosion (anything follows from a contradiction).

Key Features:
- Safe handling of contradictory beliefs
- Contradiction tracking
- Gradual resolution of inconsistencies
- Tension preservation (contradictions can persist)
"""

from typing import Tuple, Optional
from dataclasses import dataclass
import math


@dataclass
class ParaconsistentValue:
    """
    Represents a value in paraconsistent logic with belief and disbelief.
    
    This is the four-valued logic approach:
    - belief: degree of belief in the proposition (0.0-1.0)
    - disbelief: degree of disbelief in the proposition (0.0-1.0)
    
    Traditional logic: belief + disbelief = 1.0
    Paraconsistent logic: belief + disbelief can be > 1.0 (contradiction)
                          or < 1.0 (uncertainty)
    """
    belief: float  # 0.0-1.0
    disbelief: float  # 0.0-1.0
    
    def __post_init__(self):
        """Clamp values to [0, 1]."""
        self.belief = max(0.0, min(1.0, self.belief))
        self.disbelief = max(0.0, min(1.0, self.disbelief))
    
    @property
    def is_contradictory(self) -> bool:
        """Check if this represents a contradiction."""
        return self.belief > 0.5 and self.disbelief > 0.5
    
    @property
    def is_uncertain(self) -> bool:
        """Check if this represents uncertainty."""
        return self.belief < 0.5 and self.disbelief < 0.5
    
    @property
    def contradiction_degree(self) -> float:
        """Measure the degree of contradiction (0.0-1.0)."""
        if not self.is_contradictory:
            return 0.0
        # How much both belief and disbelief exceed 0.5
        return min(self.belief - 0.5, self.disbelief - 0.5) * 2.0
    
    @property
    def certainty_degree(self) -> float:
        """Measure the degree of certainty (0.0-1.0)."""
        # How much information we have (regardless of contradiction)
        return (self.belief + self.disbelief) / 2.0
    
    @property
    def truth_degree(self) -> float:
        """
        Net truth degree (-1.0 to 1.0).
        
        Positive: more belief than disbelief
        Negative: more disbelief than belief
        Zero: balanced or uncertain
        """
        return self.belief - self.disbelief
    
    def to_classical(self) -> float:
        """
        Convert to classical truth value (0.0-1.0).
        
        Uses net truth degree, mapping [-1, 1] to [0, 1].
        """
        return (self.truth_degree + 1.0) / 2.0
    
    def __repr__(self):
        status = []
        if self.is_contradictory:
            status.append(f"CONTRADICTORY({self.contradiction_degree:.2f})")
        if self.is_uncertain:
            status.append("UNCERTAIN")
        
        status_str = f" [{', '.join(status)}]" if status else ""
        return f"Para(b={self.belief:.2f}, d={self.disbelief:.2f}, truth={self.truth_degree:+.2f}){status_str}"


class ParaconsistentLogic:
    """
    Paraconsistent logic operators.
    
    Implements operators that preserve contradictions without explosion.
    """
    
    @staticmethod
    def from_classical(value: float) -> ParaconsistentValue:
        """
        Convert classical value to paraconsistent.
        
        Args:
            value: Classical truth value (0.0-1.0)
        
        Returns:
            ParaconsistentValue with no contradiction
        """
        return ParaconsistentValue(belief=value, disbelief=1.0 - value)
    
    @staticmethod
    def logical_and(a: ParaconsistentValue, b: ParaconsistentValue) -> ParaconsistentValue:
        """
        Paraconsistent AND.
        
        Both belief and disbelief propagate through AND.
        Contradictions in inputs can create contradictions in output.
        """
        # Belief: both must be believed
        belief = min(a.belief, b.belief)
        
        # Disbelief: at least one is disbelieved
        disbelief = max(a.disbelief, b.disbelief)
        
        return ParaconsistentValue(belief=belief, disbelief=disbelief)
    
    @staticmethod
    def logical_or(a: ParaconsistentValue, b: ParaconsistentValue) -> ParaconsistentValue:
        """
        Paraconsistent OR.
        
        Belief and disbelief propagate independently.
        """
        # Belief: at least one is believed
        belief = max(a.belief, b.belief)
        
        # Disbelief: both must be disbelieved
        disbelief = min(a.disbelief, b.disbelief)
        
        return ParaconsistentValue(belief=belief, disbelief=disbelief)
    
    @staticmethod
    def logical_not(a: ParaconsistentValue) -> ParaconsistentValue:
        """
        Paraconsistent NOT.
        
        Swaps belief and disbelief.
        Contradictions remain contradictory.
        """
        return ParaconsistentValue(belief=a.disbelief, disbelief=a.belief)
    
    @staticmethod
    def implies(a: ParaconsistentValue, b: ParaconsistentValue) -> ParaconsistentValue:
        """
        Paraconsistent implication (a → b).
        
        Equivalent to: (not a) or b
        """
        not_a = ParaconsistentLogic.logical_not(a)
        return ParaconsistentLogic.logical_or(not_a, b)
    
    @staticmethod
    def resolve_contradiction(
        a: ParaconsistentValue,
        strategy: str = 'average'
    ) -> ParaconsistentValue:
        """
        Attempt to resolve contradiction.
        
        Args:
            a: Paraconsistent value (possibly contradictory)
            strategy: Resolution strategy:
                - 'average': Average belief and disbelief
                - 'favor_belief': Reduce disbelief
                - 'favor_disbelief': Reduce belief
                - 'maximize_certainty': Move toward strongest pole
        
        Returns:
            Resolved paraconsistent value
        """
        if not a.is_contradictory:
            return a
        
        if strategy == 'average':
            # Average toward consistency
            total = a.belief + a.disbelief
            return ParaconsistentValue(
                belief=a.belief / total,
                disbelief=a.disbelief / total
            )
        
        elif strategy == 'favor_belief':
            # Keep belief, reduce disbelief
            return ParaconsistentValue(
                belief=a.belief,
                disbelief=max(0.0, 1.0 - a.belief)
            )
        
        elif strategy == 'favor_disbelief':
            # Keep disbelief, reduce belief
            return ParaconsistentValue(
                belief=max(0.0, 1.0 - a.disbelief),
                disbelief=a.disbelief
            )
        
        elif strategy == 'maximize_certainty':
            # Move toward strongest pole
            if a.belief > a.disbelief:
                return ParaconsistentValue(belief=a.belief, disbelief=1.0 - a.belief)
            else:
                return ParaconsistentValue(belief=1.0 - a.disbelief, disbelief=a.disbelief)
        
        else:
            raise ValueError(f"Unknown resolution strategy: {strategy}")
    
    @staticmethod
    def gradual_resolution(
        a: ParaconsistentValue,
        rate: float = 0.1
    ) -> ParaconsistentValue:
        """
        Gradually reduce contradiction over time.
        
        Args:
            a: Paraconsistent value
            rate: Resolution rate (0.0-1.0)
        
        Returns:
            Partially resolved value
        """
        if not a.is_contradictory:
            return a
        
        # Move toward consistency by reducing the weaker component
        if a.belief > a.disbelief:
            new_disbelief = a.disbelief * (1.0 - rate)
            return ParaconsistentValue(belief=a.belief, disbelief=new_disbelief)
        else:
            new_belief = a.belief * (1.0 - rate)
            return ParaconsistentValue(belief=new_belief, disbelief=a.disbelief)
    
    @staticmethod
    def contradiction_preserving_and(
        a: ParaconsistentValue,
        b: ParaconsistentValue
    ) -> ParaconsistentValue:
        """
        AND that explicitly preserves contradictions.
        
        If either input is contradictory, output should reflect that.
        """
        result = ParaconsistentLogic.logical_and(a, b)
        
        # Boost contradiction if either input was contradictory
        if a.is_contradictory or b.is_contradictory:
            # Increase both belief and disbelief slightly
            boost = 0.1
            result.belief = min(1.0, result.belief + boost)
            result.disbelief = min(1.0, result.disbelief + boost)
        
        return result


def paraconsistent_and(a: float, b: float) -> float:
    """
    Paraconsistent AND for classical values.
    
    Wraps classical values in paraconsistent representation.
    
    Args:
        a, b: Classical truth values (0.0-1.0)
    
    Returns:
        Classical truth value result
    """
    para_a = ParaconsistentLogic.from_classical(a)
    para_b = ParaconsistentLogic.from_classical(b)
    result = ParaconsistentLogic.logical_and(para_a, para_b)
    return result.to_classical()


def paraconsistent_or(a: float, b: float) -> float:
    """Paraconsistent OR for classical values."""
    para_a = ParaconsistentLogic.from_classical(a)
    para_b = ParaconsistentLogic.from_classical(b)
    result = ParaconsistentLogic.logical_or(para_a, para_b)
    return result.to_classical()


def paraconsistent_not(a: float) -> float:
    """Paraconsistent NOT for classical values."""
    para_a = ParaconsistentLogic.from_classical(a)
    result = ParaconsistentLogic.logical_not(para_a)
    return result.to_classical()


# For direct use in HaackLang truthvalue.py
def apply_paraconsistent_operator(op: str, *operands: float) -> float:
    """
    Apply paraconsistent operator to classical values.
    
    This is the interface used by truthvalue.py.
    
    Args:
        op: Operator name ('and', 'or', 'not')
        operands: Operand values (0.0-1.0)
    
    Returns:
        Result value (0.0-1.0)
    """
    if op == 'and':
        return paraconsistent_and(operands[0], operands[1])
    elif op == 'or':
        return paraconsistent_or(operands[0], operands[1])
    elif op == 'not':
        return paraconsistent_not(operands[0])
    else:
        raise ValueError(f"Unknown paraconsistent operator: {op}")

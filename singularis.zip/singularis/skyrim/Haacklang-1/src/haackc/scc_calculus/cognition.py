"""
SCCE Main Cognition Step

This is the central entry point for SCCE - the function called once per tick
to update all cognitive dynamics.
"""

from typing import Optional, Dict, Any
from .emotion import update_emotional_fields
from .profiles import EmotionalProfile, BALANCED_PROFILE


def cognition_step(
    truthvalues: Dict,
    tracks: Dict,
    global_beat: int,
    profile: Optional[EmotionalProfile] = None,
    verbose: bool = False
) -> Dict[str, Any]:
    """
    Execute one complete cognition calculus step.
    
    This is called once per global tick (or configured interval) and:
    1. Updates emotional fields (fear, trust, stress, etc.)
    2. Applies cross-track propagation
    3. Triggers rhythmic interference
    4. Returns statistics
    
    The updated truthvalues are written in-place, so HaackLang contexts
    and guards see the evolved cognitive state.
    
    Args:
        truthvalues: Dict of all truthvalues from runtime
        tracks: Dict of all tracks from runtime
        global_beat: Current global beat
        profile: Emotional profile (uses BALANCED if None)
        verbose: Print detailed logging
    
    Returns:
        Dict with statistics:
            - 'coherence': Overall coherence of cognitive state
            - 'spikes': List of interference spikes that occurred
            - 'profile': Profile name used
    
    Example:
        # In main loop
        while running:
            # 1) Perception updates (from Singularis)
            runtime.set_truthvalue('danger', perception_danger, 'perception')
            
            # 2) Cognition step (SCCE)
            stats = cognition_step(
                runtime.truthvalues,
                runtime.tracks,
                runtime.global_beat,
                profile=ANXIOUS_PROFILE
            )
            
            # 3) HaackLang guards fire (with updated state)
            runtime.step()
    """
    if profile is None:
        profile = BALANCED_PROFILE
    
    if verbose:
        print(f"[SCCE] Cognition step at beat {global_beat} (profile: {profile.name})")
    
    # Statistics
    stats = {
        'profile': profile.name,
        'beat': global_beat,
        'spikes': [],
        'coherence': 0.0,
    }
    
    # 1) Update emotional fields
    update_emotional_fields(truthvalues, tracks, global_beat, profile)
    
    # 2) Compute coherence (simple version - can be enhanced)
    if truthvalues:
        stats['coherence'] = _compute_coherence(truthvalues, tracks)
    
    # 3) Optional: Future extensions
    # - Memory consolidation
    # - Learning updates
    # - Meta-cognitive adjustments
    
    if verbose:
        print(f"[SCCE]   Coherence: {stats['coherence']:.3f}")
        if stats['spikes']:
            print(f"[SCCE]   Spikes: {len(stats['spikes'])}")
    
    return stats


def _compute_coherence(truthvalues: Dict, tracks: Dict) -> float:
    """
    Compute overall cognitive coherence.
    
    This is a simple measure - could be enhanced with full meta-logic.
    
    Args:
        truthvalues: All truthvalues
        tracks: All tracks
    
    Returns:
        Coherence score (0.0-1.0)
    """
    if not truthvalues or not tracks:
        return 1.0
    
    # Simple coherence: variance across tracks within truthvalues
    total_variance = 0.0
    count = 0
    
    for tv_name, tv in truthvalues.items():
        values = [tv.get(track_name) for track_name in tracks]
        if len(values) > 1:
            mean = sum(values) / len(values)
            variance = sum((v - mean) ** 2 for v in values) / len(values)
            total_variance += variance
            count += 1
    
    if count == 0:
        return 1.0
    
    avg_variance = total_variance / count
    
    # Convert variance to coherence (0 variance = 1.0 coherence)
    # Variance can range from 0 to 0.25 (max when values are [0, 1])
    coherence = 1.0 - min(1.0, avg_variance * 4.0)
    
    return coherence


def quick_step(
    runtime,
    profile: Optional[EmotionalProfile] = None,
    verbose: bool = False
) -> Dict[str, Any]:
    """
    Convenience wrapper for cognition_step that takes a runtime object.
    
    Args:
        runtime: HaackLangRuntime instance (must have truthvalues, tracks, global_beat)
        profile: Emotional profile
        verbose: Print logging
    
    Returns:
        Statistics dict
    
    Example:
        # Simplest usage
        stats = quick_step(runtime)
    """
    return cognition_step(
        truthvalues=runtime.truthvalues,
        tracks=runtime.scheduler.tracks,
        global_beat=runtime.scheduler.global_beat,
        profile=profile,
        verbose=verbose
    )

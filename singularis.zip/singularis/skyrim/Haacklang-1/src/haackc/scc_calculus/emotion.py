"""
SCCE Emotional Dynamics

Higher-level emotional calculus built from core primitives.

This module encodes how emotions evolve over time:
- Fear dynamics (rises with danger, inhibited by trust)
- Trust dynamics (builds slowly, erodes quickly)
- Stress dynamics (accumulates, relieves slowly)
- Emotional interference (insight, panic, flow states)
"""

from typing import Dict, Optional
from .core import (
    decay,
    reinforce,
    propagate,
    inhibit,
    amplify,
    interference_spike,
    resonate,
    homeostasis,
)
from .profiles import EmotionalProfile, BALANCED_PROFILE


def fear_dynamics(
    truthvalues: Dict,
    tracks: Dict,
    global_beat: int,
    profile: Optional[EmotionalProfile] = None
) -> None:
    """
    Update fear based on danger, trust, and stress.
    
    Dynamics:
    - Fear decays over time (cooling)
    - Danger reinforces fear (learning)
    - Trust inhibits fear (regulation)
    - Fear + danger resonate → panic
    - Stress amplifies fear
    
    Args:
        truthvalues: Dict of all truthvalues
        tracks: Dict of all tracks
        global_beat: Current beat
        profile: Emotional profile (uses BALANCED if None)
    """
    if profile is None:
        profile = BALANCED_PROFILE
    
    fear = truthvalues.get('fear')
    danger = truthvalues.get('danger')
    trust = truthvalues.get('trust')
    stress = truthvalues.get('stress')
    
    if not fear:
        return
    
    # 1) Decay fear on all tracks
    for track_name in tracks:
        decay(fear, track_name, rate=profile.fear_decay_rate)
    
    # 2) Danger reinforces fear (perception track)
    if danger and 'perception' in tracks:
        reinforce(fear, 'perception', danger, alpha=profile.danger_to_fear_alpha)
    
    # 3) Trust inhibits fear (slow/strategic track)
    if trust and 'strategic' in tracks:
        inhibit(fear, trust, 'strategic', strength=profile.trust_inhibits_fear)
    
    # 4) Stress amplifies fear (main track)
    if stress and 'perception' in tracks:
        amplify(fear, stress, 'perception', strength=0.15)
    
    # 5) Fear + danger resonate into panic (fast track)
    if danger and 'perception' in tracks:
        resonate(fear, danger, 'perception', strength=0.1)
    
    # 6) Propagate fast fear → slow fear (conscious → subconscious)
    if 'perception' in tracks and 'strategic' in tracks:
        propagate(fear, fear, 'perception', 'strategic', alpha=0.1)


def trust_dynamics(
    truthvalues: Dict,
    tracks: Dict,
    global_beat: int,
    profile: Optional[EmotionalProfile] = None
) -> None:
    """
    Update trust based on experience and stress.
    
    Dynamics:
    - Trust decays slowly (forgetting)
    - Positive outcomes build trust (slow)
    - Stress erodes trust (fast)
    - Trust has homeostatic baseline
    
    Args:
        truthvalues: Dict of all truthvalues
        tracks: Dict of all tracks
        global_beat: Current beat
        profile: Emotional profile
    """
    if profile is None:
        profile = BALANCED_PROFILE
    
    trust = truthvalues.get('trust')
    stress = truthvalues.get('stress')
    
    if not trust:
        return
    
    # 1) Slow decay (trust is sticky)
    for track_name in tracks:
        decay(trust, track_name, rate=profile.trust_decay_rate)
    
    # 2) Stress erodes trust on strategic track
    if stress and 'strategic' in tracks:
        inhibit(trust, stress, 'strategic', strength=0.2)
    
    # 3) Homeostatic pull toward baseline (humans tend toward ~0.6 trust)
    if 'strategic' in tracks:
        homeostasis(trust, 'strategic', target=0.6, strength=0.05)


def stress_dynamics(
    truthvalues: Dict,
    tracks: Dict,
    global_beat: int,
    profile: Optional[EmotionalProfile] = None
) -> None:
    """
    Update stress based on danger, fear, and time.
    
    Dynamics:
    - Stress accumulates with danger
    - Fear amplifies stress
    - Stress decays slowly (recovery)
    - Homeostatic pull toward low baseline
    
    Args:
        truthvalues: Dict of all truthvalues
        tracks: Dict of all tracks
        global_beat: Current beat
        profile: Emotional profile
    """
    if profile is None:
        profile = BALANCED_PROFILE
    
    stress = truthvalues.get('stress')
    danger = truthvalues.get('danger')
    fear = truthvalues.get('fear')
    
    if not stress:
        return
    
    # 1) Slow decay (stress relief takes time)
    for track_name in tracks:
        decay(stress, track_name, rate=profile.stress_decay_rate)
    
    # 2) Danger amplifies stress on main track
    if danger and 'perception' in tracks:
        amplify(stress, danger, 'perception', strength=0.15)
    
    # 3) Fear amplifies stress on all tracks
    if fear:
        for track_name in tracks:
            amplify(stress, fear, track_name, strength=0.1)
    
    # 4) Homeostatic pull toward low baseline
    if 'strategic' in tracks:
        homeostasis(stress, 'strategic', target=0.2, strength=0.08)


def curiosity_dynamics(
    truthvalues: Dict,
    tracks: Dict,
    global_beat: int,
    profile: Optional[EmotionalProfile] = None
) -> None:
    """
    Update curiosity based on novelty and stress.
    
    Dynamics:
    - Curiosity decays (habituation)
    - Low stress enables curiosity
    - High stress suppresses curiosity
    - Novelty spikes curiosity
    
    Args:
        truthvalues: Dict of all truthvalues
        tracks: Dict of all tracks
        global_beat: Current beat
        profile: Emotional profile
    """
    if profile is None:
        profile = BALANCED_PROFILE
    
    curiosity = truthvalues.get('curiosity')
    stress = truthvalues.get('stress')
    novelty = truthvalues.get('novelty')
    
    if not curiosity:
        return
    
    # 1) Decay (habituation)
    for track_name in tracks:
        decay(curiosity, track_name, rate=0.03)
    
    # 2) Stress inhibits curiosity
    if stress and 'strategic' in tracks:
        inhibit(curiosity, stress, 'strategic', strength=0.4)
    
    # 3) Novelty spikes curiosity
    if novelty and 'perception' in tracks:
        amplify(curiosity, novelty, 'perception', strength=0.5)


def hope_doubt_dynamics(
    truthvalues: Dict,
    tracks: Dict,
    global_beat: int,
    profile: Optional[EmotionalProfile] = None
) -> None:
    """
    Update hope and doubt (mutual inhibition).
    
    Dynamics:
    - Hope and doubt cross-inhibit
    - Success builds hope
    - Failure builds doubt
    - Both decay over time
    
    Args:
        truthvalues: Dict of all truthvalues
        tracks: Dict of all tracks
        global_beat: Current beat
        profile: Emotional profile
    """
    if profile is None:
        profile = BALANCED_PROFILE
    
    hope = truthvalues.get('hope')
    doubt = truthvalues.get('doubt')
    
    if not hope or not doubt:
        return
    
    # 1) Decay both
    for track_name in tracks:
        decay(hope, track_name, rate=0.02)
        decay(doubt, track_name, rate=0.02)
    
    # 2) Mutual inhibition on strategic track
    if 'strategic' in tracks:
        from .core import cross_inhibit
        cross_inhibit(hope, doubt, 'strategic', strength=0.3)


def update_emotional_fields(
    truthvalues: Dict,
    tracks: Dict,
    global_beat: int,
    profile: Optional[EmotionalProfile] = None
) -> None:
    """
    Complete emotional calculus step - updates all emotional fields.
    
    This is the main entry point for emotional dynamics.
    Call once per global tick.
    
    Args:
        truthvalues: Dict of all truthvalues
        tracks: Dict of all tracks
        global_beat: Current beat
        profile: Emotional profile (uses BALANCED if None)
    """
    if profile is None:
        profile = BALANCED_PROFILE
    
    # 1) Update individual emotional fields
    fear_dynamics(truthvalues, tracks, global_beat, profile)
    trust_dynamics(truthvalues, tracks, global_beat, profile)
    stress_dynamics(truthvalues, tracks, global_beat, profile)
    curiosity_dynamics(truthvalues, tracks, global_beat, profile)
    hope_doubt_dynamics(truthvalues, tracks, global_beat, profile)
    
    # 2) Cross-track propagation
    danger = truthvalues.get('danger')
    if danger and 'perception' in tracks and 'strategic' in tracks:
        # Fast perception slowly updates strategic belief
        propagate(danger, danger, 'perception', 'strategic', 
                 alpha=profile.danger_to_belief_alpha)
    
    # 3) Rhythmic interference (emergent phenomena)
    _update_interference_spikes(truthvalues, tracks, global_beat, profile)


def _update_interference_spikes(
    truthvalues: Dict,
    tracks: Dict,
    global_beat: int,
    profile: EmotionalProfile
) -> None:
    """
    Update interference-based emergent phenomena.
    
    When cognitive rhythms align, emergent states appear:
    - Insight (perception + strategic align)
    - Panic (danger + fear align)
    - Flow (challenge + skill align)
    """
    # 1) Insight spike: when perception and strategic align
    if 'danger' in truthvalues and 'perception' in tracks and 'strategic' in tracks:
        interference_spike(
            truthvalues, tracks, global_beat,
            tv_name='danger',
            track_a='perception',
            track_b='strategic',
            target_track='intuition',
            strength=profile.interference_strength
        )
    
    # 2) Panic spike: when fear and danger align on fast tracks
    if 'fear' in truthvalues and 'danger' in truthvalues and 'perception' in tracks:
        fear = truthvalues['fear']
        danger = truthvalues['danger']
        
        # Only spike if both are high
        if fear.get('perception') > 0.6 and danger.get('perception') > 0.6:
            if 'intuition' in tracks:
                interference_spike(
                    truthvalues, tracks, global_beat,
                    tv_name='fear',
                    track_a='perception',
                    track_b='perception',  # Same track, different truthvalue
                    target_track='intuition',
                    strength=0.2
                )

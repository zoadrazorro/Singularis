"""
Singularis Cognition Calculus Engine (SCCE)

The mathematical brain layer that handles temporal cognitive dynamics.

SCCE operates between:
- The world/sensors (Singularis subsystems, perception)
- The HaackLang runtime (Tracks, BoolRhythm, Contexts)

Its job:
1. Take current cognitive state (danger, fear, trust, stress, etc.)
2. Apply temporal + logical calculus (decay, reinforcement, propagation)
3. Write updated values back into HaackLang truthvalues
4. Let HaackLang contexts & guards make decisions

In other words:
- SCCE = "how the mind changes over time"
- HaackLang = "how the mind interprets and acts based on those changes"
"""

from .core import (
    decay,
    reinforce,
    propagate,
    inhibit,
    amplify,
    interference_spike,
)

from .emotion import (
    update_emotional_fields,
    fear_dynamics,
    trust_dynamics,
    stress_dynamics,
)

from .profiles import (
    EmotionalProfile,
    ANXIOUS_PROFILE,
    STOIC_PROFILE,
    CURIOUS_PROFILE,
    AGGRESSIVE_PROFILE,
    BALANCED_PROFILE,
)

from .cognition import cognition_step


__all__ = [
    # Core primitives
    'decay',
    'reinforce',
    'propagate',
    'inhibit',
    'amplify',
    'interference_spike',
    
    # Emotional dynamics
    'update_emotional_fields',
    'fear_dynamics',
    'trust_dynamics',
    'stress_dynamics',
    
    # Profiles
    'EmotionalProfile',
    'ANXIOUS_PROFILE',
    'STOIC_PROFILE',
    'CURIOUS_PROFILE',
    'AGGRESSIVE_PROFILE',
    'BALANCED_PROFILE',
    
    # Main entry point
    'cognition_step',
]

"""
SCCE Core Calculus Primitives

These are the fundamental mathematical operations for cognitive dynamics:
- Decay: Exponential forgetting/cooling
- Reinforce: Learning from repeated exposure
- Propagate: Cross-track influence (perception → belief → intuition)
- Inhibit: One state suppressing another (trust inhibits fear)
- Amplify: One state boosting another (danger amplifies stress)
- Interference: Rhythmic alignment creates emergent spikes
"""

from typing import Optional
from ..runtime.truthvalue import TruthValue


def decay(tv: TruthValue, track: str, rate: float) -> None:
    """
    Exponential decay: v(t+1) = v(t) * (1 - rate)
    
    Models:
    - Forgetting
    - Emotional cooling
    - Fading memories
    - Stress relief
    
    Args:
        tv: TruthValue to decay
        track: Which track to decay
        rate: Decay rate (0.0-1.0). Typical: 0.01-0.05
    
    Example:
        # Fear fades over time
        decay(fear, 'main', rate=0.02)
    """
    v = tv.get(track)
    tv.set(track, v * (1.0 - rate))


def reinforce(tv: TruthValue, track: str, stimulus: TruthValue, alpha: float) -> None:
    """
    Reinforcement learning style update:
    v_new = (1 - alpha) * v_old + alpha * stimulus
    
    Models:
    - Learning from repeated exposure
    - Belief updating
    - Habit formation
    - Pattern recognition
    
    Args:
        tv: TruthValue to reinforce
        track: Which track to update
        stimulus: New evidence/stimulus
        alpha: Learning rate (0.0-1.0). Typical: 0.1-0.3
    
    Example:
        # Danger perception reinforces danger belief
        reinforce(danger_belief, 'slow', danger_perception, alpha=0.1)
    """
    v = tv.get(track)
    s = stimulus.get(track)
    tv.set(track, (1.0 - alpha) * v + alpha * s)


def propagate(
    source: TruthValue,
    target: TruthValue,
    src_track: str,
    tgt_track: str,
    alpha: float
) -> None:
    """
    Cross-track propagation:
    target[tgt_track] <- blend(target[tgt_track], source[src_track])
    
    Models:
    - Perception → Belief (fast → slow)
    - Belief → Intuition (slow → paraconsistent)
    - Conscious → Subconscious
    - Short-term → Long-term memory
    
    Args:
        source: Source truthvalue
        target: Target truthvalue (can be same as source)
        src_track: Track to read from
        tgt_track: Track to write to
        alpha: Propagation strength (0.0-1.0). Typical: 0.05-0.2
    
    Example:
        # Fast perception slowly influences belief
        propagate(danger, danger, 'perception', 'strategic', alpha=0.1)
    """
    sv = source.get(src_track)
    tv = target.get(tgt_track)
    target.set(tgt_track, (1.0 - alpha) * tv + alpha * sv)


def inhibit(
    tv_a: TruthValue,
    tv_b: TruthValue,
    track: str,
    strength: float
) -> None:
    """
    tv_a inhibited by tv_b: a <- max(0.0, a - strength * b)
    
    Models:
    - Trust inhibiting fear
    - Confidence suppressing doubt
    - Knowledge reducing uncertainty
    - Calm counteracting stress
    
    Args:
        tv_a: TruthValue to inhibit
        tv_b: Inhibiting truthvalue
        track: Which track
        strength: Inhibition strength (0.0-1.0). Typical: 0.2-0.5
    
    Example:
        # Trust reduces fear
        inhibit(fear, trust, 'slow', strength=0.3)
    """
    a = tv_a.get(track)
    b = tv_b.get(track)
    tv_a.set(track, max(0.0, a - strength * b))


def amplify(
    tv_a: TruthValue,
    tv_b: TruthValue,
    track: str,
    strength: float
) -> None:
    """
    tv_a amplified by tv_b: a <- min(1.0, a + strength * b)
    
    Models:
    - Danger amplifying fear
    - Fear boosting stress
    - Success building confidence
    - Hope reinforcing motivation
    
    Args:
        tv_a: TruthValue to amplify
        tv_b: Amplifying truthvalue
        track: Which track
        strength: Amplification strength (0.0-1.0). Typical: 0.1-0.4
    
    Example:
        # Danger amplifies stress
        amplify(stress, danger, 'main', strength=0.2)
    """
    a = tv_a.get(track)
    b = tv_b.get(track)
    tv_a.set(track, min(1.0, a + strength * b))


def interference_spike(
    truthvalues: dict,
    tracks: dict,
    global_beat: int,
    tv_name: str,
    track_a: str,
    track_b: str,
    target_track: str,
    strength: float
) -> None:
    """
    When track_a and track_b fire simultaneously, spike target_track.
    
    Models:
    - Emergent insight (perception + belief align → intuition spike)
    - Panic (danger + fear align → emergency response)
    - Eureka moments (thinking + emotion align → creative leap)
    - Flashbacks (context + memory align → vivid recall)
    
    This is the "magic" of polyrhythmic cognition - when different
    cognitive rhythms align, something emergent happens.
    
    Args:
        truthvalues: Dict of all truthvalues
        tracks: Dict of all tracks
        global_beat: Current global beat
        tv_name: TruthValue to spike
        track_a: First track to check alignment
        track_b: Second track to check alignment
        target_track: Track to spike (usually 'intuition' or 'syncop')
        strength: Spike strength (0.0-1.0). Typical: 0.1-0.3
    
    Example:
        # When perception and belief align, spike intuition
        interference_spike(
            truthvalues, tracks, beat,
            tv_name='danger',
            track_a='perception',
            track_b='strategic',
            target_track='intuition',
            strength=0.15
        )
    """
    # Check if both tracks are active this beat
    if track_a not in tracks or track_b not in tracks:
        return
    
    A = tracks[track_a]
    B = tracks[track_b]
    
    # Check if both fire on current beat
    if A.is_active(global_beat) and B.is_active(global_beat):
        tv = truthvalues.get(tv_name)
        if not tv:
            return
        
        # Spike the target track
        v = tv.get(target_track)
        tv.set(target_track, min(1.0, v + strength))
        
        # Log the interference event
        print(f"[SCCE] Interference spike: {tv_name}.{target_track} "
              f"(alignment of {track_a} + {track_b} at beat {global_beat})")


def cross_inhibit(
    tv_a: TruthValue,
    tv_b: TruthValue,
    track: str,
    strength: float
) -> None:
    """
    Mutual inhibition: both truthvalues inhibit each other.
    
    Models:
    - Approach/avoid conflict
    - Ambivalence
    - Cognitive dissonance
    - Competing goals
    
    Args:
        tv_a: First truthvalue
        tv_b: Second truthvalue
        track: Which track
        strength: Inhibition strength for each direction
    
    Example:
        # Hope and fear mutually inhibit
        cross_inhibit(hope, fear, 'slow', strength=0.2)
    """
    inhibit(tv_a, tv_b, track, strength)
    inhibit(tv_b, tv_a, track, strength)


def resonate(
    tv_a: TruthValue,
    tv_b: TruthValue,
    track: str,
    strength: float
) -> None:
    """
    Resonance: both truthvalues amplify each other.
    
    Models:
    - Positive feedback loops
    - Panic spirals (fear + danger)
    - Flow states (skill + challenge)
    - Synergy
    
    Args:
        tv_a: First truthvalue
        tv_b: Second truthvalue
        track: Which track
        strength: Amplification strength for each direction
    
    Example:
        # Fear and danger resonate into panic
        resonate(fear, danger, 'main', strength=0.15)
    """
    amplify(tv_a, tv_b, track, strength)
    amplify(tv_b, tv_a, track, strength)


def homeostasis(
    tv: TruthValue,
    track: str,
    target: float,
    strength: float
) -> None:
    """
    Pull value toward homeostatic target.
    
    Models:
    - Emotional baseline restoration
    - Arousal regulation
    - Stress recovery
    - Mood stabilization
    
    Args:
        tv: TruthValue to regulate
        track: Which track
        target: Target value (0.0-1.0)
        strength: Pull strength (0.0-1.0). Typical: 0.05-0.15
    
    Example:
        # Stress returns to baseline over time
        homeostasis(stress, 'slow', target=0.2, strength=0.1)
    """
    v = tv.get(track)
    delta = target - v
    tv.set(track, v + strength * delta)


def threshold_trigger(
    tv: TruthValue,
    track: str,
    threshold: float,
    spike: float
) -> bool:
    """
    If value exceeds threshold, spike it and return True.
    
    Models:
    - All-or-nothing responses
    - Tipping points
    - Phase transitions
    - Threshold phenomena
    
    Args:
        tv: TruthValue to check
        track: Which track
        threshold: Trigger threshold
        spike: Amount to spike if triggered
    
    Returns:
        True if threshold was crossed
    
    Example:
        # If danger exceeds 0.8, spike to maximum
        if threshold_trigger(danger, 'main', threshold=0.8, spike=0.2):
            print("EMERGENCY!")
    """
    v = tv.get(track)
    if v >= threshold:
        tv.set(track, min(1.0, v + spike))
        return True
    return False

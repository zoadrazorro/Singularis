"""
SCCE Cognitive Profiles

Different agents/personalities modeled as parameter sets.

Each profile defines how an agent's cognition evolves:
- How fast emotions decay
- How strongly states influence each other
- How rhythmic interference works
- Baseline homeostatic targets

Examples:
- ANXIOUS: Emotions linger, low trust, high interference
- STOIC: Fast decay, high trust inhibition, low interference
- CURIOUS: Low stress impact, high novelty response
- AGGRESSIVE: Fast reactions, high amplification
"""

from dataclasses import dataclass
from typing import Optional


@dataclass
class EmotionalProfile:
    """
    Parameters controlling emotional and cognitive dynamics.
    
    This is the "personality" of the cognitive system.
    """
    
    # === Decay Rates (how fast things fade) ===
    fear_decay_rate: float = 0.02
    """How fast fear fades (0.0-0.1). Lower = lingering fear."""
    
    trust_decay_rate: float = 0.01
    """How fast trust erodes (0.0-0.1). Trust is sticky."""
    
    stress_decay_rate: float = 0.015
    """How fast stress relieves (0.0-0.1). Stress is slow to heal."""
    
    # === Propagation (how states influence each other) ===
    danger_to_belief_alpha: float = 0.1
    """How fast perception updates belief (0.0-0.5)."""
    
    danger_to_fear_alpha: float = 0.15
    """How strongly danger creates fear (0.0-0.5)."""
    
    # === Inhibition (suppression) ===
    trust_inhibits_fear: float = 0.3
    """How much trust reduces fear (0.0-1.0)."""
    
    # === Interference (emergent phenomena) ===
    interference_strength: float = 0.15
    """How strong rhythmic spikes are (0.0-0.5)."""
    
    # === Homeostatic Targets ===
    trust_baseline: float = 0.6
    """Natural trust level to return to (0.0-1.0)."""
    
    stress_baseline: float = 0.2
    """Natural stress level to return to (0.0-1.0)."""
    
    # === Meta-parameters ===
    name: str = "Balanced"
    """Profile name for logging."""
    
    description: str = "Balanced emotional regulation"
    """Profile description."""
    
    def __post_init__(self):
        """Validate parameters."""
        # Clamp all rates to valid ranges
        self.fear_decay_rate = max(0.0, min(0.1, self.fear_decay_rate))
        self.trust_decay_rate = max(0.0, min(0.1, self.trust_decay_rate))
        self.stress_decay_rate = max(0.0, min(0.1, self.stress_decay_rate))
        
        self.danger_to_belief_alpha = max(0.0, min(0.5, self.danger_to_belief_alpha))
        self.danger_to_fear_alpha = max(0.0, min(0.5, self.danger_to_fear_alpha))
        
        self.trust_inhibits_fear = max(0.0, min(1.0, self.trust_inhibits_fear))
        self.interference_strength = max(0.0, min(0.5, self.interference_strength))
        
        self.trust_baseline = max(0.0, min(1.0, self.trust_baseline))
        self.stress_baseline = max(0.0, min(1.0, self.stress_baseline))
    
    def summary(self) -> str:
        """Get a summary string of this profile."""
        return f"""
{self.name} Profile:
  {self.description}
  
  Decay Rates:
    Fear: {self.fear_decay_rate:.3f}
    Trust: {self.trust_decay_rate:.3f}
    Stress: {self.stress_decay_rate:.3f}
  
  Learning:
    Danger → Belief: {self.danger_to_belief_alpha:.3f}
    Danger → Fear: {self.danger_to_fear_alpha:.3f}
  
  Regulation:
    Trust inhibits Fear: {self.trust_inhibits_fear:.3f}
  
  Emergence:
    Interference Strength: {self.interference_strength:.3f}
  
  Baselines:
    Trust: {self.trust_baseline:.3f}
    Stress: {self.stress_baseline:.3f}
        """.strip()


# =============================================================================
# Pre-defined Profiles
# =============================================================================

BALANCED_PROFILE = EmotionalProfile(
    name="Balanced",
    description="Default balanced emotional regulation",
    fear_decay_rate=0.02,
    trust_decay_rate=0.01,
    stress_decay_rate=0.015,
    danger_to_belief_alpha=0.1,
    danger_to_fear_alpha=0.15,
    trust_inhibits_fear=0.3,
    interference_strength=0.15,
    trust_baseline=0.6,
    stress_baseline=0.2,
)


ANXIOUS_PROFILE = EmotionalProfile(
    name="Anxious",
    description="Emotions linger, trust is fragile, high interference",
    fear_decay_rate=0.01,           # Slower decay = lingering fear
    trust_decay_rate=0.03,          # Faster decay = fragile trust
    stress_decay_rate=0.01,         # Slow stress relief
    danger_to_belief_alpha=0.2,     # Danger quickly changes beliefs
    danger_to_fear_alpha=0.3,       # High danger→fear coupling
    trust_inhibits_fear=0.1,        # Trust not very effective
    interference_strength=0.3,      # Lots of intuition/panic spikes
    trust_baseline=0.4,             # Lower baseline trust
    stress_baseline=0.4,            # Higher baseline stress
)


STOIC_PROFILE = EmotionalProfile(
    name="Stoic",
    description="Fast emotional recovery, strong regulation, low interference",
    fear_decay_rate=0.05,           # Fast emotional cooling
    trust_decay_rate=0.005,         # Very sticky trust
    stress_decay_rate=0.04,         # Fast stress relief
    danger_to_belief_alpha=0.05,    # Slow to update beliefs
    danger_to_fear_alpha=0.08,      # Low danger→fear coupling
    trust_inhibits_fear=0.5,        # Trust strongly suppresses fear
    interference_strength=0.05,     # Few emergent spikes
    trust_baseline=0.7,             # High baseline trust
    stress_baseline=0.1,            # Low baseline stress
)


CURIOUS_PROFILE = EmotionalProfile(
    name="Curious",
    description="Low stress impact, high novelty response, exploratory",
    fear_decay_rate=0.03,
    trust_decay_rate=0.015,
    stress_decay_rate=0.025,        # Moderate stress relief
    danger_to_belief_alpha=0.12,    # Open to new information
    danger_to_fear_alpha=0.1,       # Moderate fear response
    trust_inhibits_fear=0.4,        # Good emotional regulation
    interference_strength=0.2,      # Moderate intuition spikes
    trust_baseline=0.65,
    stress_baseline=0.15,           # Low baseline stress
)


AGGRESSIVE_PROFILE = EmotionalProfile(
    name="Aggressive",
    description="Fast reactions, high amplification, impulsive",
    fear_decay_rate=0.025,
    trust_decay_rate=0.02,
    stress_decay_rate=0.02,
    danger_to_belief_alpha=0.25,    # Very reactive to danger
    danger_to_fear_alpha=0.25,      # High danger→fear (but also anger)
    trust_inhibits_fear=0.2,        # Moderate regulation
    interference_strength=0.25,     # High impulsive spikes
    trust_baseline=0.5,             # Moderate trust
    stress_baseline=0.3,            # Higher baseline arousal
)


CAUTIOUS_PROFILE = EmotionalProfile(
    name="Cautious",
    description="Slow to act, high risk aversion, conservative",
    fear_decay_rate=0.015,          # Fear lingers
    trust_decay_rate=0.008,         # Trust builds slowly
    stress_decay_rate=0.012,
    danger_to_belief_alpha=0.08,    # Slow belief updates
    danger_to_fear_alpha=0.2,       # High danger→fear
    trust_inhibits_fear=0.25,       # Moderate regulation
    interference_strength=0.12,     # Moderate spikes
    trust_baseline=0.55,            # Slightly lower trust
    stress_baseline=0.25,           # Higher baseline stress
)


# =============================================================================
# Profile Registry
# =============================================================================

PROFILE_REGISTRY = {
    'balanced': BALANCED_PROFILE,
    'anxious': ANXIOUS_PROFILE,
    'stoic': STOIC_PROFILE,
    'curious': CURIOUS_PROFILE,
    'aggressive': AGGRESSIVE_PROFILE,
    'cautious': CAUTIOUS_PROFILE,
}


def get_profile(name: str) -> Optional[EmotionalProfile]:
    """
    Get a profile by name.
    
    Args:
        name: Profile name (case-insensitive)
    
    Returns:
        EmotionalProfile or None if not found
    
    Example:
        profile = get_profile('anxious')
    """
    return PROFILE_REGISTRY.get(name.lower())


def list_profiles() -> list:
    """Get list of available profile names."""
    return list(PROFILE_REGISTRY.keys())


def print_all_profiles():
    """Print summaries of all profiles."""
    for name in sorted(PROFILE_REGISTRY.keys()):
        profile = PROFILE_REGISTRY[name]
        print("="*70)
        print(profile.summary())
        print()

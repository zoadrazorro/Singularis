"""
SCCE Survival Demo

Demonstrates the Singularis Cognition Calculus Engine in action.

This shows how SCCE's temporal cognitive dynamics work with HaackLang:
1. Perception sets danger levels
2. SCCE evolves fear, trust, stress over time
3. HaackLang guards trigger actions based on evolved state

Compare different emotional profiles to see how they affect behavior.
"""

import sys
from pathlib import Path

# Add src to path
sys.path.insert(0, str(Path(__file__).parent.parent / 'src'))

from haackc.runtime.track import Track, LogicType
from haackc.runtime.truthvalue import TruthValue
from haackc.scc_calculus import (
    cognition_step,
    ANXIOUS_PROFILE,
    STOIC_PROFILE,
    BALANCED_PROFILE,
    CURIOUS_PROFILE,
    AGGRESSIVE_PROFILE,
)


class SimplifiedRuntime:
    """Simplified runtime for demo purposes."""
    
    def __init__(self):
        # Create tracks
        self.tracks = {
            'perception': Track('perception', period=1, phase=0, logic=LogicType.CLASSICAL),
            'strategic': Track('strategic', period=3, phase=0, logic=LogicType.FUZZY),
            'intuition': Track('intuition', period=7, phase=0, logic=LogicType.PARACONSISTENT),
        }
        
        # Create truthvalues
        self.truthvalues = {
            'danger': TruthValue(self.tracks, initial_value=0.0),
            'fear': TruthValue(self.tracks, initial_value=0.0),
            'trust': TruthValue(self.tracks, initial_value=0.6),
            'stress': TruthValue(self.tracks, initial_value=0.2),
        }
        
        self.global_beat = 0
        self.actions_taken = []
    
    def set_danger(self, value: float):
        """Set danger on perception track (simulates perception input)."""
        self.truthvalues['danger'].set('perception', value)
    
    def advance(self):
        """Advance one beat."""
        self.global_beat += 1
        for track in self.tracks.values():
            track.advance()
    
    def check_guards(self):
        """Check guard conditions and trigger actions."""
        danger = self.truthvalues['danger']
        fear = self.truthvalues['fear']
        trust = self.truthvalues['trust']
        
        # Guard: main danger > 0.8 -> flee
        if danger.get('perception') > 0.8:
            self.actions_taken.append(('flee', self.global_beat))
            print(f"  [BEAT {self.global_beat}] ACTION: FLEE (danger={danger.get('perception'):.2f})")
        
        # Guard: slow trust < 0.3 -> withdraw
        elif trust.get('strategic') < 0.3:
            self.actions_taken.append(('withdraw', self.global_beat))
            print(f"  [BEAT {self.global_beat}] ACTION: WITHDRAW (trust={trust.get('strategic'):.2f})")
        
        # Guard: syncop fear > 0.9 -> panic
        elif fear.get('intuition') > 0.9:
            self.actions_taken.append(('panic', self.global_beat))
            print(f"  [BEAT {self.global_beat}] ACTION: PANIC (fear={fear.get('intuition'):.2f})")
    
    def print_state(self):
        """Print current cognitive state."""
        danger = self.truthvalues['danger']
        fear = self.truthvalues['fear']
        trust = self.truthvalues['trust']
        stress = self.truthvalues['stress']
        
        print(f"  Beat {self.global_beat:3d} | "
              f"D:{danger.get('perception'):.2f}/{danger.get('strategic'):.2f}/{danger.get('intuition'):.2f} | "
              f"F:{fear.get('perception'):.2f}/{fear.get('strategic'):.2f}/{fear.get('intuition'):.2f} | "
              f"T:{trust.get('perception'):.2f}/{trust.get('strategic'):.2f}/{trust.get('intuition'):.2f} | "
              f"S:{stress.get('perception'):.2f}/{stress.get('strategic'):.2f}/{stress.get('intuition'):.2f}")


def run_scenario(profile, scenario_name, danger_curve):
    """
    Run a survival scenario with a specific emotional profile.
    
    Args:
        profile: EmotionalProfile to use
        scenario_name: Name of scenario for logging
        danger_curve: List of danger values over time
    """
    print("="*80)
    print(f"Scenario: {scenario_name}")
    print(f"Profile: {profile.name}")
    print("="*80)
    print()
    print(f"  {'Beat':>6} | {'Danger (P/S/I)':^15} | {'Fear (P/S/I)':^15} | "
          f"{'Trust (P/S/I)':^15} | {'Stress (P/S/I)':^15}")
    print("  " + "-"*76)
    
    runtime = SimplifiedRuntime()
    
    for beat, danger_value in enumerate(danger_curve, start=1):
        # 1) Set danger (perception input)
        runtime.set_danger(danger_value)
        
        # 2) Run SCCE cognition step
        stats = cognition_step(
            truthvalues=runtime.truthvalues,
            tracks=runtime.tracks,
            global_beat=runtime.global_beat,
            profile=profile,
            verbose=False
        )
        
        # 3) Check guards (actions)
        runtime.check_guards()
        
        # 4) Print state every 5 beats
        if beat % 5 == 0 or runtime.actions_taken:
            runtime.print_state()
        
        # 5) Advance runtime
        runtime.advance()
    
    print()
    print(f"Actions taken: {len(runtime.actions_taken)}")
    for action, beat in runtime.actions_taken:
        print(f"  Beat {beat}: {action.upper()}")
    print()


def main():
    """Run multiple scenarios with different profiles."""
    
    # Scenario 1: Gradual danger increase
    print("\n" + "="*80)
    print("SCENARIO 1: GRADUAL DANGER INCREASE")
    print("="*80 + "\n")
    
    gradual_danger = [min(1.0, i / 25.0) for i in range(30)]
    
    print("Testing different emotional profiles on same scenario...\n")
    
    run_scenario(BALANCED_PROFILE, "Gradual Danger (Balanced)", gradual_danger)
    run_scenario(ANXIOUS_PROFILE, "Gradual Danger (Anxious)", gradual_danger)
    run_scenario(STOIC_PROFILE, "Gradual Danger (Stoic)", gradual_danger)
    
    # Scenario 2: Danger spike then fade
    print("\n" + "="*80)
    print("SCENARIO 2: DANGER SPIKE THEN FADE")
    print("="*80 + "\n")
    
    spike_danger = (
        [0.0] * 5 +           # Calm
        [0.9] * 5 +           # Sudden spike!
        [0.5] * 5 +           # Reduced
        [0.2] * 5 +           # Fading
        [0.0] * 10            # Safe again
    )
    
    run_scenario(BALANCED_PROFILE, "Danger Spike (Balanced)", spike_danger)
    run_scenario(ANXIOUS_PROFILE, "Danger Spike (Anxious)", spike_danger)
    run_scenario(STOIC_PROFILE, "Danger Spike (Stoic)", spike_danger)
    
    # Scenario 3: Sustained moderate danger
    print("\n" + "="*80)
    print("SCENARIO 3: SUSTAINED MODERATE DANGER")
    print("="*80 + "\n")
    
    sustained_danger = [0.6] * 30
    
    run_scenario(BALANCED_PROFILE, "Sustained Danger (Balanced)", sustained_danger)
    run_scenario(ANXIOUS_PROFILE, "Sustained Danger (Anxious)", sustained_danger)
    run_scenario(STOIC_PROFILE, "Sustained Danger (Stoic)", sustained_danger)
    
    # Profile comparison summary
    print("\n" + "="*80)
    print("PROFILE COMPARISON SUMMARY")
    print("="*80)
    
    print("\nKey Differences:")
    print()
    print("BALANCED Profile:")
    print("  - Moderate emotional regulation")
    print("  - Actions triggered at appropriate times")
    print("  - Recovers at normal pace")
    print()
    print("ANXIOUS Profile:")
    print("  - Emotions linger longer (slow decay)")
    print("  - More prone to PANIC actions (high interference)")
    print("  - Trust erodes quickly, rebuilds slowly")
    print("  - More actions triggered overall")
    print()
    print("STOIC Profile:")
    print("  - Fast emotional recovery (high decay)")
    print("  - Fewer actions triggered")
    print("  - Trust strongly inhibits fear")
    print("  - Maintains composure under stress")
    print()
    
    print("="*80)
    print("Demo Complete!")
    print("="*80)
    print()
    print("Key Takeaway:")
    print("  The SAME danger curve produces DIFFERENT behaviors")
    print("  depending on the emotional profile.")
    print()
    print("  This is SCCE: the math layer of the mind.")
    print("="*80)


if __name__ == '__main__':
    main()

"""
Singularis↔HaackLang Integration Example

This demonstrates how to integrate HaackLang cognitive modules
into the Singularis AGI main loop.
"""

import asyncio
import sys
from pathlib import Path

# Add HaackLang bridge to path
sys.path.insert(0, str(Path(__file__).parent.parent.parent.parent))

from haacklang_bridge import SingularisHaackBridge
from haacklang_bridge.decorators import haack_track, haack_truthvalue, haack_context


# ============================================================================
# Example: Python subsystems with HaackLang decorators
# ============================================================================

@haack_track('perception', period=1, logic='classical')
class PerceptionSubsystem:
    """Fast perceptual processing - maps to perception track."""
    
    @haack_truthvalue('danger', track='perception')
    def detect_visual_threats(self, game_state):
        """Detect threats from visual analysis."""
        # Simulated threat detection
        # In real Singularis, this would call gemini_vision()
        
        if game_state.get('enemy_nearby', False):
            return 0.9  # High danger
        elif game_state.get('enemy_visible', False):
            return 0.6  # Medium danger
        else:
            return 0.2  # Low danger


@haack_track('strategic', period=3, logic='fuzzy')
class StrategicSubsystem:
    """Strategic planning - maps to strategic track."""
    
    @haack_truthvalue('danger', track='strategic')
    def assess_strategic_risk(self, game_state):
        """Assess long-term risk."""
        # Simulated strategic assessment
        # In real Singularis, this would call meta_strategist
        
        health = game_state.get('health', 100)
        enemy_count = game_state.get('enemy_count', 0)
        
        if health < 30 and enemy_count > 2:
            return 0.8  # High strategic risk
        elif enemy_count > 0:
            return 0.5  # Medium risk
        else:
            return 0.2  # Low risk


@haack_track('intuition', period=7, logic='paraconsistent')
class EmotionSubsystem:
    """Emotional/intuitive responses - maps to intuition track."""
    
    @haack_truthvalue('danger', track='intuition')
    def fear_response(self, game_state):
        """Emotional danger assessment."""
        # Simulated emotion
        # In real Singularis, this would call emotion_system (HuiHui)
        
        recent_damage = game_state.get('recent_damage', False)
        stuck_count = game_state.get('stuck_count', 0)
        
        if recent_damage:
            return 0.9  # High fear
        elif stuck_count > 5:
            return 0.7  # Frustration/anxiety
        else:
            return 0.3  # Calm


# ============================================================================
# Main integration loop
# ============================================================================

async def main():
    """Main integration example."""
    
    print("="*70)
    print("Singularis↔HaackLang Integration Example")
    print("="*70)
    
    # Initialize bridge
    modules_dir = Path(__file__).parent.parent / 'cognitive_modules'
    bridge = SingularisHaackBridge(
        haack_modules_dir=modules_dir,
        beat_interval=0.1  # 10 Hz
    )
    
    # Load all .haack modules
    num_modules = bridge.load_all_modules()
    print(f"\n[EXAMPLE] Loaded {num_modules} HaackLang modules")
    
    # Initialize Python subsystems
    perception = PerceptionSubsystem()
    strategic = StrategicSubsystem()
    emotion = EmotionSubsystem()
    
    # Register Python callbacks that .haack modules can call
    def gemini_vision_threat(game_state):
        """Simulated Gemini vision threat detection."""
        return perception.detect_visual_threats(game_state)
    
    def assess_long_term_risk(game_state):
        """Simulated strategic risk assessment."""
        return strategic.assess_strategic_risk(game_state)
    
    def fear_level(game_state):
        """Simulated emotional fear response."""
        return emotion.fear_response(game_state)
    
    bridge.register_python_callback('gemini_vision_threat', gemini_vision_threat)
    bridge.register_python_callback('assess_long_term_risk', assess_long_term_risk)
    bridge.register_python_callback('fear_level', fear_level)
    
    # Simulated game states for demonstration
    test_scenarios = [
        # Scenario 1: Peaceful exploration
        {
            'name': 'Peaceful Exploration',
            'cycles': 5,
            'game_state': {
                'in_combat': False,
                'in_menu': False,
                'enemy_nearby': False,
                'health': 100,
                'enemy_count': 0
            }
        },
        
        # Scenario 2: Enemy detected
        {
            'name': 'Enemy Detected',
            'cycles': 5,
            'game_state': {
                'in_combat': False,
                'in_menu': False,
                'enemy_nearby': True,
                'enemy_visible': True,
                'health': 80,
                'enemy_count': 1
            }
        },
        
        # Scenario 3: Combat
        {
            'name': 'Active Combat',
            'cycles': 10,
            'game_state': {
                'in_combat': True,
                'in_menu': False,
                'enemy_nearby': True,
                'health': 50,
                'enemy_count': 2,
                'recent_damage': True
            }
        },
        
        # Scenario 4: Low health emergency
        {
            'name': 'Low Health Emergency',
            'cycles': 5,
            'game_state': {
                'in_combat': True,
                'in_menu': False,
                'enemy_nearby': True,
                'health': 20,
                'enemy_count': 3,
                'recent_damage': True
            }
        },
    ]
    
    # Run scenarios
    for scenario in test_scenarios:
        print(f"\n{'='*70}")
        print(f"SCENARIO: {scenario['name']}")
        print(f"{'='*70}\n")
        
        game_state = scenario['game_state']
        
        # Update bridge with game state
        bridge.update_game_state(game_state)
        
        # Run cycles
        for i in range(scenario['cycles']):
            print(f"\n--- Cycle {i+1}/{scenario['cycles']} ---")
            
            # Gather subsystem outputs
            subsystem_outputs = {
                'perception.danger': perception.detect_visual_threats(game_state),
                'strategic.danger': strategic.assess_strategic_risk(game_state),
                'emotion.fear': emotion.fear_response(game_state)
            }
            
            # Execute cycle through HaackLang
            result = await bridge.cycle(
                perception={'game_state': game_state},
                subsystem_outputs=subsystem_outputs
            )
            
            # Display results
            print(f"Beat: {result['metadata']['beat']}")
            print(f"Context: {result['metadata']['context']}")
            print(f"Active Tracks: {', '.join(result['active_tracks'])}")
            
            if result['action']:
                print(f"→ ACTION: {result['action']}")
            
            # Show danger truthvalue across tracks
            if 'danger' in result['truthvalues']:
                danger_tv = result['truthvalues']['danger']
                print(f"\nDanger TruthValue:")
                for track, value in danger_tv.to_dict().items():
                    print(f"  {track}: {value:.3f}")
            
            # Check for errors
            if result['metadata']['errors']:
                print(f"\nErrors: {result['metadata']['errors']}")
            
            # Sleep between cycles
            await asyncio.sleep(bridge.beat_interval)
        
        # Print bridge status after scenario
        bridge.print_status()
    
    # Final statistics
    print("\n" + "="*70)
    print("Final Statistics")
    print("="*70)
    
    stats = bridge.get_stats()
    print(f"Total Cycles: {stats['total_cycles']}")
    print(f"HaackLang Executions: {stats['haack_executions']}")
    print(f"Context Switches: {stats['context_switches']}")
    print(f"Errors: {stats['errors']}")
    print(f"Uptime: {stats['uptime']:.1f}s")
    print(f"Cycles/Second: {stats['cycles_per_second']:.2f}")
    
    print("\n" + "="*70)
    print("Integration Example Complete")
    print("="*70)


if __name__ == '__main__':
    asyncio.run(main())

"""
Test paraconsistent logic implementation.
"""

import sys
from pathlib import Path

# Add src to path
sys.path.insert(0, str(Path(__file__).parent.parent / 'src'))

from haackc.runtime.paraconsistent import (
    ParaconsistentValue,
    ParaconsistentLogic,
    paraconsistent_and,
    paraconsistent_or,
    paraconsistent_not
)


def test_paraconsistent_value_creation():
    """Test creating paraconsistent values."""
    print("="*70)
    print("Test: Paraconsistent Value Creation")
    print("="*70)
    
    # Normal value (no contradiction)
    p1 = ParaconsistentValue(belief=0.8, disbelief=0.2)
    print(f"Normal value: {p1}")
    assert not p1.is_contradictory
    assert not p1.is_uncertain
    assert abs(p1.truth_degree - 0.6) < 0.01  # Floating point tolerance
    print("[OK] Normal value works\n")
    
    # Contradictory value (both high)
    p2 = ParaconsistentValue(belief=0.9, disbelief=0.8)
    print(f"Contradictory value: {p2}")
    assert p2.is_contradictory
    assert p2.contradiction_degree > 0.0
    print(f"  Contradiction degree: {p2.contradiction_degree:.2f}")
    print("[OK] Contradiction detected\n")
    
    # Uncertain value (both low)
    p3 = ParaconsistentValue(belief=0.3, disbelief=0.2)
    print(f"Uncertain value: {p3}")
    assert p3.is_uncertain
    print("[OK] Uncertainty detected\n")


def test_paraconsistent_and():
    """Test paraconsistent AND."""
    print("="*70)
    print("Test: Paraconsistent AND")
    print("="*70)
    
    # Normal AND
    a = ParaconsistentValue(belief=0.8, disbelief=0.2)
    b = ParaconsistentValue(belief=0.7, disbelief=0.3)
    result = ParaconsistentLogic.logical_and(a, b)
    
    print(f"A: {a}")
    print(f"B: {b}")
    print(f"A AND B: {result}")
    print()
    
    # AND with contradiction
    c = ParaconsistentValue(belief=0.9, disbelief=0.8)  # Contradictory
    d = ParaconsistentValue(belief=0.8, disbelief=0.2)  # Normal
    result2 = ParaconsistentLogic.logical_and(c, d)
    
    print(f"C (contradictory): {c}")
    print(f"D (normal): {d}")
    print(f"C AND D: {result2}")
    print("[OK] Paraconsistent AND works\n")


def test_paraconsistent_or():
    """Test paraconsistent OR."""
    print("="*70)
    print("Test: Paraconsistent OR")
    print("="*70)
    
    a = ParaconsistentValue(belief=0.3, disbelief=0.7)
    b = ParaconsistentValue(belief=0.8, disbelief=0.2)
    result = ParaconsistentLogic.logical_or(a, b)
    
    print(f"A: {a}")
    print(f"B: {b}")
    print(f"A OR B: {result}")
    print("[OK] Paraconsistent OR works\n")


def test_paraconsistent_not():
    """Test paraconsistent NOT."""
    print("="*70)
    print("Test: Paraconsistent NOT")
    print("="*70)
    
    a = ParaconsistentValue(belief=0.8, disbelief=0.2)
    result = ParaconsistentLogic.logical_not(a)
    
    print(f"A: {a}")
    print(f"NOT A: {result}")
    assert result.belief == a.disbelief
    assert result.disbelief == a.belief
    print("[OK] Paraconsistent NOT works\n")
    
    # NOT of contradiction stays contradictory
    b = ParaconsistentValue(belief=0.9, disbelief=0.8)
    result2 = ParaconsistentLogic.logical_not(b)
    
    print(f"B (contradictory): {b}")
    print(f"NOT B: {result2}")
    assert result2.is_contradictory
    print("[OK] Contradiction preserved through NOT\n")


def test_contradiction_resolution():
    """Test resolving contradictions."""
    print("="*70)
    print("Test: Contradiction Resolution")
    print("="*70)
    
    # Create contradiction
    p = ParaconsistentValue(belief=0.9, disbelief=0.8)
    print(f"Original (contradictory): {p}")
    
    # Resolve using different strategies
    resolved_avg = ParaconsistentLogic.resolve_contradiction(p, strategy='average')
    print(f"Resolved (average): {resolved_avg}")
    assert not resolved_avg.is_contradictory
    
    resolved_belief = ParaconsistentLogic.resolve_contradiction(p, strategy='favor_belief')
    print(f"Resolved (favor_belief): {resolved_belief}")
    assert not resolved_belief.is_contradictory
    
    resolved_disbelief = ParaconsistentLogic.resolve_contradiction(p, strategy='favor_disbelief')
    print(f"Resolved (favor_disbelief): {resolved_disbelief}")
    assert not resolved_disbelief.is_contradictory
    
    print("[OK] Contradiction resolution works\n")


def test_gradual_resolution():
    """Test gradual contradiction resolution."""
    print("="*70)
    print("Test: Gradual Contradiction Resolution")
    print("="*70)
    
    p = ParaconsistentValue(belief=0.9, disbelief=0.8)
    print(f"Original: {p}")
    print(f"Contradiction degree: {p.contradiction_degree:.2f}\n")
    
    # Apply gradual resolution multiple times
    for i in range(5):
        p = ParaconsistentLogic.gradual_resolution(p, rate=0.2)
        print(f"After step {i+1}: {p}")
        print(f"  Contradiction degree: {p.contradiction_degree:.2f}")
    
    print("\n[OK] Gradual resolution reduces contradiction over time\n")


def test_classical_interface():
    """Test classical value interface."""
    print("="*70)
    print("Test: Classical Value Interface")
    print("="*70)
    
    # These are the functions used by truthvalue.py
    result_and = paraconsistent_and(0.8, 0.7)
    print(f"paraconsistent_and(0.8, 0.7) = {result_and:.3f}")
    
    result_or = paraconsistent_or(0.3, 0.8)
    print(f"paraconsistent_or(0.3, 0.8) = {result_or:.3f}")
    
    result_not = paraconsistent_not(0.8)
    print(f"paraconsistent_not(0.8) = {result_not:.3f}")
    
    print("\n[OK] Classical interface works\n")


def test_contradiction_explosion_prevention():
    """Test that contradictions don't cause explosion."""
    print("="*70)
    print("Test: Explosion Prevention (Key Paraconsistent Property)")
    print("="*70)
    
    # In classical logic: P AND NOT P = False (explosion)
    # In paraconsistent logic: P AND NOT P can be true without explosion
    
    p = ParaconsistentValue(belief=0.9, disbelief=0.8)  # Contradictory
    not_p = ParaconsistentLogic.logical_not(p)
    
    print(f"P (contradictory): {p}")
    print(f"NOT P: {not_p}")
    
    # P AND NOT P
    p_and_not_p = ParaconsistentLogic.logical_and(p, not_p)
    print(f"P AND NOT P: {p_and_not_p}")
    
    # This should NOT collapse to false - it preserves the contradiction
    print(f"Truth degree of P AND NOT P: {p_and_not_p.truth_degree:+.2f}")
    print(f"Is contradictory: {p_and_not_p.is_contradictory}")
    
    # The key property: we can reason with contradictions without explosion
    # We can still perform other operations
    q = ParaconsistentValue(belief=0.7, disbelief=0.3)
    result = ParaconsistentLogic.logical_or(p_and_not_p, q)
    print(f"(P AND NOT P) OR Q: {result}")
    
    print("\n[OK] No explosion - system remains stable with contradictions\n")


if __name__ == '__main__':
    print("\n" + "="*70)
    print("PARACONSISTENT LOGIC TEST SUITE")
    print("="*70 + "\n")
    
    test_paraconsistent_value_creation()
    test_paraconsistent_and()
    test_paraconsistent_or()
    test_paraconsistent_not()
    test_contradiction_resolution()
    test_gradual_resolution()
    test_classical_interface()
    test_contradiction_explosion_prevention()
    
    print("="*70)
    print("ALL TESTS PASSED [SUCCESS]")
    print("="*70)

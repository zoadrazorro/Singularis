"""
Test meta-logic operators.
"""

import sys
from pathlib import Path

# Add src to path
sys.path.insert(0, str(Path(__file__).parent.parent / 'src'))

from haackc.runtime.track import Track, LogicType
from haackc.runtime.truthvalue import TruthValue
from haackc.runtime.metalogic import MetaLogic


def test_internal_coherence():
    """Test internal coherence measurement."""
    print("="*70)
    print("Test: Internal Coherence")
    print("="*70)
    
    # Create tracks
    tracks = {
        'main': Track('main', period=1, logic=LogicType.CLASSICAL),
        'slow': Track('slow', period=4, logic=LogicType.FUZZY),
        'syncop': Track('syncop', period=7, logic=LogicType.PARACONSISTENT)
    }
    
    # High coherence - all tracks agree
    tv1 = TruthValue(tracks, initial_value=0.8)
    coh1 = MetaLogic.coherence(tv1)
    print(f"TruthValue with all tracks at 0.8:")
    print(f"  {tv1}")
    print(f"  Internal coherence: {coh1:.3f}")
    assert coh1 > 0.95
    print("[OK] High coherence detected\n")
    
    # Low coherence - tracks disagree
    tv2 = TruthValue(tracks, initial_value=0.0)
    tv2.set('main', 0.9)
    tv2.set('slow', 0.3)
    tv2.set('syncop', 0.1)
    coh2 = MetaLogic.coherence(tv2)
    print(f"TruthValue with divergent tracks:")
    print(f"  {tv2}")
    print(f"  Internal coherence: {coh2:.3f}")
    assert coh2 < 0.7
    print("[OK] Low coherence detected\n")


def test_external_coherence():
    """Test coherence between multiple truthvalues."""
    print("="*70)
    print("Test: External Coherence")
    print("="*70)
    
    tracks = {
        'main': Track('main', period=1, logic=LogicType.CLASSICAL),
        'slow': Track('slow', period=4, logic=LogicType.FUZZY),
    }
    
    # High coherence - truthvalues agree
    tv1 = TruthValue(tracks, initial_value=0.8)
    tv2 = TruthValue(tracks, initial_value=0.75)
    tv3 = TruthValue(tracks, initial_value=0.82)
    
    coh = MetaLogic.coherence(tv1, tv2, tv3)
    print(f"Three truthvalues with similar values:")
    print(f"  TV1: {tv1}")
    print(f"  TV2: {tv2}")
    print(f"  TV3: {tv3}")
    print(f"  External coherence: {coh:.3f}")
    assert coh > 0.9
    print("[OK] High external coherence\n")
    
    # Low coherence - truthvalues disagree
    tv4 = TruthValue(tracks, initial_value=0.2)
    tv5 = TruthValue(tracks, initial_value=0.9)
    
    coh2 = MetaLogic.coherence(tv4, tv5)
    print(f"Two truthvalues with different values:")
    print(f"  TV4: {tv4}")
    print(f"  TV5: {tv5}")
    print(f"  External coherence: {coh2:.3f}")
    assert coh2 < 0.6
    print("[OK] Low external coherence detected\n")


def test_conflict_detection():
    """Test conflict detection between truthvalues."""
    print("="*70)
    print("Test: Conflict Detection")
    print("="*70)
    
    tracks = {
        'main': Track('main', period=1, logic=LogicType.CLASSICAL),
        'slow': Track('slow', period=4, logic=LogicType.FUZZY),
    }
    
    # No conflict
    tv1 = TruthValue(tracks, initial_value=0.7)
    tv2 = TruthValue(tracks, initial_value=0.75)
    
    has_conflict, conflicts = MetaLogic.conflict(tv1, tv2)
    print(f"TV1: {tv1}")
    print(f"TV2: {tv2}")
    print(f"Has conflict: {has_conflict}")
    assert not has_conflict
    print("[OK] No conflict detected (as expected)\n")
    
    # With conflict
    tv3 = TruthValue(tracks, initial_value=0.2)
    tv4 = TruthValue(tracks, initial_value=0.9)
    
    has_conflict2, conflicts2 = MetaLogic.conflict(tv3, tv4)
    print(f"TV3: {tv3}")
    print(f"TV4: {tv4}")
    print(f"Has conflict: {has_conflict2}")
    if has_conflict2:
        print(f"Conflicts detected:")
        for track, desc in conflicts2:
            print(f"  {track}: {desc}")
    assert has_conflict2
    print("[OK] Conflict detected\n")


def test_conflict_resolution():
    """Test resolving conflicts between truthvalues."""
    print("="*70)
    print("Test: Conflict Resolution")
    print("="*70)
    
    tracks = {
        'main': Track('main', period=1, logic=LogicType.CLASSICAL),
        'slow': Track('slow', period=4, logic=LogicType.FUZZY),
    }
    
    # Conflicting truthvalues
    tv1 = TruthValue(tracks, initial_value=0.2)
    tv2 = TruthValue(tracks, initial_value=0.8)
    tv3 = TruthValue(tracks, initial_value=0.5)
    
    print("Conflicting truthvalues:")
    print(f"  TV1: {tv1}")
    print(f"  TV2: {tv2}")
    print(f"  TV3: {tv3}")
    print()
    
    # Resolve with different strategies
    resolved_avg = MetaLogic.resolve(tv1, tv2, tv3, strategy='average')
    print(f"Resolved (average): {resolved_avg}")
    # Average of 0.2, 0.8, 0.5 = 0.5
    avg_val = resolved_avg.get('main')
    print(f"  Main track value: {avg_val:.2f}")
    assert abs(avg_val - 0.5) < 0.2, f"Expected ~0.5, got {avg_val}"
    
    resolved_max = MetaLogic.resolve(tv1, tv2, tv3, strategy='maximum')
    print(f"Resolved (maximum): {resolved_max}")
    max_val = resolved_max.get('main')
    assert abs(max_val - 0.8) < 0.1, f"Expected ~0.8, got {max_val}"
    
    resolved_min = MetaLogic.resolve(tv1, tv2, tv3, strategy='minimum')
    print(f"Resolved (minimum): {resolved_min}")
    min_val = resolved_min.get('main')
    assert abs(min_val - 0.2) < 0.1, f"Expected ~0.2, got {min_val}"
    
    print("\n[OK] Conflict resolution works\n")


def test_meta_reasoning():
    """Test full meta-cognitive reasoning."""
    print("="*70)
    print("Test: Meta-Cognitive Reasoning")
    print("="*70)
    
    tracks = {
        'perception': Track('perception', period=1, logic=LogicType.CLASSICAL),
        'strategic': Track('strategic', period=3, logic=LogicType.FUZZY),
        'intuition': Track('intuition', period=7, logic=LogicType.PARACONSISTENT)
    }
    
    # Create some truthvalues with varying coherence
    truthvalues = {
        'danger': TruthValue(tracks, initial_value=0.0),
        'opportunity': TruthValue(tracks, initial_value=0.0),
        'confidence': TruthValue(tracks, initial_value=0.0)
    }
    
    # Set values to create interesting patterns
    truthvalues['danger'].set('perception', 0.9)
    truthvalues['danger'].set('strategic', 0.6)
    truthvalues['danger'].set('intuition', 0.3)  # Low internal coherence
    
    truthvalues['opportunity'].set('perception', 0.4)
    truthvalues['opportunity'].set('strategic', 0.7)
    truthvalues['opportunity'].set('intuition', 0.5)
    
    truthvalues['confidence'].set('perception', 0.8)
    truthvalues['confidence'].set('strategic', 0.8)
    truthvalues['confidence'].set('intuition', 0.7)  # High internal coherence
    
    # Perform meta-reasoning
    analysis = MetaLogic.meta_reasoning(truthvalues, tracks)
    
    print("Meta-cognitive analysis:")
    print(f"  Overall coherence: {analysis['overall_coherence']:.3f}")
    print(f"  Number of conflicts: {analysis['num_conflicts']}")
    print()
    
    print("TruthValue stats:")
    for name, stats in analysis['truthvalue_stats'].items():
        print(f"  {name}:")
        print(f"    Internal coherence: {stats['internal_coherence']:.3f}")
        print(f"    Values: {stats['values']}")
    print()
    
    if analysis['recommendations']:
        print("Recommendations:")
        for rec in analysis['recommendations']:
            print(f"  - {rec}")
    
    print("\n[OK] Meta-reasoning complete\n")


def test_coherence_thresholds():
    """Test coherence threshold detection."""
    print("="*70)
    print("Test: Coherence Thresholds (for Singularis integration)")
    print("="*70)
    
    tracks = {
        'perception': Track('perception', period=1, logic=LogicType.CLASSICAL),
        'strategic': Track('strategic', period=3, logic=LogicType.FUZZY),
    }
    
    # Critical low coherence (< 0.4)
    tv_critical = TruthValue(tracks, initial_value=0.0)
    tv_critical.set('perception', 0.9)
    tv_critical.set('strategic', 0.1)
    
    coh_critical = MetaLogic.coherence(tv_critical)
    print(f"Critical case (perception=0.9, strategic=0.1):")
    print(f"  Coherence: {coh_critical:.3f}")
    
    if coh_critical < 0.4:
        print("  -> CRITICAL: Should enter survival mode")
    print()
    
    # Warning low coherence (< 0.6)
    tv_warning = TruthValue(tracks, initial_value=0.0)
    tv_warning.set('perception', 0.7)
    tv_warning.set('strategic', 0.4)
    
    coh_warning = MetaLogic.coherence(tv_warning)
    print(f"Warning case (perception=0.7, strategic=0.4):")
    print(f"  Coherence: {coh_warning:.3f}")
    
    if coh_warning < 0.6:
        print("  -> WARNING: Subsystems disagree")
    print()
    
    # Good coherence
    tv_good = TruthValue(tracks, initial_value=0.0)
    tv_good.set('perception', 0.75)
    tv_good.set('strategic', 0.72)
    
    coh_good = MetaLogic.coherence(tv_good)
    print(f"Good case (perception=0.75, strategic=0.72):")
    print(f"  Coherence: {coh_good:.3f}")
    
    if coh_good > 0.8:
        print("  -> GOOD: Systems agree")
    
    print("\n[OK] Coherence thresholds work as expected\n")


if __name__ == '__main__':
    print("\n" + "="*70)
    print("META-LOGIC TEST SUITE")
    print("="*70 + "\n")
    
    test_internal_coherence()
    test_external_coherence()
    test_conflict_detection()
    test_conflict_resolution()
    test_meta_reasoning()
    test_coherence_thresholds()
    
    print("="*70)
    print("ALL TESTS PASSED [SUCCESS]")
    print("="*70)

"""
Run all HaackLang tests.
"""

import sys
import subprocess
from pathlib import Path


def run_test(test_file):
    """Run a single test file."""
    print(f"\n{'='*70}")
    print(f"Running: {test_file.name}")
    print('='*70)
    
    result = subprocess.run(
        [sys.executable, str(test_file)],
        capture_output=False,
        text=True
    )
    
    return result.returncode == 0


def main():
    tests_dir = Path(__file__).parent
    
    test_files = [
        tests_dir / 'test_paraconsistent.py',
        tests_dir / 'test_metalogic.py',
    ]
    
    print("\n" + "="*70)
    print("HAACKLANG HLVM TEST SUITE")
    print("="*70)
    print(f"Running {len(test_files)} test files...")
    
    results = []
    for test_file in test_files:
        if test_file.exists():
            success = run_test(test_file)
            results.append((test_file.name, success))
        else:
            print(f"\n⚠️  Test file not found: {test_file}")
            results.append((test_file.name, False))
    
    # Summary
    print("\n" + "="*70)
    print("TEST SUMMARY")
    print("="*70)
    
    for name, success in results:
        status = "[PASS]" if success else "[FAIL]"
        print(f"{status} - {name}")
    
    all_passed = all(success for _, success in results)
    
    print("\n" + "="*70)
    if all_passed:
        print("ALL TESTS PASSED [SUCCESS]")
        print("="*70)
        print("\nHLVM Phase 1 Implementation: VALIDATED")
        print("Ready for Phase 2 - Singularis Integration")
    else:
        print("SOME TESTS FAILED")
        print("="*70)
        return 1
    
    return 0


if __name__ == '__main__':
    sys.exit(main())

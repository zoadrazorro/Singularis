"""Core philosophical and architectural foundations."""
